"""Math commands (*frac, *pow, *root, *sum, *prod, *lim, ...).

Table of contents for this ~1100-line file — line numbers are
approximate, the names are stable:

    ~line  section
    -----  -------
      42   _has_top_level_semi() / split_top_level_args() — shared
           argument splitter: ';' wins at depth 0, else ',', quotes safe
     129   MATH_ALIASES + normalize_friendly_calls() — friendly
           aliases (fraction→frac, power→pow, integral→int, ...)
     179   escape_number_commas() / space_out_bare_identifiers() —
           keep 100,000 intact; make MD / 4ac readable to Typst
     255   replace_math_call() — generic depth-aware *name(...) engine
     333   clean_inner_math() — per-argument normalization (vars,
           calc, symbols) shared by every command below
     403   math_call_specs() — THE table of one-liner commands:
           frac, abs, trig, sqrt/cbrt, log/ln, pow, root, sum, prod,
           lim, binom, accents
     452   *int / *oint (integrals)
     559   *diff / *pdiff (derivatives)
     651   *cases (piecewise / equation systems, rows on '|')
     742   *det (determinants)
     901   *set (set-builder vs listing)
     970   *align (rows aligned on '=')
    ~1075   *vec (math-mode column vector, *matrix-style components)
    ~1130   *pow helpers: group_power_base(), _format_pow()

Adding a command? Prefer a spec entry in math_call_specs() (name,
min_args, formatter); the replace_*_calls for int/diff/cases/det/
set/align show the manual pattern. Register the name in
diagnostics.KNOWN_COMMANDS (unknown names warn "did you mean") and
document it in rule.txt + docs/algebra.md.
"""

import re

from .calc import apply_calc_in_string
from .command_registry import DEFAULT_REGISTRY, render_spec
from .diagnostics import report
from .symbols import replace_symbol_shortcuts
from .variables import replace_defines, replace_vars


def _has_top_level_semi(s):
    """True when *s* has a depth-0 ``;`` (quote-aware for ``"..."``).

    Shared by the friendly ``;``-wins splitters: when ``;`` appears at
    depth 0 it separates alone (so ``100,000`` stays intact).
    """
    _dp = _db = _br = 0
    _q = False
    for _i, _ch in enumerate(s):
        if _ch == '"' and (_i == 0 or s[_i - 1] != '\\'):
            _q = not _q
            continue
        if _q:
            continue
        if _ch == '(':
            _dp += 1
        elif _ch == ')' and _dp > 0:
            _dp -= 1
        elif _ch == '{':
            _db += 1
        elif _ch == '}' and _db > 0:
            _db -= 1
        elif _ch == '[':
            _br += 1
        elif _ch == ']' and _br > 0:
            _br -= 1
        elif _ch == ';' and _dp == 0 and _db == 0 and _br == 0:
            return True
    return False


def split_top_level_args(args):
    """Split on ';' (or ',' friendly) at paren depth 0 (tracks (), {} and []).

    Friendly rule: when ';' appears at depth 0, split on ';' only
    (so ``*frac(100,000 ; 2)`` keeps ``100,000`` intact). Otherwise
    split on ',' so ``*frac(2,3)`` works like ``*frac(2 ; 3)``.
    Separators inside double-quoted strings are ignored so
    ``*frac("a;b" ; c)`` keeps ``"a;b"`` intact.
    """
    # Scan for a depth-0 ';' first to decide the separator set.
    # Quote-aware: separators inside "..." never count.
    has_semi = _has_top_level_semi(args)
    seps = (';',) if has_semi else (';', ',')
    parts = []
    current = []
    depth_paren = 0
    depth_brace = 0
    depth_bracket = 0
    in_quote = False
    idx = 0
    for char in args:
        if char == '"' and (idx == 0 or args[idx - 1] != '\\'):
            in_quote = not in_quote
            current.append(char)
            idx += 1
            continue
        if in_quote:
            current.append(char)
            idx += 1
            continue
        if char == '(':
            depth_paren += 1
        elif char == ')' and depth_paren > 0:
            depth_paren -= 1
        elif char == '{':
            depth_brace += 1
        elif char == '}' and depth_brace > 0:
            depth_brace -= 1
        elif char == '[':
            depth_bracket += 1
        elif char == ']' and depth_bracket > 0:
            depth_bracket -= 1
        if (char in seps and depth_paren == 0
                and depth_brace == 0 and depth_bracket == 0):
            parts.append(''.join(current).strip())
            current = []
        else:
            current.append(char)
        idx += 1
    parts.append(''.join(current).strip())
    return parts


# Friendly aliases: alias -> canonical math command. Derived from the
# default command registry (commands.toml) so adding an alias only
# touches the mod file. Bare (star-less) calls like frac(2 ; 3) are also
# accepted (see normalize_friendly_calls).
MATH_ALIASES = {}
for _spec in DEFAULT_REGISTRY.commands.values():
    for _alias in _spec.aliases:
        MATH_ALIASES[_alias] = _spec.name

_CANONICAL_MATH_NAMES = (
    'frac', 'abs', 'sin', 'cos', 'tan', 'sqrt', 'log', 'ln',
    'pow', 'root', 'sum', 'prod', 'lim', 'cbrt',
    'int', 'oint', 'cases', 'vec', 'binom',
    'cot', 'sec', 'csc', 'arcsin', 'arccos', 'arctan',
    'sinh', 'cosh', 'tanh', 'coth',
    'hat', 'bar', 'overline', 'tilde', 'dot',
)


def normalize_friendly_calls(text, registry=None):
    """Rewrite friendly math spellings to canonical ``*name(...)`` form.

    Only starred aliases (``*fraction(`` -> ``*frac(`` etc., see the
    registry's alias map). Bare ``frac(`` without ``*`` is deliberately
    NOT rewritten here. Idempotent and safe to call repeatedly.
    """
    if registry is None:
        try:
            from .command_registry import DEFAULT_REGISTRY
            registry = DEFAULT_REGISTRY
        except Exception:  # pragma: no cover - defensive
            registry = None
    alias_map = getattr(registry, 'aliases', None)
    if alias_map is None:
        alias_map = MATH_ALIASES
    # Starred aliases: *fraction( -> *frac(. Hyphenated aliases need
    # re.escape (e.g. square-root). Skip identity (cbrt -> cbrt).
    for alias, canon in alias_map.items():
        if alias == canon:
            continue
        text = re.sub(
            r'\*' + re.escape(alias) + r'\s*\(',
            f'*{canon}(',
            text,
        )
    return text


def escape_number_commas(s):
    """Escape literal commas that belong to numbers for Typst math.

    A bare comma inside Typst math function args is an argument
    separator, so emitting ``$frac(100,000, 7)$`` fails with
    "unexpected argument" (no PDF). Verified: ``$frac(100\\,000, 7)$``
    compiles. Only a comma where there are at least 2 digits on either
    side is escaped — single-digit separators (e.g. ``frac(2,3)``) are
    left intact because the formatters always emit them with a trailing
    space.

    Quoted spans are opaque text, not math: their content is left
    byte-for-byte alone (a quoted ``100,000`` must stay as typed).
    """
    parts = re.split(r'("[^"]*")', s)
    for i in range(0, len(parts), 2):
        # Only escape commas with 2+ digits on at least one side;
        # single-digit separators like frac(2,3) are function args
        # and survive because formatters add trailing spaces.
        def _escape_comma(m):
            before = m.group(1)
            after = m.group(2)
            digits_before = len(re.findall(r'\d', before))
            digits_after = len(re.findall(r'\d', after))
            if digits_before >= 2 or digits_after >= 2:
                return m.group(0).replace(',', r'\,')
            return m.group(0)

        parts[i] = re.sub(r'(\d*),(\d*)', _escape_comma, parts[i])
    return ''.join(parts)


# Typst math identifiers that must survive space_out_bare_identifiers().
# Everything else that looks like a bare multi-letter word (MD, ABC, MBC)
# is an "unknown variable" in Typst and aborts the whole PDF build, so we
# split it into implicit products (M D, A B C) which always compile.
_TYPST_MATH_KEEP = frozenset({
    'frac', 'abs', 'sin', 'cos', 'tan', 'sqrt', 'cbrt', 'root',
    'sum', 'product', 'prod', 'lim', 'display',
    'integral', 'cont', 'dif', 'cases', 'arrow', 'vec', 'binom',
    'cot', 'sec', 'csc', 'arcsin', 'arccos', 'arctan',
    'sinh', 'cosh', 'tanh', 'coth',
    'hat', 'bar', 'overline', 'tilde', 'dot',
    'partial', 'det', 'delim',
    'quad', 'thin', 'med',
    'pi', 'infinity',
    'strong', 'emph', 'underline',
    'upright', 'bracket', 'lr', 'mid',
})


def space_out_bare_identifiers(s):
    """Split bare multi-letter words so Typst math compiles.

    ``$frac(MD, AD)$`` fails with "unknown variable: MD" because Typst
    reads ``MD`` as one variable name. ``$frac(M D, A D)$`` (implicit
    product) compiles and renders as math italic, which is the right
    look for segment/triangle names (MD, ABC, MBC, ...).

    Kept intact: quoted strings ("MD"), Typst functions/constants in
    _TYPST_MATH_KEEP, function calls (word followed by '('), and
    single letters/digits. Idempotent: already-spaced output is stable.

    Letters directly after a digit also split (4ac -> 4a c, 2xy -> 2x y)
    so the quadratic discriminant b^2 - 4ac does not abort Typst with
    "unknown variable: ac". The digit stays glued to the first letter
    (4a), which Typst reads as implicit product and compiles fine.
    """
    # Split out "..." quoted spans so we never touch string contents.
    parts = re.split(r'("[^"]*")', s)
    for idx in range(0, len(parts), 2):
        seg = parts[idx]

        def _repl(m, seg=seg):
            word = m.group(1)
            if len(word) < 2:
                return word
            if word in _TYPST_MATH_KEEP:
                return word
            # Function call: name directly followed by '(' stays whole.
            # Whitespace before '(' is NOT a call (e.g. 'AB (x)'): split
            # it so Typst doesn't abort on unknown variable 'AB'.
            after = seg[m.end():]
            if after.startswith('('):
                return word
            return ' '.join(word)

        parts[idx] = re.sub(
            r'(?<![A-Za-z_])([A-Za-z][A-Za-z0-9]*)(?![A-Za-z0-9_])',
            _repl,
            seg,
        )
    return ''.join(parts)


def replace_math_call(text, name, min_args, formatter, _depth=0,
                      line_no=None):
    """Replace *name(...) calls using depth-aware paren matching."""
    if _depth > 20:
        report('Warning', line_no,
               f'*{name}(...) nested too deep — leaving as-is')
        return text
    try:
        return _replace_math_call(text, name, min_args, formatter, _depth,
                                  line_no=line_no)
    except RecursionError:
        report('Warning', line_no,
               f'*{name}(...) nested too deep — leaving as-is')
        return text


def _replace_math_call(text, name, min_args, formatter, _depth=0,
                       line_no=None):
    import re
    pattern = re.compile(r'\*' + re.escape(name) + r'\s*\(')
    pos = 0
    out = []
    while True:
        match = pattern.search(text, pos)
        if not match:
            out.append(text[pos:])
            break
        out.append(text[pos:match.start()])
        start = match.end()
        depth = 1
        i = start
        in_quote = False
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '"' and (i == 0 or text[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            report(
                'Warning', line_no,
                f'unclosed *{name}(... — missing closing parenthesis')
            # Emit the opener literally and continue scanning so later
            # valid calls on the same line are still processed.
            out.append(text[match.start():match.end()])
            pos = match.end()
            continue
        args = split_top_level_args(text[start:i - 1])
        if len(args) < min_args:
            report(
                'Warning', line_no,
                f'*{name}(...) expects {min_args} argument(s), '
                f'got {len(args)} — leaving as-is')
            out.append(text[match.start():i])
        elif any(a == '' for a in args[:min_args]):
            report(
                'Warning', line_no,
                f'*{name}(...) has empty argument(s) — leaving as-is')
            out.append(text[match.start():i])
        else:
            if len(args) > min_args:
                report(
                    'Warning', line_no,
                    f'*{name}(...) expects {min_args} argument(s), '
                    f'got {len(args)} — extra arguments ignored')
                args = args[:min_args]
            out.append(formatter(args))
        pos = i
    return ''.join(out)


def clean_inner_math(ctx, s, _depth=0, line_no=None):
    """Normalize a math argument: vars, defines, calc, nested math calls."""
    if _depth > 20:
        report('Warning', line_no,
               'math nesting too deep — leaving as-is')
        return s
    try:
        return _clean_inner_math(ctx, s, _depth, line_no=line_no)
    except RecursionError:
        report('Warning', line_no,
               'math nesting too deep — leaving as-is')
        return s


def _clean_inner_math(ctx, s, _depth=0, line_no=None):
    from .text_commands import normalize_text_aliases, replace_styling_calls
    s = normalize_friendly_calls(s.strip(), ctx.registry if hasattr(ctx, 'registry') else None)
    s = normalize_text_aliases(s)
    s = replace_styling_calls(
        s, ctx, line_no,
        lambda arg: clean_inner_math(ctx, arg, _depth + 1, line_no=line_no),
        _depth,
    )
    s = replace_vars(ctx, s.strip())
    s = replace_defines(ctx, s)
    s = apply_calc_in_string(ctx, s, line_no=line_no)
    # Unify *pi/*infinity with the text/math paths: text renders $pi$,
    # inline math renders pi inside $...$, so normalize to bare words
    # here before symbol shortcuts (which map *pi -> π).
    s = re.sub(r'\*pi\b', 'pi', s)
    s = re.sub(r'\*infinity\b', 'infinity', s)
    # Strip only temporary $ wrappers (e.g. from nested math calls),
    # not every literal '$': a literal dollar in args is preserved for
    # the final unwrap below.
    s = replace_symbol_shortcuts(s)
    s = normalize_friendly_calls(s, ctx.registry if hasattr(ctx, 'registry') else None)
    for fn_name, fn_min, fn_fmt in math_call_specs(ctx):
        s = replace_math_call(s, fn_name, fn_min, fn_fmt, line_no=line_no)
    s = replace_int_calls(s, ctx, _depth, line_no=line_no)
    s = replace_diff_calls(s, ctx, _depth, line_no=line_no)
    s = replace_cases_call(s, ctx, _depth, line_no=line_no)
    s = replace_det_calls(s, ctx, _depth, line_no=line_no)
    s = replace_set_calls(s, ctx, _depth, line_no=line_no)
    s = replace_align_calls(s, ctx, _depth, line_no=line_no)
    s = replace_vec_calls(s, ctx, line_no=line_no, _depth=_depth)
    s = re.sub(r'\$([^$]+)\$', r'\1', s)
    # Escape thousands commas (100,000 -> 100\,000) so Typst does not
    # read them as argument separators. See escape_number_commas.
    s = escape_number_commas(s)
    # Split bare multi-letter identifiers (MD -> M D) so Typst does not
    # abort with "unknown variable: MD". See space_out_bare_identifiers.
    s = space_out_bare_identifiers(s)
    if ctx.mult_sym != '*':
        # Protect quoted strings and *command( (unknown commands left as
        # text) so '"a*b"' survives; space the operator: 2*3 -> '2 . 3'.
        _prot = {}

        def _pm(m):
            ph = f'\x03{len(_prot)}\x04'
            _prot[ph] = m.group(0)
            return ph

        s = re.sub(r'"[^"]*"', _pm, s)
        s = re.sub(r'\*[A-Za-z][A-Za-z0-9_\-]*\s*\(', _pm, s)
        s = re.sub(r'\s*\*\s*', f' {ctx.mult_sym} ', s)
        for ph, orig in _prot.items():
            s = s.replace(ph, orig)
    return s


def math_call_specs(ctx):
    """List of ``(name, min_args, renderer)`` for every math command.

    Each renderer receives the already-cleaned argument strings and
    returns Typst math markup. Commands not in this list are handled by
    dedicated ``replace_*_calls`` functions (det, set, align, vec,
    int, diff, cases, matrix, table).
    """
    specs = []
    reg = getattr(ctx, 'registry', None)
    if reg is None:
        reg = DEFAULT_REGISTRY
    for cmd_spec in reg.template_specs():
        spec = cmd_spec

        def formatter(args, spec=spec):
            return render_spec(spec, ctx, args)

        specs.append((spec.name, spec.args, formatter))
    # pow keeps its Python formatting helper.
    specs.append(('pow', 2, lambda args: _format_pow(ctx, args)))
    return specs


def _format_int(ctx, name, args):
    """Typst for *int/*oint (1-4 args, friendly ;/, separators).

    - 1 arg: indefinite ``*int(expr)`` -> ``$integral expr$``
    - 2 args: indefinite with differential ``*int(expr ; x)``
    - 3 args: definite ``*int(lo ; hi ; expr)``
    - 4 args: definite with differential ``*int(lo ; hi ; expr ; x)``
    ``*oint`` uses ``integral.cont`` (Typst has no bare ``oint``).
    """
    base = 'integral.cont' if name == 'oint' else 'integral'
    if len(args) == 1:
        return f"${base} {clean_inner_math(ctx, args[0])}$"
    if len(args) == 2:
        return (f"${base} {clean_inner_math(ctx, args[0])} "
                f"dif {clean_inner_math(ctx, args[1])}$")
    if len(args) == 3:
        return (f"${base}_({clean_inner_math(ctx, args[0])})^"
                f"({clean_inner_math(ctx, args[1])}) "
                f"{clean_inner_math(ctx, args[2])}$")
    # len == 4 (caller caps extras to 4)
    return (f"${base}_({clean_inner_math(ctx, args[0])})^"
            f"({clean_inner_math(ctx, args[1])}) "
            f"{clean_inner_math(ctx, args[2])} "
            f"dif {clean_inner_math(ctx, args[3])}$")


def _replace_single_int(text, ctx, name, _depth=0, line_no=None):
    """Replace one of *int/*oint (variable 1-4 arity)."""
    pattern = re.compile(r'\*' + re.escape(name) + r'\s*\(')
    pos = 0
    out = []
    while True:
        match = pattern.search(text, pos)
        if not match:
            out.append(text[pos:])
            break
        out.append(text[pos:match.start()])
        start = match.end()
        depth = 1
        i = start
        in_quote = False
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '"' and (i == 0 or text[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            report(
                'Warning', line_no,
                f'unclosed *{name}(... — missing closing parenthesis')
            out.append(text[match.start():match.end()])
            pos = match.end()
            continue
        args = split_top_level_args(text[start:i - 1])
        if len(args) < 1 or any(a == '' for a in args[:1]):
            report(
                'Warning', line_no,
                f'*{name}(...) has empty argument(s) — leaving as-is')
            out.append(text[match.start():i])
        elif len(args) == 0:
            report(
                'Warning', line_no,
                f'*{name}(...) expects 1 argument(s), got 0 — leaving as-is')
            out.append(text[match.start():i])
        elif any(a == '' for a in args):
            report(
                'Warning', line_no,
                f'*{name}(...) has empty argument(s) — leaving as-is')
            out.append(text[match.start():i])
        else:
            if len(args) > 4:
                report(
                    'Warning', line_no,
                    f'*{name}(...) expects 4 argument(s), '
                    f'got {len(args)} — extra arguments ignored')
                args = args[:4]
            out.append(_format_int(ctx, name, args))
        pos = i
    return ''.join(out)


def replace_int_calls(text, ctx, _depth=0, line_no=None):
    """Expand *int/*oint (variable arity) for text/math/nested paths."""
    if _depth > 20:
        report('Warning', line_no,
               '*int(...) nested too deep — leaving as-is')
        return text
    # *integral( is normalized to *int( by normalize_friendly_calls, but
    # run it here too so direct calls without the outer pass still work.
    text = normalize_friendly_calls(text, ctx.registry if hasattr(ctx, 'registry') else None)
    for name in ('int', 'oint'):
        text = _replace_single_int(text, ctx, name, _depth,
                                    line_no=line_no)
    return text


def _format_diff(ctx, name, args):
    """Typst for *diff/*pdiff (2-3 args, friendly ;/, separators).

    - 2 args: ``*diff(f ; x)`` -> ``$frac(dif f, dif x)$`` (Leibniz
      notation with Typst's upright differential ``dif``).
    - 3 args: ``*diff(f ; x ; n)`` -> ``$frac(dif^n f, dif x^n)$``.
    ``*pdiff`` uses ``partial`` (Typst ``partial``, renders ∂) with
    the same 2-3 arguments.
    """
    base = 'partial' if name == 'pdiff' else 'dif'
    if len(args) == 2:
        return (f"$frac({base} {clean_inner_math(ctx, args[0])}, "
                f"{base} {clean_inner_math(ctx, args[1])})$")
    # len == 3 (caller caps extras to 3)
    order = clean_inner_math(ctx, args[2])
    return (f"$frac({base}^{order} {clean_inner_math(ctx, args[0])}, "
            f"{base} {clean_inner_math(ctx, args[1])}^{order})$")


def _replace_single_diff(text, ctx, name, _depth=0, line_no=None):
    """Replace one of *diff/*pdiff (variable 2-3 arity)."""
    pattern = re.compile(r'\*' + re.escape(name) + r'\s*\(')
    pos = 0
    out = []
    while True:
        match = pattern.search(text, pos)
        if not match:
            out.append(text[pos:])
            break
        out.append(text[pos:match.start()])
        start = match.end()
        depth = 1
        i = start
        in_quote = False
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '"' and (i == 0 or text[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            report(
                'Warning', line_no,
                f'unclosed *{name}(... — missing closing parenthesis')
            out.append(text[match.start():match.end()])
            pos = match.end()
            continue
        args = split_top_level_args(text[start:i - 1])
        if len(args) < 2 or any(a == '' for a in args[:2]):
            report(
                'Warning', line_no,
                f'*{name}(...) expects 2 argument(s), '
                f'got {len(args)} — leaving as-is')
            out.append(text[match.start():i])
        elif any(a == '' for a in args):
            report(
                'Warning', line_no,
                f'*{name}(...) has empty argument(s) — leaving as-is')
            out.append(text[match.start():i])
        else:
            if len(args) > 3:
                report(
                    'Warning', line_no,
                    f'*{name}(...) expects 3 argument(s), '
                    f'got {len(args)} — extra arguments ignored')
                args = args[:3]
            out.append(_format_diff(ctx, name, args))
        pos = i
    return ''.join(out)


def replace_diff_calls(text, ctx, _depth=0, line_no=None):
    """Expand *diff/*pdiff (variable arity) for text/math/nested paths."""
    if _depth > 20:
        report('Warning', line_no,
               '*diff(...) nested too deep — leaving as-is')
        return text
    for name in ('diff', 'pdiff'):
        text = _replace_single_diff(text, ctx, name, _depth,
                                    line_no=line_no)
    return text


def replace_cases_call(text, ctx, _depth=0, line_no=None):
    """Expand *cases(row1 | row2 | ...) to Typst cases(...).

    Rows split on top-level ``|`` with the same quote/nesting rules as
    *matrix rows (via tables.split_rows_top_level). Inside a row, a
    depth-0 ``;`` (same rules as *matrix cells, via
    tables.split_cells_top_level, friendly ``,`` when no ``;``) splits
    value/condition cells, emitted with Typst ``&`` alignment
    (``$cases(x & x > 0, 0 & x <= 0)$``). Single-cell rows emit as-is,
    so the existing ``|``-only and block forms are unchanged. Empty
    rows are dropped (like tables); empty cells or fully-empty calls
    warn and stay as-is.
    """
    from . import tables as _tables
    if _depth > 20:
        report('Warning', line_no,
               '*cases(...) nested too deep — leaving as-is')
        return text
    pattern = re.compile(r'\*cases\s*\(')
    pos = 0
    out = []
    while True:
        match = pattern.search(text, pos)
        if not match:
            out.append(text[pos:])
            break
        out.append(text[pos:match.start()])
        start = match.end()
        depth = 1
        i = start
        in_quote = False
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '"' and (i == 0 or text[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            report(
                'Warning', line_no,
                'unclosed *cases(... — missing closing parenthesis')
            out.append(text[match.start():match.end()])
            pos = match.end()
            continue
        inner_raw = text[start:i - 1]
        rows_raw = _tables.split_rows_top_level(inner_raw)
        rows = [r.strip() for r in rows_raw if r.strip() != '']
        if not rows:
            report(
                'Warning', line_no,
                '*cases(...) is empty — leaving as-is')
            out.append(text[match.start():i])
            pos = i
            continue
        if any(r == '' for r in rows):
            report(
                'Warning', line_no,
                '*cases(...) has empty argument(s) — leaving as-is')
            out.append(text[match.start():i])
            pos = i
            continue
        rendered = []
        broken = False
        for r in rows:
            cells = _tables.split_cells_top_level(r)
            if any(c == '' for c in cells):
                report(
                    'Warning', line_no,
                    '*cases(...) has empty cell(s) — leaving as-is')
                out.append(text[match.start():i])
                broken = True
                break
            cleaned_cells = [clean_inner_math(ctx, c, line_no=line_no)
                             for c in cells]
            rendered.append(' & '.join(cleaned_cells))
        if broken:
            pos = i
            continue
        out.append(f"$cases({', '.join(rendered)})$")
        pos = i
    return ''.join(out)


def _render_det_grid(ctx, grid_raw, line_no=None):
    """Render a raw det grid to Typst ``mat(delim: "|", ...)`` (no $).

    Returns None when the grid is empty (caller leaves input as-is).
    Ragged rows are padded with 0 (warning), like *matrix. Nested
    tables warn like matrix cells do.
    """
    kept = [r for r in grid_raw if any(c.strip() for c in r)]
    if not kept:
        report(
            'Warning', line_no,
            '*det(...) is empty — leaving as-is')
        return None
    widths = [len(r) for r in kept]
    ncols = max(widths)
    if len(set(widths)) != 1:
        report(
            'Warning', line_no,
            f'*det(...) rows have different lengths {widths} — '
            f'padding to {ncols} column(s)')
        kept = [r + [''] * (ncols - len(r)) for r in kept]
    rendered = []
    for row in kept:
        r_out = []
        for cell_raw in row:
            if not cell_raw.strip():
                r_out.append('')
                continue
            if re.search(r'\*(table|matrix|mat)\s*\(', cell_raw):
                report(
                    'Warning', line_no,
                    '*det(...) cell contains a nested '
                    'table/matrix — only math commands are supported '
                    'inside determinants')
            r_out.append(clean_inner_math(ctx, cell_raw, line_no=line_no))
        rendered.append(r_out)
    inner = '; '.join(
        ', '.join(c if c.strip() else '0' for c in row) for row in rendered
    )
    # Empty matrix cells have no sensible math value; '0' keeps Typst
    # compiling instead of aborting the whole PDF (same as *matrix).
    return f'mat(delim: "|", {inner})'


def _det_matrix_arg_inner(inner_raw):
    """Inner grid text when *inner_raw* is one matrix, else None.

    Accepts both the source form ``*matrix(...)``/``*mat(...)`` (seen
    on the nested clean_inner_math path) and the already-expanded
    Typst form ``$mat(...)$`` (the text pipeline expands tables
    before math commands run).
    """
    stripped = inner_raw.strip()
    if stripped.startswith('$') and stripped.endswith('$') and len(stripped) >= 2:
        # Accept the already-expanded Typst form ``$mat(...)$`` (the
        # text pipeline expands tables before math commands run).
        # Depth-aware, not greedy: ``*det($mat(a)$ $mat(b)$)`` must not
        # swallow across spans.
        inner = stripped[1:-1]
        mm = re.match(r'mat\s*\(', inner)
        if mm:
            depth = 1
            j = mm.end()
            in_q = False
            while j < len(inner) and depth:
                ch = inner[j]
                if ch == '"' and (j == 0 or inner[j - 1] != '\\'):
                    in_q = not in_q
                elif not in_q:
                    if ch == '(':
                        depth += 1
                    elif ch == ')':
                        depth -= 1
                j += 1
            if depth == 0 and j == len(inner):
                return ('typst', inner)
    m = re.match(r'\*(matrix|mat)\s*\(', stripped)
    if not m:
        return None
    depth = 1
    i = m.end()
    in_quote = False
    while i < len(stripped) and depth > 0:
        ch = stripped[i]
        if ch == '"' and (i == 0 or stripped[i - 1] != '\\'):
            in_quote = not in_quote
        elif not in_quote:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
        i += 1
    if depth != 0 or stripped[i:].strip():
        return None
    return ('ezmath', stripped[m.end():i - 1])


def replace_det_calls(text, ctx, _depth=0, line_no=None):
    """Expand *det(...) to a vertical-bar determinant.

    Emits Typst ``$mat(delim: "|", ...)$`` (real vertical bars, not a
    ``det`` word). Accepts either a single ``*matrix(...)`` argument
    or the same row/cell syntax as *matrix (``|`` rows, ``;`` or
    friendly ``,`` cells). Ragged rows pad with 0 (warning); empty
    calls warn and stay as-is. Warnings carry the *line_no* of the
    line being rendered when one is known.
    """
    from . import tables as _tables
    if _depth > 20:
        report('Warning', line_no,
               '*det(...) nested too deep — leaving as-is')
        return text
    pattern = re.compile(r'\*det\s*\(')
    pos = 0
    out = []
    while True:
        match = pattern.search(text, pos)
        if not match:
            out.append(text[pos:])
            break
        out.append(text[pos:match.start()])
        start = match.end()
        depth = 1
        i = start
        in_quote = False
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '"' and (i == 0 or text[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            report(
                'Warning', line_no,
                'unclosed *det(... — missing closing parenthesis')
            out.append(text[match.start():match.end()])
            pos = match.end()
            continue
        inner_raw = text[start:i - 1]
        mat_arg = _det_matrix_arg_inner(inner_raw)
        if mat_arg is not None:
            kind, mat_inner = mat_arg
            if kind == 'typst':
                # Already-expanded $mat(...)$: splice in the "|"
                # delimiter (cells are rendered Typst already).
                out.append(f'$mat(delim: "|", {mat_inner[4:]})$')
                pos = i
                continue
            grid_raw = _tables.parse_grid(mat_inner)
        else:
            grid_raw = _tables.parse_grid(inner_raw)
        rendered = _render_det_grid(ctx, grid_raw, line_no=line_no)
        if rendered is None:
            out.append(text[match.start():i])
            pos = i
            continue
        out.append(f'${rendered}$')
        pos = i
    return ''.join(out)


def replace_set_calls(text, ctx, _depth=0, line_no=None):
    """Expand *set(...) to ``{x | condition}`` or ``{a, b, c}``.

    The rule is by separator (documented in docs/algebra.md): when
    ``;`` separates at depth 0, two arguments mean set-builder
    ``*set(x ; condition)`` -> ``$ {x | condition} $``; any other
    count is a listing (one argument is a singleton). Without ``;``,
    comma-separated arguments are always a listing — so two-element
    listings are written ``*set(a, b)`` while ``*set(a ; b)`` stays
    set-builder. Conditions containing ``;`` can be quoted
    (``*set(x ; "a;b")``).
    """
    if _depth > 20:
        report('Warning', line_no,
               '*set(...) nested too deep — leaving as-is')
        return text
    pattern = re.compile(r'\*set\s*\(')
    pos = 0
    out = []
    while True:
        match = pattern.search(text, pos)
        if not match:
            out.append(text[pos:])
            break
        out.append(text[pos:match.start()])
        start = match.end()
        depth = 1
        i = start
        in_quote = False
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '"' and (i == 0 or text[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            report(
                'Warning', line_no,
                'unclosed *set(... — missing closing parenthesis')
            out.append(text[match.start():match.end()])
            pos = match.end()
            continue
        inner_raw = text[start:i - 1]
        args = split_top_level_args(inner_raw)
        if not args or any(a == '' for a in args):
            report(
                'Warning', line_no,
                '*set(...) has empty argument(s) — leaving as-is')
            out.append(text[match.start():i])
            pos = i
            continue
        if len(args) == 2 and _has_top_level_semi(inner_raw):
            elem = clean_inner_math(ctx, args[0], line_no=line_no)
            cond = clean_inner_math(ctx, args[1], line_no=line_no)
            out.append(f'$ {{{elem} | {cond}}} $')
        else:
            cells = [clean_inner_math(ctx, a, line_no=line_no) for a in args]
            out.append(f"$ {{{', '.join(cells)}}} $")
        pos = i
    return ''.join(out)


def _split_first_eq(s):
    """Split *s* at the first depth-0 ``=`` (quote-aware).

    Returns (left, right), or (s, None) when there is no top-level
    ``=``. Depth tracks ()/ {}/[] so ``*sum(i = 1 ; n ; i) = x``
    aligns at the outer ``=`` only.
    """
    dp = db = br = 0
    in_quote = False
    for idx, ch in enumerate(s):
        if ch == '"' and (idx == 0 or s[idx - 1] != '\\'):
            in_quote = not in_quote
            continue
        if in_quote:
            continue
        if ch == '(':
            dp += 1
        elif ch == ')' and dp > 0:
            dp -= 1
        elif ch == '{':
            db += 1
        elif ch == '}' and db > 0:
            db -= 1
        elif ch == '[':
            br += 1
        elif ch == ']' and br > 0:
            br -= 1
        elif ch == '=' and dp == 0 and db == 0 and br == 0:
            return s[:idx], s[idx + 1:]
    return s, None


def replace_align_calls(text, ctx, _depth=0, line_no=None):
    """Expand *align(...) to equations aligned at ``=``.

    Rows split on top-level ``|`` with the same quote/nesting rules
    as *matrix rows, and the multiline block form works exactly like
    *cases (lines joined with ``|``). Each row is cleaned first (so
    ``==`` becomes ``=``), then split at its first depth-0 ``=`` and
    emitted with the Typst ``&=`` alignment marker and single-``\\``
    row breaks (``$ x &= 1 \\ y &= 2 $``). Rows without ``=`` are
    emitted as-is and never crash the build; only the first ``=``
    aligns, the rest stay literal.
    """
    from . import tables as _tables
    if _depth > 20:
        report('Warning', line_no,
               '*align(...) nested too deep — leaving as-is')
        return text
    pattern = re.compile(r'\*align\s*\(')
    pos = 0
    out = []
    while True:
        match = pattern.search(text, pos)
        if not match:
            out.append(text[pos:])
            break
        out.append(text[pos:match.start()])
        start = match.end()
        depth = 1
        i = start
        in_quote = False
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '"' and (i == 0 or text[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            report(
                'Warning', line_no,
                'unclosed *align(... — missing closing parenthesis')
            out.append(text[match.start():match.end()])
            pos = match.end()
            continue
        inner_raw = text[start:i - 1]
        rows_raw = _tables.split_rows_top_level(inner_raw)
        rows = [r.strip() for r in rows_raw if r.strip() != '']
        if not rows:
            report(
                'Warning', line_no,
                '*align(...) is empty — leaving as-is')
            out.append(text[match.start():i])
            pos = i
            continue
        rendered = []
        for r in rows:
            cleaned = clean_inner_math(ctx, r, line_no=line_no)
            left, right = _split_first_eq(cleaned)
            if right is None:
                rendered.append(cleaned)
            else:
                rendered.append(f'{left.strip()} &= {right.strip()}')
        out.append(f"$ {' \\ '.join(rendered)} $")
        pos = i
    return ''.join(out)


def replace_vec_calls(text, ctx, line_no=None, _depth=0):
    """Expand *vec(...) to a Typst math column vector.

    Components split with the same friendly rule as *matrix cells: a
    depth-0 ";" separates them ("," works when no ";" is present, so
    ``*vec(100,000 ; 2)`` keeps ``100,000`` intact). At least 2
    components are required — ``*vec(x1 ; x2 [; x3 ...])`` emits
    ``$vec(x1, x2, ...)$`` (Typst column vector, any height >= 2).
    Variables, calc() and nested math commands work inside components
    (via clean_inner_math), so *vec nests inside \\ ... \\ math,
    *matrix/*det cells and other math commands like the rest.
    Empty calls, empty components or a single component warn (with
    *line_no* when known) and stay as-is.
    """
    if _depth > 20:
        report('Warning', line_no,
               '*vec(...) nested too deep — leaving as-is')
        return text
    pattern = re.compile(r'\*vec\s*\(')
    pos = 0
    out = []
    while True:
        match = pattern.search(text, pos)
        if not match:
            out.append(text[pos:])
            break
        out.append(text[pos:match.start()])
        start = match.end()
        depth = 1
        i = start
        in_quote = False
        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '"' and (i == 0 or text[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            report(
                'Warning', line_no,
                'unclosed *vec(... — missing closing parenthesis')
            out.append(text[match.start():match.end()])
            pos = match.end()
            continue
        inner_raw = text[start:i - 1]
        args = split_top_level_args(inner_raw)
        if len(args) < 2:
            report(
                'Warning', line_no,
                f'*vec(...) expects at least 2 components, '
                f'got {len(args)} — leaving as-is')
            out.append(text[match.start():i])
            pos = i
            continue
        if any(a == '' for a in args):
            report(
                'Warning', line_no,
                f'*vec(...) has empty component(s) — '
                f'leaving as-is')
            out.append(text[match.start():i])
            pos = i
            continue
        rendered = [clean_inner_math(ctx, a, line_no=line_no)
                     for a in args]
        out.append(f"$vec({', '.join(rendered)})$")
        pos = i
    return ''.join(out)


def group_power_base(ctx, s):
    """Prepare the base of a power expression for Typst.

    Wraps compound bases (``x + 1``, ``a / b``) in parentheses so
    ``*pow(x + 1, 2)`` renders as ``(x + 1)^2`` rather than
    ``x + 1^2``. Word-internal hyphens (``foo-bar``) are not treated as
    operators. Returns the possibly-wrapped base string.
    """
    s = clean_inner_math(ctx, s)
    # Wrap compound bases in parens. A word-internal hyphen (foo-bar)
    # is not an operator; require spacing or non-word context for '-',
    # while '+', '*', '/' anywhere indicate a compound expression.
    has_spaced_op = bool(re.search(r'\s[+\-*/]\s', s))
    has_plus_star_slash = bool(re.search(r'[+*/]', s))
    has_minus_op = bool(
        re.search(r'(?<![A-Za-z0-9_])-(?![A-Za-z0-9_])', s)
        or re.search(r'(?<=\d)-(?=\d)', s)
        or re.search(r'\s-\s', s)
    )
    if (has_spaced_op or has_plus_star_slash or has_minus_op) and not (
        s.startswith('(') and s.endswith(')') and _outer_parens_balanced(s)
    ):
        return f'({s})'
    return s


def _outer_parens_balanced(s):
    """True when the outer (...) wraps the whole string."""
    if not (s.startswith('(') and s.endswith(')')):
        return False
    depth = 0
    for i, ch in enumerate(s):
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
            if depth == 0 and i != len(s) - 1:
                return False
    return depth == 0


def _format_pow(ctx, args, line_no=None):
    base = group_power_base(ctx, args[0])
    exp = clean_inner_math(ctx, args[1], line_no=line_no)
    # *pow(A ; *degree) means A° per spec, not A^(°).
    if exp == '°':
        return f'${base}°$'
    if not exp.strip():
        report(
            'Warning', line_no,
            '*pow(...) has empty exponent — emitting base only')
        return f'${base}$'
    return f'${base}^({exp})$'
