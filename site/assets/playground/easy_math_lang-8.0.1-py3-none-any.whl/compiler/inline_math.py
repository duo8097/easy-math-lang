"""Inline math mode: \\ ... \\  ->  Typst $ ... $.

Structural scanner (not a global string replace). Rules:

- ``\\\\`` is an escaped literal backslash and never toggles math mode.
- An unescaped ``\\`` toggles math mode (open -> close -> open ...).
- Whitespace just inside the delimiters is trimmed.
- Content is processed with the existing pipeline pieces (vars/defines
  are applied by the caller beforehand or inside; math commands,
  ``*pi``/``*infinity`` and ``replace_symbol_shortcuts`` are applied
  inside so ASCII/shortcut syntax keeps working).
- Empty ``\\ \\`` warns and emits nothing.
"""

import re
import sys

from .diagnostics import report

BS_PLACEHOLDER = '\x0600\x06'


def mask_escaped(text):
    """Replace ``\\\\`` runs with placeholders so they never toggle math."""
    return text.replace('\\\\', BS_PLACEHOLDER)


def unmask_escaped(text):
    """Restore literal backslashes (Typst-escaped)."""
    return text.replace(BS_PLACEHOLDER, '\\\\')


def find_unescaped(text):
    """Positions of unescaped ``\\`` in text (``\\\\`` ignored).

    Escape-aware scan on the raw string so returned offsets are valid
    for slicing *text* (older masked-regex version returned shifted
    offsets whenever ``\\\\`` appeared before a delimiter).
    """
    positions = []
    i, n = 0, len(text)
    while i < n:
        if text[i] == '\\':
            if i + 1 < n and text[i + 1] == '\\':
                i += 2
                continue
            positions.append(i)
        i += 1
    return positions


def split_first_pair(text):
    """Split ``head \\ inner \\ tail`` on the first balanced pair.

    Returns (head, inner, tail) or None when there is no closing
    delimiter. ``\\\\`` sequences never count as delimiters.
    """
    return _split_raw(text)


def _split_raw(text):
    """Escape-aware first-pair split on the raw string."""
    i, n = 0, len(text)
    # find opening unescaped backslash
    open_idx = -1
    while i < n:
        if text[i] == '\\':
            if i + 1 < n and text[i + 1] == '\\':
                i += 2
                continue
            open_idx = i
            break
        i += 1
    if open_idx == -1:
        return None
    j = open_idx + 1
    while j < n:
        if text[j] == '\\':
            if j + 1 < n and text[j + 1] == '\\':
                j += 2
                continue
            return text[:open_idx], text[open_idx + 1:j], text[j + 1:]
        j += 1
    return None


def process_math_inner(ctx, inner_raw, line_no=None):
    """Convert raw math content to Typst ``$...$`` (no surrounding text).

    Applies math commands, ``*pi``/``*infinity`` and the existing
    symbol-shortcut table (source of truth stays in ``symbols.py``).
    Returns the wrapped string, or '' for empty content (with warning).
    """
    from .diagnostics import warn_unknown_commands
    from .math_commands import (
        clean_inner_math,
        math_call_specs,
        normalize_friendly_calls,
        replace_align_calls,
        replace_cases_call,
        replace_det_calls,
        replace_diff_calls,
        replace_int_calls,
        replace_math_call,
        replace_set_calls,
        replace_vec_calls,
        space_out_bare_identifiers,
    )
    from .symbols import replace_symbol_shortcuts

    inner = inner_raw.strip()
    if not inner:
        if line_no is not None:
            report(
                'WARNING', line_no,
                'empty math expression '
                '\\ \\ — emitting nothing.')
        else:
            report(
                'WARNING', None,
                'empty math expression \\ \\ — emitting nothing.')
        return ''
    # Protect literal \\ so it never toggles math and survives Typst.
    inner = inner.replace('\\\\', BS_PLACEHOLDER)
    # Matrices work inside \ ... \ too (tables do not — text mode only).
    if re.search(r'\*(matrix|mat)\s*\(', inner):
        inner = _expand_matrices_in_math(ctx, inner, line_no)
    if re.search(r'\*table\s*\(', inner):
        report(
            'Warning', line_no,
            '*table(...) is text mode and '
            'cannot be used inside math \\ ... \\ — leaving as-is')
    if re.search(r'\*image\s*\(', inner):
        report(
            'Warning', line_no,
            '*image(...) is text mode (image file) '
            'and cannot be used inside math \\ ... \\ — leaving as-is')
    if re.search(
        r'(?<![A-Za-z0-9_*\\])\*(newpage|pagebreak)(?![A-Za-z0-9_\-])',
        inner,
    ):
        report(
            'Warning', line_no,
            '*newpage/*pagebreak is text mode '
            'and cannot be used inside math \\ ... \\ — leaving as-is')
    inner = normalize_friendly_calls(inner, ctx.registry)
    from .text_commands import normalize_text_aliases, replace_styling_calls
    inner = normalize_text_aliases(inner)
    # Text styling compiles inside math too (Typst accepts
    # #strong/#emph/#underline in equations); page breaks and images
    # stay text-mode-only (warned above).
    inner = replace_styling_calls(
        inner, ctx, line_no,
        lambda arg: clean_inner_math(ctx, arg, line_no=line_no),
    )
    for fn_name, fn_min, fn_fmt in math_call_specs(ctx):
        inner = replace_math_call(inner, fn_name, fn_min, fn_fmt, line_no=line_no)
    inner = replace_int_calls(inner, ctx, line_no=line_no)
    inner = replace_diff_calls(inner, ctx, line_no=line_no)
    inner = replace_cases_call(inner, ctx, line_no=line_no)
    inner = replace_det_calls(inner, ctx, line_no=line_no)
    inner = replace_set_calls(inner, ctx, line_no=line_no)
    inner = replace_align_calls(inner, ctx, line_no=line_no)
    inner = replace_vec_calls(inner, ctx, line_no)
    if line_no is not None:
        # Unknown *cmd(...) inside math never reaches the text-pass
        # warning (it is hidden behind a math placeholder by then).
        warn_unknown_commands(inner, line_no, ctx.registry)
    inner = re.sub(r'\*pi\b', '$pi$', inner)
    inner = re.sub(r'\*infinity\b', '$infinity$', inner)
    # Strip the temporary $ wrappers from *pi so the outer wrap stays clean:
    # '$pi$' inside becomes 'pi' inside the final '$...$'.
    inner = inner.replace('$pi$', 'pi').replace('$infinity$', 'infinity')
    inner = replace_symbol_shortcuts(inner)
    # Apply custom multiplication symbol inside math for consistency
    # with text mode (text '2 * 3' -> '2 . 3' must match '\ 2 * 3 \').
    if ctx.mult_sym != '*':
        _prot = {}

        def _pm(m):
            ph = f'\x03{len(_prot)}\x04'
            _prot[ph] = m.group(0)
            return ph

        inner = re.sub(r'"[^"]*"', _pm, inner)
        inner = re.sub(r'\*[A-Za-z][A-Za-z0-9_\-]*\s*\(', _pm, inner)
        inner = re.sub(r'\s*\*\s*', f' {ctx.mult_sym} ', inner)
        for ph, orig in _prot.items():
            inner = inner.replace(ph, orig)
    # Literal \\ inside math must not emit Typst '\\' (line break).
    # Emit a quoted backslash string so it renders as a backslash.
    inner = inner.replace(BS_PLACEHOLDER, '"\\\\"')
    # Math-call formatters already return $...$; unwrap nested wrappers
    # so \ *frac(1;2) \ becomes $frac(1, 2)$, not $$frac(1, 2)$$.
    inner = re.sub(r'\$([^$]+)\$', r'\1', inner)
    # Bare multi-letter words (MD, ABC) are unknown variables in Typst
    # and abort the build; split to implicit products (M D, A B C).
    inner = space_out_bare_identifiers(inner)
    return f'${inner}$'


def _expand_matrices_in_math(ctx, text, line_no):
    """Expand *matrix/*mat inside \\ ... \\ to Typst mat(...) (no $)."""
    from .math_commands import clean_inner_math
    from . import tables as _tables

    pos = 0
    out = []
    while True:
        found = _tables.find_next_call(text, pos)
        if not found:
            out.append(text[pos:])
            break
        if found[0] == 'unclosed':
            _, name, call_start, inner_start, _, _ = found
            # Only matrices are expanded here; tables warn upstream.
            if name in ('matrix', 'mat'):
                report(
                    'Warning', line_no,
                    f'unclosed *{name}(... — '
                    f'missing closing parenthesis')
            out.append(text[pos:inner_start])
            pos = inner_start
            continue
        name, call_start, _s, call_end, inner_raw = found
        if name not in ('matrix', 'mat'):
            # Leave tables/other calls for the caller (tables warn).
            out.append(text[pos:call_end])
            pos = call_end
            continue
        out.append(text[pos:call_start])
        grid_raw = _tables.parse_grid(inner_raw)
        norm = _tables.normalize_grid(grid_raw, line_no, 'matrix')
        if norm is None:
            out.append(text[call_start:call_end])
            pos = call_end
            continue
        rendered = []
        for row in norm:
            r_out = []
            for cell_raw in row:
                if not cell_raw.strip():
                    r_out.append('')
                    continue
                r_out.append(clean_inner_math(ctx, cell_raw, line_no=line_no))
            rendered.append(r_out)
        # No $ wrapper: process_math_inner unwraps $...$ later and adds
        # its own outer $...$, so emit bare mat(...) here.
        out.append(_tables.build_matrix_math_inner(rendered))
        pos = call_end
    return ''.join(out)
