"""Shared mutable state for a single compilation run."""


class CompileContext:
    """Variables, defines and the multiplication display symbol."""

    def __init__(self):
        self.variables = {}
        self.defines = {}
        self.mult_sym = '*'
        try:
            from .command_registry import DEFAULT_REGISTRY
            self.registry = DEFAULT_REGISTRY
        except Exception:  # pragma: no cover - defensive
            self.registry = None
        self._mod_template_depth = 0
        self._mod_expansion_count = 0
        self._mod_expanded_chars = 0
        self._mod_expansion_aborted = False
        # Absolute .eml path for SourceSpans (set per compile_ezmath run).
        self.source_file = ''
        # Original .ezmath source, one entry per line (no newlines), and
        # the filename to show in diagnostic context blocks. Set per
        # compile_ezmath run; the diagnostics helper reads them for the
        # source-line preview under each diagnostic. Empty when the
        # context is created outside a compile.
        self.source_lines = []
        self.source_name = ''
        # Document title set via *doc_title(...) (control line, consumed).
        # Stored raw and rendered at codegen so forward-referenced
        # variables still resolve. None means "use the default title".
        self.doc_title_raw = None
        self.doc_title_line = None
        # Document font set via *doc_font(...) (control line, consumed).
        # Family/size strings, or None for the Typst default (12pt).
        self.doc_font_family = None
        self.doc_font_size = None
        # Function-plot output (set by compile_ezmath before the line
        # loop; *_render_text_line* generates SVGs next to the .typ).
        self.plot_dir = None
        self.plot_stem = 'doc'
        self.plot_index = 0
        # Image files used via *image(...) as (abs_path, typ_relpath)
        # pairs (set during the line loop; typ/html exports to other
        # directories copy them along like plot sidecars).
        self.image_files = []
