"""Comment stripping (// comments, with URL protection)."""

import re

from .inline_math import find_unescaped


def split_lines(text):
    """Split *text* like LSP clients split a document.

    ``str.splitlines()`` also splits on VT/FF/FS/GS/RS/US/NEL and the
    Unicode line separators, which would invent lines that do not exist
    in the client's view of the file and shift every diagnostic after
    them. LSP clients split on \\r\\n, \\r and \\n only, so we normalize
    and split on \\n — keeping compiler output and editor positions in
    agreement.
    """
    return text.replace('\r\n', '\n').replace('\r', '\n').split('\n')


def _math_ranges(line_prot):
    """Ranges covered by ``\\ ... \\`` math on one line (never comments).

    Balanced pairs protect the whole ``\\...\\`` span; a trailing
    unclosed opener (multiline math) protects through end of line,
    mirroring the pipeline's buffering.
    """
    positions = find_unescaped(line_prot)
    ranges = []
    for i in range(0, len(positions) - 1, 2):
        ranges.append((positions[i], positions[i + 1] + 1))
    if len(positions) % 2 == 1:
        ranges.append((positions[-1], len(line_prot)))
    return ranges


def _balanced_spans(line, opener):
    """Yield (start, end) spans of balanced opener(...) on one line."""
    pat_len = len(opener)
    pos = 0
    while True:
        s = line.find(opener, pos)
        if s == -1:
            return
        # calc( inside mycalc( is not a call; skip it.
        if opener == 'calc(' and s > 0 and (line[s - 1].isalnum() or line[s - 1] == '_'):
            pos = s + pat_len
            continue
        depth = 1
        i = s + pat_len
        in_quote = False
        while i < len(line) and depth > 0:
            ch = line[i]
            if ch == '"' and (i == 0 or line[i - 1] != '\\'):
                in_quote = not in_quote
            elif not in_quote:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
            i += 1
        if depth != 0:
            # Unclosed opener: skip it and continue so later balanced
            # spans on the same line are still protected.
            pos = s + pat_len
            continue
        yield (s, i)
        pos = i


def _is_escaped_bs(line, i):
    """True when line[i] is preceded by an odd number of backslashes."""
    n = 0
    j = i - 1
    while j >= 0 and line[j] == '\\':
        n += 1
        j -= 1
    return n % 2 == 1


def _quote_ranges(line):
    """Ranges covered by double-quoted strings (never comments).

    An unterminated string protects through end of line, mirroring
    the rest of the compiler's handling of unterminated constructs.
    """
    ranges = []
    start = None
    i = 0
    while i < len(line):
        ch = line[i]
        if ch == '"' and not _is_escaped_bs(line, i):
            if start is None:
                start = i
            else:
                ranges.append((start, i + 1))
                start = None
        i += 1
    if start is not None:
        ranges.append((start, len(line)))
    return ranges


def _protected_ranges(line):
    """Ranges where // must not start a comment.

    Covers calc(...), *p(...), any other balanced *command(...) span,
    while \\...\\ math is handled separately in strip_comments.
    """
    ranges = []
    for opener in ('calc(', '*p(', '*calc('):
        ranges.extend(_balanced_spans(line, opener))
    for m in re.finditer(r'\*[A-Za-z][A-Za-z0-9_\-]*\(', line):
        ranges.extend(_balanced_spans(line, m.group(0)))
    return ranges


def _find_comment_start(line_prot, protected):
    idx = line_prot.find('//')
    while idx != -1:
        if any(s <= idx < e for s, e in protected):
            idx = line_prot.find('//', idx + 2)
            continue
        return idx
    return -1


def strip_comments(text):
    """Remove ``//`` comments from an .ezmath document, protecting URLs,
    math pairs (``\\ ... \\``), quoted strings, and balanced
    ``*command(...)`` spans so a ``//`` inside a URL or math is never
    treated as a comment start. Tracks multiline math across source
    lines. Returns the cleaned text.
    """
    from .statements import _normalize_friendly_statement

    cleaned_lines = []
    in_math = False
    in_fence = False
    for raw_line in split_lines(text):
        if raw_line.strip().startswith('```'):
            in_fence = not in_fence
            cleaned_lines.append(raw_line)
            continue
        if in_fence:
            cleaned_lines.append(raw_line)
            continue
        # Protect full URLs (scheme://host/path...) from // comment
        # stripping — the old scheme-only shield let a later // in the
        # path start a bogus comment (https://example.com/a//b).
        placeholder = '\x00URLSLASH\x00'
        line_prot = re.sub(
            r'([A-Za-z][A-Za-z0-9+.-]*://\S*)',
            lambda m, placeholder=placeholder: m.group(1).replace('/', placeholder),
            raw_line,
        )
        protected = _protected_ranges(line_prot)
        protected.extend(_quote_ranges(line_prot))
        # Track multiline math across source lines. Only actual text
        # delimiters affect state: raw *p(...) and assignment values are
        # consumed before inline math by the document pipeline.
        statement = _normalize_friendly_statement(line_prot.strip())
        control = not in_math and (
            re.match(r'^<[^<>]+>\s*=', statement)
            or re.match(r'^\*?define\s*\(', statement)
            or statement.startswith('*draw('))
        raw_spans = list(_balanced_spans(line_prot, '*p('))
        positions = [] if control else [
            pos for pos in find_unescaped(line_prot)
            if not any(start <= pos < end for start, end in raw_spans)]
        opened = 0 if in_math else None
        for pos in positions:
            if opened is None:
                opened = pos
            else:
                protected.append((opened, pos + 1))
                opened = None
        if opened is not None:
            protected.append((opened, len(line_prot)))
        idx = _find_comment_start(line_prot, protected)
        # A backslash inside a removed comment must not open math on the
        # next line.
        for pos in positions:
            if idx == -1 or pos < idx:
                in_math = not in_math
        if idx != -1:
            line_prot = line_prot[:idx]
        line = line_prot.replace(placeholder, '/')
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)
