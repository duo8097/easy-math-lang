"""Non-modal *draw gallery window (presentational only).

Opened from the Symbol Bar's ``*draw`` button. Lists every geometry
command as a card — thumbnail, syntax, description — with a search box
and group filter. Like ``SymbolBar`` it emits signals and lets the
host window (MainWindow) own insertion:

- ``templateRequested(str entry_id)`` — the card's ``Insert
  example…`` button: the host opens the template window
  (``draw_template.DrawTemplateDialog``) where the example can be
  previewed/edited before it is inserted.
- ``exampleRequested(str)`` — a full ``*draw(...)`` example block to
  insert (the "empty block" action).
- ``commandRequested(str symbol_name)`` — a ``geo-*`` palette id; the
  host runs the existing ``SymbolDialog`` parameter dialog.

Thumbnails come from ``assets/draw_previews/<id>.svg`` rendered with
``QSvgRenderer`` (pre-rendered by ``scripts/build_draw_previews.py`` —
never fetched at runtime). A missing/unreadable file degrades to a
neutral placeholder tile, so the dialog works with zero SVGs present.
Every thumbnail sits on a fixed light tile so it stays legible in dark
mode; the rest of the window follows the app theme like any dialog.

This module is imported lazily on first click (keeps PySide6.QtSvg
and the catalog out of editor startup — see tests/test_lazy_imports).
"""

from __future__ import annotations

import os

from PySide6 import QtCore, QtGui, QtSvg, QtWidgets

from . import i18n
from .icons import SIZE_DIALOG, apply_icon
from .qt_text import install_text_context_menu
from .draw_catalog import CATALOG, GROUPS, CatalogEntry, catalog_entries

#: Source-tree location of the pre-rendered thumbnails.
PREVIEW_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), 'assets', 'draw_previews')

#: Fixed thumbnail tile: light in BOTH themes so figures read on dark.
THUMB_W, THUMB_H = 168, 112
TILE_BG = '#ffffff'
PLACEHOLDER_BG = '#f2f2f2'
PLACEHOLDER_FG = '#b8b8b8'
PLACEHOLDER_BORDER = '#c8c8c8'
CARD_WIDTH = 244
GRID_COLUMNS = 3


def preview_dir() -> str:
    """Directory holding ``<id>.svg`` previews.

    Source tree first (``editor/assets/draw_previews`` next to this
    module), then the PyInstaller bundle layout (``--add-data`` puts
    the files under the bundle root). Returns the first existing
    candidate — none may exist, in which case every card shows the
    placeholder tile.
    """
    candidates = [PREVIEW_DIR]
    try:
        from . import paths
        candidates.append(
            paths.resource_path('editor', 'assets', 'draw_previews'))
    except Exception:  # pragma: no cover - defensive
        pass
    for candidate in candidates:
        if os.path.isdir(candidate):
            return candidate
    return PREVIEW_DIR


def preview_path(entry_id: str) -> str:
    """Absolute path of one thumbnail (may not exist)."""
    return os.path.join(preview_dir(), f'{entry_id}.svg')


# ----------------------------------------------------------------------
# Thumbnail rendering
# ----------------------------------------------------------------------

def _placeholder_pixmap(width: int = THUMB_W,
                        height: int = THUMB_H) -> QtGui.QPixmap:
    """Neutral tile used when an SVG is missing or unreadable."""
    pix = QtGui.QPixmap(width, height)
    pix.fill(QtGui.QColor(PLACEHOLDER_BG))
    painter = QtGui.QPainter(pix)
    try:
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        pen = QtGui.QPen(QtGui.QColor(PLACEHOLDER_BORDER))
        pen.setStyle(QtCore.Qt.DashLine)
        pen.setWidth(1)
        painter.setPen(pen)
        painter.drawRect(4, 4, width - 9, height - 9)
        painter.drawLine(6, 6, width - 7, height - 7)
        painter.drawLine(width - 7, 6, 6, height - 7)
    finally:
        painter.end()
    return pix


def render_thumbnail(entry_id: str, width: int = THUMB_W,
                     height: int = THUMB_H) -> tuple[QtGui.QPixmap, bool]:
    """Render ``<entry_id>.svg`` on a fixed light tile.

    Returns ``(pixmap, has_preview)``; ``has_preview`` is False when
    the file is missing/invalid (a placeholder tile is returned then).
    *width*/*height* size the tile — the gallery cards use the fixed
    168×112 thumbnail, the template window a larger preview of the
    same file.
    """
    path = preview_path(entry_id)
    try:
        renderer = QtSvg.QSvgRenderer(path)
    except Exception:  # unreadable/corrupt file — fall back
        renderer = None
    if renderer is None or not renderer.isValid():
        return _placeholder_pixmap(width, height), False
    pix = QtGui.QPixmap(width, height)
    pix.fill(QtGui.QColor(TILE_BG))
    painter = QtGui.QPainter(pix)
    try:
        # Letterbox: previews vary in aspect (auto-sized pages), the
        # tile is fixed — scale to fit without distortion.
        view = renderer.viewBoxF()
        if view.isValid() and view.width() > 0 and view.height() > 0:
            scale = min(width / view.width(), height / view.height())
            w, h = view.width() * scale, view.height() * scale
            target = QtCore.QRectF((width - w) / 2.0,
                                    (height - h) / 2.0, w, h)
        else:
            target = QtCore.QRectF(0, 0, width, height)
        renderer.render(painter, target)
    finally:
        painter.end()
    return pix, True


# ----------------------------------------------------------------------
# Card
# ----------------------------------------------------------------------

def title_text(entry):
    """Translated card title (command names/syntax stay untouched)."""
    translator = i18n.current_translator()
    key = f'draw.{entry.id}.title'
    return translator.tr(key) if translator.has(key) else entry.title


def description_text(entry):
    """Translated card description."""
    translator = i18n.current_translator()
    key = f'draw.{entry.id}.description'
    return translator.tr(key) if translator.has(key) else entry.description


class DrawCard(QtWidgets.QFrame):
    """One command: thumbnail, syntax, description, two insert buttons."""

    def __init__(self, entry: CatalogEntry, parent=None):
        super().__init__(parent)
        self.entry = entry
        self.setObjectName('draw-card')
        self.setProperty('entry-id', entry.id)
        self.setProperty('group', entry.group)
        self.setMinimumWidth(CARD_WIDTH)
        self.setMaximumWidth(CARD_WIDTH + 40)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        self.thumb = QtWidgets.QLabel(self)
        self.thumb.setObjectName('draw-thumbnail')
        self.thumb.setFixedSize(THUMB_W, THUMB_H)
        self.thumb.setAlignment(QtCore.Qt.AlignCenter)
        # Fixed light tile in both themes: previews stay legible in
        # dark mode without inverting the rendered figure.
        self.thumb.setStyleSheet(
            f'QLabel {{ background-color: {TILE_BG}; '
            f'border: 1px solid {PLACEHOLDER_BORDER}; }}')
        pixmap, has_preview = render_thumbnail(entry.id)
        self.thumb.setPixmap(pixmap)
        self.thumb.setProperty('has-preview', has_preview)
        self.thumb.setAccessibleName(
            i18n.tr('draw_gallery.preview_name',
                    command=entry.command) if has_preview
            else i18n.tr('draw_gallery.no_preview_name',
                         command=entry.command))
        layout.addWidget(self.thumb, 0, QtCore.Qt.AlignHCenter)

        title = QtWidgets.QLabel(title_text(entry), self)
        self._title_label = title
        title.setObjectName('draw-card-title')
        title.setWordWrap(True)
        title_font = QtGui.QFont(title.font())
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)

        syntax = QtWidgets.QLabel(entry.syntax, self)
        syntax.setObjectName('draw-card-syntax')
        syntax.setWordWrap(True)
        mono = QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont)
        syntax.setFont(mono)
        syntax.setToolTip(entry.syntax)
        layout.addWidget(syntax)

        description = QtWidgets.QLabel(description_text(entry), self)
        self._desc_label = description
        description.setObjectName('draw-card-description')
        description.setWordWrap(True)
        description.setToolTip(f'{entry.syntax}\n{description_text(entry)}')
        layout.addWidget(description)

        buttons = QtWidgets.QHBoxLayout()
        buttons.setSpacing(6)
        self.example_btn = QtWidgets.QPushButton(
            i18n.tr('draw_gallery.insert_example'), self)
        self.example_btn.setObjectName('insert-example')
        apply_icon(self.example_btn, 'insert-example', SIZE_DIALOG)
        self.example_btn.setAccessibleName(
            i18n.tr('draw_gallery.insert_example_name', title=title_text(entry)))
        self.example_btn.setToolTip(
            i18n.tr('draw_gallery.insert_example_tip',
                    command=entry.command))
        buttons.addWidget(self.example_btn)

        self.command_btn = QtWidgets.QPushButton(
            i18n.tr('draw_gallery.insert_command'), self)
        self.command_btn.setObjectName('insert-command')
        apply_icon(self.command_btn, 'insert-command', SIZE_DIALOG)
        self.command_btn.setAccessibleName(
            i18n.tr('draw_gallery.insert_command_name',
                    command=entry.command))
        if entry.symbol:
            self.command_btn.setToolTip(
                i18n.tr('draw_gallery.insert_command_tip',
                        command=entry.command))
        else:
            # Defensive: a catalog command without a geo-* dialog in the
            # registry (every command has one today).
            self.command_btn.setEnabled(False)
            self.command_btn.setToolTip(
                i18n.tr('draw_gallery.no_dialog_tip',
                        command=entry.command))
        buttons.addWidget(self.command_btn)
        layout.addLayout(buttons)
        layout.addStretch(1)

    def retranslate_ui(self):
        """Refresh the draw card texts in the current language."""
        entry = self.entry
        self._title_label.setText(title_text(entry))
        self._desc_label.setText(description_text(entry))
        self._desc_label.setToolTip(f'{entry.syntax}\n{description_text(entry)}')
        self.example_btn.setText(i18n.tr('draw_gallery.insert_example'))
        self.example_btn.setAccessibleName(
            i18n.tr('draw_gallery.insert_example_name', title=title_text(entry)))
        self.example_btn.setToolTip(
            i18n.tr('draw_gallery.insert_example_tip',
                    command=entry.command))
        self.command_btn.setText(i18n.tr('draw_gallery.insert_command'))
        self.command_btn.setAccessibleName(
            i18n.tr('draw_gallery.insert_command_name',
                    command=entry.command))
        if entry.symbol:
            self.command_btn.setToolTip(
                i18n.tr('draw_gallery.insert_command_tip',
                        command=entry.command))
        else:
            self.command_btn.setToolTip(
                i18n.tr('draw_gallery.no_dialog_tip',
                        command=entry.command))


# ----------------------------------------------------------------------
# Dialog
# ----------------------------------------------------------------------

class DrawGalleryDialog(QtWidgets.QDialog):
    """Non-modal browser for every geometry command.

    One instance is reused per MainWindow; presentational only — the
    host window connects the signals to its own insertion code.
    """

    exampleRequested = QtCore.Signal(str)
    commandRequested = QtCore.Signal(str)
    templateRequested = QtCore.Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setModal(False)
        self.setObjectName('drawGalleryDialog')
        self.setWindowTitle(i18n.tr('draw_gallery.title'))
        self.resize(900, 560)
        self.setMinimumSize(640, 420)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        header = QtWidgets.QHBoxLayout()
        header.setSpacing(6)

        self.search = QtWidgets.QLineEdit(self)
        self.search.setObjectName('draw-gallery-search')
        self.search.setPlaceholderText(i18n.tr('draw_gallery.search_placeholder'))
        self.search.setClearButtonEnabled(True)
        self.search.setAccessibleName(i18n.tr('draw_gallery.search_name'))
        self.search.setToolTip(i18n.tr('draw_gallery.search_tip'))
        install_text_context_menu(self.search)
        header.addWidget(self.search, 1)

        self.group_combo = QtWidgets.QComboBox(self)
        self.group_combo.setObjectName('draw-gallery-group')
        self.group_combo.setAccessibleName(i18n.tr('draw_gallery.group_name'))
        self.group_combo.addItem(i18n.tr('symbolbar.all'))
        for group in GROUPS:
            self.group_combo.addItem(i18n.tr(f'group.{group}'))
        header.addWidget(self.group_combo)

        self.empty_btn = QtWidgets.QPushButton(
            i18n.tr('draw_gallery.empty'), self)
        self.empty_btn.setObjectName('draw-gallery-empty')
        apply_icon(self.empty_btn, 'empty-block', SIZE_DIALOG)
        self.empty_btn.setAccessibleName(i18n.tr('draw_gallery.empty_name'))
        self.empty_btn.setToolTip(i18n.tr('draw_gallery.empty_tip'))
        self.empty_btn.clicked.connect(self._emit_empty_block)
        header.addWidget(self.empty_btn)
        layout.addLayout(header)

        self.status = QtWidgets.QLabel('', self)
        self.status.setObjectName('draw-gallery-status')
        self.status.setAccessibleName(i18n.tr('a11y.visible_count'))
        layout.addWidget(self.status)

        self.scroll = QtWidgets.QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(
            QtCore.Qt.ScrollBarAsNeeded)
        layout.addWidget(self.scroll, 1)

        self._container = QtWidgets.QWidget(self.scroll)
        self._grid = QtWidgets.QGridLayout(self._container)
        self._grid.setContentsMargins(0, 0, 0, 0)
        self._grid.setHorizontalSpacing(8)
        self._grid.setVerticalSpacing(8)
        self._grid.setAlignment(QtCore.Qt.AlignTop | QtCore.Qt.AlignLeft)
        self.scroll.setWidget(self._container)

        self._cards: dict[str, DrawCard] = {}
        self.search.textChanged.connect(self._rebuild)
        self.group_combo.currentTextChanged.connect(self._rebuild)
        self._rebuild()

    # -- public helpers (used by tests) --------------------------------

    @property
    def cards(self) -> dict[str, DrawCard]:
        """Read-only view of the cards currently built (id -> DrawCard)."""
        return dict(self._cards)

    def visible_ids(self) -> list[str]:
        """Entry ids currently shown, in catalog order."""
        return [entry.id for entry in catalog_entries()
                if entry.id in self._cards]

    def card_for(self, entry_id: str) -> DrawCard | None:
        """Return the card for *entry_id*, or None when not built yet."""
        return self._cards.get(entry_id)

    def _selected_group(self):
        """Registry group name for the combo, or None for 'All'."""
        current = self.group_combo.currentText()
        if current in ('', i18n.tr('symbolbar.all')):
            return None
        for group in GROUPS:
            if i18n.tr(f'group.{group}') == current:
                return group
        return current

    def matches(self, entry: CatalogEntry) -> bool:
        """True when *entry* passes the current search + group filter."""
        group = self._selected_group()
        if group is not None and entry.group != group:
            return False
        query = self.search.text().strip().lower()
        if not query:
            return True
        if query in entry.search_text:
            return True
        # Also match the translated title/description so Vietnamese
        # search finds cards by their visible text.
        translated = f'{title_text(entry)} {description_text(entry)}'.lower()
        return query in translated

    # -- internals ----------------------------------------------------

    def _clear_grid(self):
        while self._grid.count():
            item = self._grid.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.deleteLater()

    def _rebuild(self, *_args):
        self._clear_grid()
        self._cards = {}
        row = col = 0
        for entry in CATALOG:
            if not self.matches(entry):
                continue
            card = DrawCard(entry, self._container)
            card.example_btn.clicked.connect(
                lambda _checked=False, e=entry: self.templateRequested.emit(
                    e.id))
            if entry.symbol:
                card.command_btn.clicked.connect(
                    lambda _checked=False, s=entry.symbol:
                    self.commandRequested.emit(s))
            self._grid.addWidget(card, row, col)
            self._cards[entry.id] = card
            col += 1
            if col >= GRID_COLUMNS:
                col = 0
                row += 1
        # Push any leftover row against the left edge.
        if self._cards and col > 0:
            spacer = QtWidgets.QWidget(self._container)
            spacer.setSizePolicy(QtWidgets.QSizePolicy.Expanding,
                                 QtWidgets.QSizePolicy.Preferred)
            self._grid.addWidget(spacer, row, col, 1,
                                 GRID_COLUMNS - col)
        shown = len(self._cards)
        total = len(CATALOG)
        self.status.setText(
            i18n.tr('draw_gallery.count_some', shown=shown, total=total)
            if shown != total
            else i18n.tr('draw_gallery.count_all', total=total))
        if shown == 0:
            empty = QtWidgets.QLabel(
                i18n.tr('draw_gallery.no_match'), self._container)
            empty.setObjectName('draw-gallery-no-match')
            self._grid.addWidget(empty, 0, 0)

    def _emit_empty_block(self):
        """The old *draw button's insert, offered inside the gallery."""
        from .symbol_registry import get_symbol
        try:
            text = get_symbol('draw-skeleton').insert_text or ''
        except KeyError:  # pragma: no cover - registry always has it
            text = ''
        if text:
            self.exampleRequested.emit(text)

    def raise_and_activate(self):
        """Bring an already-open instance to the front."""
        if self.isMinimized():
            self.showNormal()
        self.raise_()
        self.activateWindow()

    def retranslate_ui(self):
        """Refresh translated chrome, keeping search and group filter."""
        selected = self._selected_group()
        self.setWindowTitle(i18n.tr('draw_gallery.title'))
        self.search.setPlaceholderText(
            i18n.tr('draw_gallery.search_placeholder'))
        self.search.setAccessibleName(i18n.tr('draw_gallery.search_name'))
        self.search.setToolTip(i18n.tr('draw_gallery.search_tip'))
        self.group_combo.setAccessibleName(
            i18n.tr('draw_gallery.group_name'))
        self.empty_btn.setText(i18n.tr('draw_gallery.empty'))
        self.empty_btn.setAccessibleName(i18n.tr('draw_gallery.empty_name'))
        self.empty_btn.setToolTip(i18n.tr('draw_gallery.empty_tip'))
        self.group_combo.blockSignals(True)
        try:
            self.group_combo.clear()
            self.group_combo.addItem(i18n.tr('symbolbar.all'))
            for group in GROUPS:
                self.group_combo.addItem(i18n.tr(f'group.{group}'))
            index = 0 if selected is None else (
                self.group_combo.findText(i18n.tr(f'group.{selected}')))
            self.group_combo.setCurrentIndex(max(0, index))
        finally:
            self.group_combo.blockSignals(False)
        self._rebuild()
