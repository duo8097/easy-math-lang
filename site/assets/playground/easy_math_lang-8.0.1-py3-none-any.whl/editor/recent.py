"""Recent-files list persisted with QSettings (no widgets)."""

from .config import default_settings  # noqa: F401  (public re-export)


class RecentFiles:
    """Most-recently-used file list backed by a QSettings store."""

    def __init__(self, settings, max_items=8, key='recentFiles'):
        self._settings = settings
        self._max_items = max_items
        self._key = key

    def add(self, path):
        """Remember *path*, most recent first, capped at *max_items*."""
        if not path:
            return
        items = [p for p in self.list() if p != path]
        items.insert(0, path)
        self._settings.setValue(self._key, items[:self._max_items])

    def list(self):
        """Return the stored paths, most recent first (empty list if none)."""
        value = self._settings.value(self._key, [])
        if isinstance(value, str):
            return [value]
        if not isinstance(value, (list, tuple)):
            return []
        try:
            return [str(p) for p in (value or [])]
        except TypeError:
            return []

    def clear(self):
        """Forget all stored recent-file entries."""
        self._settings.remove(self._key)
