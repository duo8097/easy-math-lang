"""Main window: menus, docks, file handling and LSP wiring.

Table of contents for this ~1900-line file — jump to the banner
comments (line numbers approximate, names are stable):

    ~line  section
    -----  -------
      81   _PreviewWorker — background compile for the live preview
     107   class MainWindow.__init__ — builds the UI, docks, LSP
           client and preview thread, then wires everything below
     243   # LSP lifecycle — start/restart/handshake, didOpen/
           didChange, diagnostics → Problems, symbols → Outline
     456   # Navigation — LSP UTF-16 positions → QTextCursor;
           open_source_location() resolves PDF click-back
     592   # Completion + hover — LSP → QCompleter + tooltips
     717   # Symbol Bar / Smart Symbol Palette
     776   # Friendly extras — command palette, find, go-to-line,
           recent files
    1043   # File operations — new/open/save (atomic write), dirty `*`
    1199   # Build — Ctrl+B runs easy-math-lang via QProcess; the
           in-process sibling _export_as() (1264) is Export As…
    1332   # Wiring — menus, editor signals, close handling
    1468   # Editor text size / # Editor font family (1495) /
           # Theme (1571)
    1694   # Live preview — debounced versioned requests, stale
           results dropped, source-map click-back to the editor
    1850   closeEvent — save prompt, then wait for LSP shutdown

Three subsystems leave this file: the compiler (out-of-process via
paths.resolve_compiler_command), the preview (in-process
compiler.pipeline on a worker QThread), and the LSP (an
out-of-process LspClient). Picture version: docs/architecture.md.
"""

import html
import os
import re
import shutil
import sys
import tempfile
import weakref

from PySide6 import QtCore, QtGui, QtWidgets

from .command_palette import CommandPalette
from .editor_widget import EditorWidget
from .find_bar import FindBar
from .help_dialogs import (EXAMPLES, AboutDialog, ShortcutsDialog,
                           WelcomePanel, example_source)
from .symbol_bar import SymbolBar
from .update_ui import (UpdateCheckWorker, UpdateDialog, UpdateDownloadWorker,
                        UpdateFailedDialog, UpdateNoticeBanner)
from .symbol_dialog import SymbolDialog
from .symbol_registry import build_source, cursor_offset_for_insert, get_symbol
from .lsp_client import LspClient, default_server_command
from .outline_panel import OutlinePanel
from .paths import icon_path, resolve_compiler_command
from .preview import PREVIEW_DEBOUNCE_MS
from .preview_panel import PreviewPanel
from .problems_panel import ProblemsPanel
from .config import default_settings
from .recent import RecentFiles
from . import friendly_errors, i18n
from .icons import SIZE_MENU, SIZE_TOOLBAR, apply_action_icon
from .qt_text import (critical as _qt_critical,
                      question as _qt_question,
                      translate_file_dialog, translate_input_dialog)
from . import theme as app_theme

SUPPORTED_SUFFIXES = ('.ezmath', '.eml')

# LSP SymbolKind values occasionally arrive as ints; show readable names.
_SYMBOL_KIND_NAMES = {
    1: 'File', 2: 'Module', 3: 'Namespace', 4: 'Package', 5: 'Class',
    6: 'Method', 7: 'Property', 8: 'Field', 9: 'Constructor', 10: 'Enum',
    11: 'Interface', 12: 'Function', 13: 'Variable', 14: 'Constant',
    15: 'String', 16: 'Number', 17: 'Boolean', 18: 'Array', 19: 'Object',
    20: 'Key', 21: 'Null', 22: 'EnumMember', 23: 'Struct', 24: 'Event',
    25: 'Operator', 26: 'TypeParameter',
}


def markdown_to_html(text):
    """Tiny Markdown subset (bold, code, newlines) for tooltips."""
    escaped = html.escape(text)
    escaped = re.sub(r'\*\*(.+?)\*\*', r'<b>\g<1></b>', escaped)
    escaped = re.sub(r'`(.+?)`', r'<code>\g<1></code>', escaped)
    return escaped.replace('\n', '<br>')


class _PreviewWorker(QtCore.QObject):
    """Background compiler for live preview (never touches Qt widgets)."""

    finished = QtCore.Signal(int, dict)

    @QtCore.Slot(int, str, str, str)
    def render(self, version, text, workdir, source_path):
        """Compile *text* to PDF in the background (worker thread).

        Emits ``finished`` with the result dict. Never touches Qt
        widgets; failures are caught and returned as ``ok: False`` so
        the editor stays alive.
        """
        from .preview import compile_source_to_pdf
        try:
            # Live preview embeds invisible eml-src link annotations so
            # Ctrl+Click can navigate back to the .eml source. Export
            # builds (File -> Export As) keep links off for clean PDFs.
            result = compile_source_to_pdf(text, workdir, version=version,
                                           source_links=True,
                                           source_path=source_path or None)
        except BaseException as exc:  # keep the editor alive on any failure
            result = {'ok': False, 'pdf': None, 'typ': '', 'log': str(exc)}
        try:
            self.finished.emit(version, result)
        except BaseException:
            pass


class MainWindow(QtWidgets.QMainWindow):
    """The editor's main window: menus, docks, file handling, LSP wiring.

    Builds the UI (editor area, Problems/Outline/Preview docks,
    menus, symbol bar), wires file operations (new/open/save), build
    (Ctrl+B runs easy-math-lang out-of-process), Export As…, live
    preview (debounced background compile), theme/font/settings, and
    the LSP client connection to easy-math-lsp.
    """
    _preview_request = QtCore.Signal(int, str, str, str)
    _update_request = QtCore.Signal(bool)

    def __init__(self, start_lsp=True, parent=None, no_save_prompt=False):
        super().__init__(parent)
        # Language first: every widget built below reads the current
        # translator at construction time. The saved choice wins;
        # otherwise the system locale decides (English fallback).
        self._settings = default_settings()
        self._language = i18n.load_setting_language(self._settings)
        self._menu_specs = []  # (widget, text key, tip key, params)
        self._menus = {}
        self.setWindowTitle(i18n.tr('app.title_suffix'))
        self.resize(1100, 750)
        self._no_save_prompt = no_save_prompt
        # Window/taskbar icon (256px PNG bundled in editor/assets). A
        # missing file keeps the default icon instead of blocking startup.
        try:
            icon_file = icon_path()
            if icon_file:
                icon = QtGui.QIcon(icon_file)
                if not icon.isNull():
                    self.setWindowIcon(icon)
        except Exception:
            pass

        self._file_path = None
        self._untitled_count = 0
        self._doc_uri = None
        self._doc_version = 0
        self._lsp_open = False  # didOpen acknowledged for current doc
        self._lsp_starting = False  # launch attempted, init not done yet
        self._closing = False  # closeEvent deferred until LSP shutdown done
        self._restart_pending = False  # restart once the old server exits
        self._reopen_after_connect = False  # re-didOpen after a restart

        self.editor = EditorWidget(self)
        _default_size = self.editor.font().pointSizeF()
        # pointSizeF() returns -1 for pixel-size fonts; keep the default.
        self._default_font_size = _default_size if _default_size and _default_size > 0 else 12.0

        self._find_bar = FindBar()
        self._find_bar.findRequested.connect(self._on_find_requested)
        self._find_bar.replaceRequested.connect(self._on_replace_requested)
        self._find_bar.optionsChanged.connect(self._on_find_options_changed)
        self._find_bar.closed.connect(self._on_find_closed)
        self._find_match_case = False
        self._find_whole_word = False
        central = QtWidgets.QWidget(self)
        central_layout = QtWidgets.QVBoxLayout(central)
        central_layout.setContentsMargins(0, 0, 0, 0)
        central_layout.setSpacing(0)
        # First-run welcome banner (hidden unless maybe_show_welcome
        # is called by the app entry point; see app.main).
        self._welcome_panel = WelcomePanel(self)
        self._welcome_panel.openExampleRequested.connect(
            self._insert_example)
        self._welcome_panel.dismissed.connect(self._dismiss_welcome)
        self._welcome_panel.hide()
        central_layout.addWidget(self._welcome_panel)
        central_layout.addWidget(self._find_bar)
        # Non-modal "a newer release exists" banner; hidden until the
        # background check finds one. The host owns the flow (see
        # maybe_show_update_failure / _start_update_check).
        self._update_banner = UpdateNoticeBanner(self)
        self._update_banner.actionRequested.connect(self._open_update_dialog)
        self._update_banner.dismissed.connect(self._dismiss_update_banner)
        self._update_banner.hide()
        central_layout.addWidget(self._update_banner)
        self._symbol_bar = SymbolBar(self)
        self._symbol_bar.symbolChosen.connect(self._on_symbol_activated)
        central_layout.addWidget(self._symbol_bar)
        central_layout.addWidget(self.editor, 1)
        self.setCentralWidget(central)
        # Lazily created *draw gallery + template window: non-modal, one
        # instance per window (re-raised on the second click). The
        # modules themselves are imported on first open to keep startup
        # imports light.
        self._draw_gallery = None
        self._draw_template = None

        self.outline = OutlinePanel(self)
        self._outline_dock = QtWidgets.QDockWidget(i18n.tr('dock.outline'), self)
        self._outline_dock.setWidget(self.outline)
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, self._outline_dock)

        self.problems = ProblemsPanel(self)
        self._problems_dock = QtWidgets.QDockWidget(i18n.tr('dock.problems'), self)
        self._problems_dock.setWidget(self.problems)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self._problems_dock)

        self.preview = PreviewPanel(self)
        self._preview_dock = QtWidgets.QDockWidget(i18n.tr('dock.preview'), self)
        self._preview_dock.setWidget(self.preview)
        self.addDockWidget(QtCore.Qt.RightDockWidgetArea, self._preview_dock)
        self._preview_dock.hide()
        self._preview_dock.visibilityChanged.connect(
            self._on_preview_visibility)

        self._cursor_label = QtWidgets.QLabel(i18n.tr('status.cursor', line=1, col=1), self)
        self._problems_button = QtWidgets.QPushButton('', self)
        self._problems_button.setFlat(True)
        self._problems_button.setCursor(QtCore.Qt.PointingHandCursor)
        self._problems_button.setToolTip(i18n.tr('status.show_problems'))
        self._problems_button.clicked.connect(self._focus_problems)
        self._lsp_label = QtWidgets.QLabel(i18n.tr('status.lsp_disconnected'), self)
        self.statusBar().addPermanentWidget(self._cursor_label)
        self.statusBar().addPermanentWidget(self._problems_button)
        self.statusBar().addPermanentWidget(self._lsp_label)

        # self._settings was created at the top of __init__ (language
        # must load before any widget is built); keep that instance.
        self._recent = RecentFiles(self._settings)
        self._theme_name = app_theme.load_theme_name(self._settings)
        
        # Initialize auto-close brackets setting
        self._auto_close_brackets = self._settings.value('editor/autoCloseBrackets', True, type=bool)
        self.editor._auto_close_brackets = self._auto_close_brackets
        
        app = QtWidgets.QApplication.instance()
        self._default_palette = app.palette() if app is not None else None
        colors = app_theme.editor_colors(self._theme_name)
        self._find_all_color = QtGui.QColor(colors['find_all'])
        self._find_current_color = QtGui.QColor(colors['find_current'])
        self._find_ranges = []
        self._find_current_index = 0

        self._change_timer = QtCore.QTimer(self)
        self._change_timer.setSingleShot(True)
        self._change_timer.setInterval(300)
        self._change_timer.timeout.connect(self._on_change_timeout)

        self._completer = QtWidgets.QCompleter(self)
        self._completer.setWidget(self.editor)
        self._completer.setCompletionMode(
            QtWidgets.QCompleter.PopupCompletion)
        self._completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self._completer.activated[str].connect(self._insert_completion)
        self._completer.highlighted[str].connect(self._show_completion_detail)
        self._completion_model = QtCore.QStringListModel(self._completer)
        self._completer.setModel(self._completion_model)
        self._completion_info = {}  # label -> (kind_name, detail)

        self._build_process = None

        # The LSP client must exist before any wired slot can run:
        # applying the theme rehighlights the editor, which emits
        # textChanged synchronously.
        self.lsp = LspClient(default_server_command(), self)
        self.lsp.server_started.connect(self._request_initialize)
        self.lsp.connected.connect(self._on_lsp_connected)
        self.lsp.disconnected.connect(self._on_lsp_disconnected)
        self.lsp.process_error.connect(self._on_lsp_error)
        self.lsp.diagnostics_received.connect(self._on_diagnostics)

        self._preview_workdir = tempfile.mkdtemp(prefix='easymath-preview-')
        self._preview_version = 0
        self._preview_auto = True
        self._preview_shutdown = False
        # Last text submitted to the worker: identical text is never
        # recompiled (saves a full compile's CPU + transient RAM on every
        # pause; explicit refresh still forces a rebuild).
        self._last_preview_text = None
        self._preview_timer = QtCore.QTimer(self)
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(PREVIEW_DEBOUNCE_MS)
        self._preview_timer.timeout.connect(self._on_preview_timeout)
        self._preview_thread = QtCore.QThread(self)
        self._preview_worker = _PreviewWorker()
        self._preview_worker.moveToThread(self._preview_thread)
        self._preview_request.connect(
            self._preview_worker.render, QtCore.Qt.QueuedConnection)
        self._preview_worker.finished.connect(self._on_preview_finished)
        self._preview_thread.start()
        self.preview.refreshRequested.connect(self._refresh_preview_now)
        self.preview.autoToggled.connect(self._on_preview_auto)
        self.preview.openPdfRequested.connect(self._open_preview_externally)
        self.preview.sourceLinkActivated.connect(self._on_preview_source_link)

        # Update check/download threads — same pattern as the preview
        # worker: one long-lived QThread each, shut down in closeEvent.
        self._update_check_thread = QtCore.QThread(self)
        self._update_check_worker = UpdateCheckWorker()
        self._update_check_worker.moveToThread(self._update_check_thread)
        self._update_request.connect(
            self._update_check_worker.check, QtCore.Qt.QueuedConnection)
        self._update_check_worker.done.connect(self._on_update_check_done)
        self._update_check_thread.start()
        self._update_download_thread = None
        self._update_download_worker = None
        self._update_inflight = False
        self._update_manual = False
        self._update_payload = None
        self._update_dialog = None
        self._update_banner_payload = None

        self._create_menus()
        self._connect_editor()
        self._apply_theme(self._theme_name, save=False)
        self._apply_editor_font()

        if start_lsp:
            self._start_lsp()

        self._new_document()
        self._update_title()
        # Background update check, shortly after startup (manual checks
        # go through the Help menu). No UI work happens until results
        # arrive; failures are silent there.
        QtCore.QTimer.singleShot(3000, self._auto_update_check)

    # ------------------------------------------------------------------
    # LSP lifecycle
    # ------------------------------------------------------------------
    def _start_lsp(self):
        if self.lsp.is_connected() or self._lsp_starting:
            return
        self._lsp_starting = True
        # start() never blocks; failure arrives via process_error and no
        # server_started signal, which resets the flag below.
        if not self.lsp.start():
            self._lsp_starting = False
            self._set_lsp_status(i18n.tr('status.lsp_disconnected'))

    def _request_initialize(self):
        if self.lsp.is_connected():
            return
        self.lsp.initialize(callback=self._on_initialize)

    def _on_initialize(self, result, error):
        if error is not None:
            self._lsp_starting = False
            # Reset the client out of its stuck 'starting' state so a
            # later _start_lsp() actually launches a new process.
            try:
                self.lsp.abort()
            except Exception:
                pass
            self._set_lsp_status(i18n.tr('status.lsp_disconnected'))
            if isinstance(error, dict):
                detail = error.get('message') or repr(error)
            else:
                detail = str(error)
            self.statusBar().showMessage(
                i18n.tr('status.lsp_init_failed', detail=detail), 8000)
            return
        if not self._lsp_open:
            # A restart already reopened the document from _on_lsp_connected.
            self._open_current_in_lsp()

    def _on_lsp_connected(self):
        self._lsp_starting = False
        self._set_lsp_status(i18n.tr('status.lsp_connected'))
        if self._reopen_after_connect:
            self._reopen_after_connect = False
            self._open_current_in_lsp()

    def _restart_lsp(self):
        """Restart the server (e.g. after a crash); reopens the document."""
        if self._restart_pending or self._closing:
            return
        if self.lsp.state == 'stopped':
            self._start_lsp()
            return
        self._restart_pending = True
        self._close_current_in_lsp()
        self.statusBar().showMessage(i18n.tr('status.restarting_lsp'), 3000)
        self.lsp.stop()

    def _on_lsp_disconnected(self, _code):
        self._lsp_starting = False
        self._set_lsp_status('LSP: Disconnected')
        self._lsp_open = False
        if self._closing:
            # Deferred close from closeEvent: the server process is gone,
            # so the window may now be destroyed safely.
            self.close()
            return
        if self._restart_pending:
            self._restart_pending = False
            self._reopen_after_connect = True
            self._start_lsp()

    def _on_lsp_error(self, message):
        if not self.lsp.is_connected():
            self._lsp_starting = False
            # A FailedToStart while state=='starting' would otherwise
            # deadlock future restarts (start() early-returns True).
            if self.lsp.state == 'starting':
                try:
                    self.lsp.abort()
                except Exception:
                    pass
        self.statusBar().showMessage(message, 8000)
        try:
            from .preview import COMPILE_LOCK
        except ImportError:
            COMPILE_LOCK = None
        try:
            if COMPILE_LOCK is not None:
                with COMPILE_LOCK:
                    sys.stderr.write(f'[easy-math-editor] {message}\n')
            else:
                sys.stderr.write(f'[easy-math-editor] {message}\n')
        except Exception:
            pass

    def _set_lsp_status(self, text):
        self._lsp_label.setText(text)

    def _is_lsp_document(self):
        if self._file_path is not None:
            return self._file_path.lower().endswith(SUPPORTED_SUFFIXES)
        return self._doc_uri is not None and \
            self._doc_uri.lower().split('?')[0].split('#')[0].endswith(SUPPORTED_SUFFIXES)

    def _open_current_in_lsp(self):
        if not self.lsp.is_connected() or not self._is_lsp_document():
            return
        self._doc_version += 1
        self.lsp.did_open(self._doc_uri, 'easymath', self._doc_version,
                          self.editor.toPlainText())
        self._lsp_open = True
        self._request_symbols()

    def _close_current_in_lsp(self):
        if self._lsp_open and self._doc_uri is not None:
            self.lsp.did_close(self._doc_uri)
        self._lsp_open = False

    def _on_change_timeout(self):
        if not self.lsp.is_connected() or not self._lsp_open:
            return
        self._doc_version += 1
        self.lsp.did_change(self._doc_uri, self._doc_version,
                            self.editor.toPlainText())
        self._request_symbols()

    def _request_symbols(self):
        if not self.lsp.is_connected() or not self._lsp_open:
            return
        uri = self._doc_uri
        version = self._doc_version

        def _done(result, error):
            if error is not None or not isinstance(result, list):
                return
            symbols = []
            for item in result:
                if not isinstance(item, dict):
                    continue
                loc = item.get('location')
                if not isinstance(loc, dict):
                    loc = {}
                # Accept DocumentSymbol-style `range` as well as
                # SymbolInformation-style `location.range`.
                rng = item.get('range') or loc.get('range') or {}
                if not isinstance(rng, dict):
                    rng = {}
                start = rng.get('start') or {}
                if not isinstance(start, dict):
                    start = {}
                kind = item.get('kind', '')
                try:
                    line = int(start.get('line', 0))
                except (TypeError, ValueError):
                    line = 0
                try:
                    char = int(start.get('character', 0))
                except (TypeError, ValueError):
                    char = 0
                symbols.append({
                    'name': item.get('name', '?') if isinstance(item.get('name'), str) else '?',
                    'kind': _SYMBOL_KIND_NAMES.get(kind, str(kind)),
                    'line': line,
                    'start': char,
                })
            # Ignore stale responses from a previous document or version.
            if uri == self._doc_uri and version == self._doc_version:
                self.outline.set_symbols(symbols)

        self.lsp.request_symbols(uri, _done)

    def _on_diagnostics(self, uri, diagnostics, version=None):
        if uri != self._doc_uri:
            return
        # Drop stale diagnostics from an older document version.
        if version is not None:
            try:
                if int(version) < int(self._doc_version):
                    return
            except (TypeError, ValueError):
                pass
        if not isinstance(diagnostics, list):
            diagnostics = []
        rows = []
        for diag in diagnostics:
            if not isinstance(diag, dict):
                continue
            rng = diag.get('range')
            if not isinstance(rng, dict):
                rng = {}
            start = rng.get('start')
            if not isinstance(start, dict):
                start = {}
            end = rng.get('end')
            if not isinstance(end, dict):
                end = {}
            sev = diag.get('severity', 1)
            try:
                line = int(start.get('line', 0))
            except (TypeError, ValueError):
                line = 0
            try:
                s_char = int(start.get('character', 0))
            except (TypeError, ValueError):
                s_char = 0
            try:
                e_char = int(end.get('character', s_char))
            except (TypeError, ValueError):
                e_char = s_char
            msg = diag.get('message', '')
            if not isinstance(msg, str):
                msg = str(msg)
            rows.append({
                'line': line,
                'start': s_char,
                'end': e_char,
                'severity': 'error' if sev == 1 else 'warning',
                'message': msg,
            })
        self.problems.set_diagnostics(rows)
        count = len(rows)
        self._problems_button.setText(
            i18n.tr('status.problems', count=count) if count else '')

    # ------------------------------------------------------------------
    # Navigation (LSP positions are UTF-16; QTextCursor is natively UTF-16)
    # ------------------------------------------------------------------
    def _goto(self, line, character):
        try:
            line, character = int(line), int(character)
        except (TypeError, ValueError):
            return
        self.editor.goto_position(line, character)
        self.editor.setFocus()

    def _goto_range(self, line, start, end):
        try:
            line, start, end = int(line), int(start), int(end)
        except (TypeError, ValueError):
            return
        block = self.editor.document().findBlockByNumber(max(0, line))
        if not block.isValid():
            return
        length = max(0, block.length() - 1)
        cursor = QtGui.QTextCursor(block)
        cursor.setPosition(block.position() + max(0, min(start, length)))
        cursor.setPosition(block.position() + max(0, min(end, length)),
                           QtGui.QTextCursor.KeepAnchor)
        self.editor.setTextCursor(cursor)
        self.editor.centerCursor()
        self.editor.setFocus()

    def open_source_location(self, file, line, column,
                             end_line=None, end_column=None):
        """Open an ``.eml`` location from a resolved source map span.

        *file* is the ``SourceSpan.source_file`` (absolute path, or the
        preview temp copy ``preview.ezmath``); *line*/*column* are 0-based
        with code-point columns (see :mod:`compiler.source_map`). The
        cursor uses Qt/LSP-native UTF-16 columns, converted via
        :mod:`editor.positions`. Navigates the current document when
        *file* is ``None``, matches the open file, or is the preview temp
        copy; otherwise opens *file* from disk (honouring unsaved-changes
        prompt). Returns ``True`` when navigation happened.
        """
        try:
            line = int(line)
        except (TypeError, ValueError):
            line = 0
        try:
            column = int(column)
        except (TypeError, ValueError):
            column = 0
        line = max(0, line)
        column = max(0, column)
        if end_line is not None:
            try:
                end_line = max(0, int(end_line))
            except (TypeError, ValueError):
                end_line = None
        if end_column is not None:
            try:
                end_column = max(0, int(end_column))
            except (TypeError, ValueError):
                end_column = None

        target = None
        try:
            target = os.path.abspath(str(file)) if file else None
        except (TypeError, ValueError, OSError):
            target = None
        current = None
        try:
            if self._file_path:
                current = os.path.abspath(self._file_path)
        except (TypeError, ValueError, OSError):
            current = None

        def _is_preview_copy(path):
            try:
                return os.path.basename(str(path)) == 'preview.ezmath'
            except Exception:
                return False

        if target is not None and target != current and not _is_preview_copy(target):
            # Different real file: open it (prompt on unsaved changes).
            try:
                if not os.path.isfile(target):
                    return False
            except (TypeError, ValueError, OSError):
                return False
            if not self._maybe_save():
                return False
            try:
                with open(target, 'r', encoding='utf-8') as handle:
                    text = handle.read()
            except (OSError, UnicodeDecodeError):
                return False
            try:
                self._recent.add(target)
            except Exception:
                pass
            self._switch_document(target, text)
        # Convert code-point column -> Qt UTF-16 using the live line text.
        try:
            from .positions import to_lsp_offset as _to_lsp
            block = self.editor.document().findBlockByNumber(max(0, line))
            line_text = block.text() if block.isValid() else ''
            character = int(_to_lsp(line_text, column))
        except Exception:
            character = column
        if end_line is not None and end_column is not None and end_line == line:
            try:
                from .positions import to_lsp_offset as _to_lsp_end
                block = self.editor.document().findBlockByNumber(max(0, line))
                line_text = block.text() if block.isValid() else ''
                end_char = int(_to_lsp_end(line_text, end_column))
            except Exception:
                end_char = end_column
            self._goto_range(line, character, end_char)
        else:
            self._goto(line, character)
        return True

    def open_source_span(self, span):
        """Convenience wrapper accepting a ``SourceSpan`` (or dict)."""
        try:
            if isinstance(span, dict):
                from compiler.source_map import SourceSpan as _SS
                span = _SS.from_dict(span)
            return bool(self.open_source_location(
                getattr(span, 'source_file', None),
                getattr(getattr(span, 'start', None), 'line', 0),
                getattr(getattr(span, 'start', None), 'column', 0),
                getattr(getattr(span, 'end', None), 'line', None),
                getattr(getattr(span, 'end', None), 'column', None),
            ))
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Completion + hover
    # ------------------------------------------------------------------
    # LSP CompletionItemKind values we care about (the rest need no
    # argument handling).
    _COMPLETION_KIND_NAMES = {3: 'function', 14: 'keyword',
                              6: 'variable', 21: 'constant'}
    # Custom text-format marker for find highlights (robust across theme
    # switches, unlike comparing background colors).
    _FIND_PROP = QtGui.QTextFormat.UserProperty + 1

    def _on_completion_requested(self):
        if not self.lsp.is_connected() or not self._lsp_open:
            return
        line, col = self.editor.cursor_line_col()
        uri = self._doc_uri
        version = self._doc_version
        self.lsp.request_completion(
            uri, line, col,
            lambda result, error: self._handle_completion_response(
                uri, result, error, version=version))

    def _handle_completion_response(self, uri, result, error, version=None):
        if error is not None or uri != self._doc_uri:
            return
        if version is not None and version != self._doc_version:
            return
        items = result.get('items') if isinstance(result, dict) else result
        if not isinstance(items, list):
            return
        info = {}
        for item in items:
            if not isinstance(item, dict) or not item.get('label'):
                continue
            kind = self._COMPLETION_KIND_NAMES.get(item.get('kind'), '')
            info[item['label']] = (kind, item.get('detail', ''))
        if not info:
            return
        self._completion_info = info
        self._completion_model.setStringList(sorted(info))
        self._completer.setCompletionPrefix(self.editor.word_under_cursor())
        self._completer.complete()

    def _show_completion_detail(self, text):
        """Show the highlighted candidate's signature in the status bar."""
        _kind, detail = self._completion_info.get(text, ('', ''))
        if detail:
            self.statusBar().showMessage(detail, 5000)

    def _char_after(self, pos):
        """Document character at Qt offset ('' when out of range).

        Uses ``QTextDocument.characterAt`` so offsets stay in Qt's
        native UTF-16 units even next to astral characters; callers
        only compare against BMP sentinels (``*``, ``(``), which a
        lone surrogate can never equal.
        """
        try:
            if pos is None or int(pos) < 0:
                return ''
            c = self.editor.document().characterAt(int(pos))
            if not c or c == '\x00':
                return ''
            return c
        except (RuntimeError, ValueError, TypeError, IndexError):
            return ''

    def _insert_completion(self, text):
        kind, detail = self._completion_info.get(text, ('', ''))
        cursor = self.editor.textCursor()
        cursor.select(QtGui.QTextCursor.WordUnderCursor)
        start, end = cursor.selectionStart(), cursor.selectionEnd()
        if text.startswith('*') and start > 0 \
                and self._char_after(start - 1) == '*':
            # Swallow the trigger '*' the user already typed so '*pi'
            # does not become '**pi'.
            start -= 1
        add_parens = (kind in ('function', 'keyword')
                      and '(' in (detail or '')
                      and self._char_after(end) != '('
                      and not (start == end
                               and self._char_after(start - 1) == '('))
        cursor.setPosition(start)
        cursor.setPosition(end, QtGui.QTextCursor.KeepAnchor)
        cursor.insertText(text + ('()' if add_parens else ''))
        if add_parens:
            # Leave the cursor inside the parens, ready for arguments.
            cursor.setPosition(cursor.position() - 1)
        self.editor.setTextCursor(cursor)

    def _on_hover_requested(self, global_pos):
        if not self.lsp.is_connected() or not self._lsp_open:
            return
        cursor = self.editor.cursorForPosition(
            self.editor.mapFromGlobal(global_pos))
        if cursor.isNull():
            return
        line, col = cursor.blockNumber(), cursor.positionInBlock()
        uri = self._doc_uri
        version = self._doc_version

        def _done(result, error):
            if error is not None or not result or uri != self._doc_uri or version != self._doc_version:
                return
            if not isinstance(result, dict):
                return
            contents = result.get('contents')
            if isinstance(contents, dict):
                value = contents.get('value', '')
            elif isinstance(contents, list):
                parts = []
                for part in contents:
                    if isinstance(part, dict):
                        parts.append(part.get('value', ''))
                    else:
                        parts.append(str(part))
                value = '\n\n'.join(p for p in parts if p)
            else:
                value = str(contents or '')
            if value:
                QtWidgets.QToolTip.showText(global_pos, markdown_to_html(value),
                                            self.editor)

        self.lsp.request_hover(uri, line, col, _done)

    # ------------------------------------------------------------------
    # Symbol Bar / Smart Symbol Palette
    # ------------------------------------------------------------------
    def _on_symbol_activated(self, name):
        """Insert a toolbar symbol: direct text or a parameter dialog."""
        try:
            symbol = get_symbol(name)
        except KeyError:
            return
        if name == 'draw-gallery':
            self._open_draw_gallery()
            return
        if not symbol.requires_dialog:
            self._insert_symbol_text(
                symbol.insert_text or '',
                cursor_offset_for_insert(symbol, symbol.insert_text or ''))
            return
        # Prefill the first field from the current selection when it
        # makes sense (e.g. selected "2+3" -> calc/frac numerator).
        initial: dict[str, str] = {}
        cursor = self.editor.textCursor()
        if cursor.hasSelection():
            selected = cursor.selectedText().replace('\u2029', '\n').strip()
            if selected and symbol.fields:
                initial[symbol.fields[0].key] = selected
        self._prompt_symbol_dialog(symbol, initial=initial)

    def _prompt_symbol_dialog(self, symbol, initial=None, insert=None):
        """Run a symbol's parameter dialog and insert the result.

        *initial* prefills the first field (from the selection);
        *insert* swaps in a different insertion strategy — the draw
        gallery passes its block-aware, single-undo-step inserter.
        """
        if insert is None:
            insert = self._insert_symbol_text
        ok, values = SymbolDialog.get_values(
            symbol, self, initial=initial if initial is not None else {})
        if not ok:
            self.editor.setFocus()
            return
        try:
            text = build_source(symbol, values)
        except ValueError as exc:
            self.statusBar().showMessage(str(exc), 5000)
            self.editor.setFocus()
            return
        insert(text)

    def _insert_symbol_text(self, text, cursor_offset=None):
        """Insert *text* at the cursor, replacing any selection.

        *cursor_offset* places the caret inside the inserted text
        (used by the draw skeleton so follow-up typing stays inside
        ``*draw(...)``); None means "right after the inserted text".
        """
        if not text:
            return
        cursor = self.editor.textCursor()
        # QTextCursor.insertText() replaces the selection when one
        # exists and otherwise inserts at the cursor — this preserves
        # middle/begin/end-of-line and multiline behavior.
        start = min(cursor.selectionStart(), cursor.selectionEnd())
        cursor.insertText(text)
        if cursor_offset is not None:
            try:
                off = max(0, min(int(cursor_offset), len(text)))
            except (TypeError, ValueError):
                off = len(text)
            cursor.setPosition(start + off)
        self.editor.setTextCursor(cursor)
        self.editor.ensureCursorVisible()
        self.editor.setFocus()

    # ------------------------------------------------------------------
    # *draw gallery + template window (non-modal, lazily imported)
    # ------------------------------------------------------------------
    def _open_draw_gallery(self):
        """Show — or re-raise — this window's geometry gallery."""
        from .draw_gallery import DrawGalleryDialog

        if self._draw_gallery is None:
            dlg = DrawGalleryDialog(self)
            dlg.exampleRequested.connect(self._insert_draw_gallery_source)
            dlg.commandRequested.connect(self._on_gallery_command)
            dlg.templateRequested.connect(self._open_draw_template)
            self._draw_gallery = dlg
        self._draw_gallery.show()
        self._draw_gallery.raise_and_activate()

    def _open_draw_template(self, key):
        """Show — or re-load — the preview/edit window for one template."""
        from .draw_template import DrawTemplateDialog

        if self._draw_template is None:
            dlg = DrawTemplateDialog(self)
            dlg.insertRequested.connect(self._insert_draw_gallery_source)
            dlg.commandRequested.connect(self._on_template_command)
            self._draw_template = dlg
        self._draw_template.open_template(key)
        self._draw_template.show()
        self._draw_template.raise_and_activate()

    def _on_gallery_command(self, name):
        """A gallery card asked for a command's parameter dialog."""
        try:
            symbol = get_symbol(name)
        except KeyError:
            return
        if symbol.requires_dialog:
            self._prompt_symbol_dialog(symbol,
                                       insert=self._insert_draw_gallery_source)

    def _on_template_command(self, name):
        """The template window's palette asked for a command dialog.

        The built command lands in the template's *code area* (see
        ``DrawTemplateDialog.insert_code``) — the document only sees
        it after Insert.
        """
        try:
            symbol = get_symbol(name)
        except KeyError:
            return
        if symbol.requires_dialog:
            self._prompt_symbol_dialog(symbol,
                                       insert=self._insert_into_template_code)
            # The modal dialog is done; keep focus in the template
            # window instead of the document behind it.
            if (self._draw_template is not None
                    and self._draw_template.isVisible()):
                self._draw_template.code.setFocus()

    def _insert_into_template_code(self, text):
        """Route a palette-built command into the template's code area.

        The counterpart of ``_insert_draw_gallery_source``: nothing
        reaches the document here — the template window shows exactly
        what Insert will later commit (see
        ``DrawTemplateDialog.insert_code``).
        """
        if self._draw_template is not None:
            self._draw_template.insert_code(text)

    def _insert_draw_gallery_source(self, source):
        """Insert a gallery example/command as ONE undo step.

        ``draw_catalog.build_insert_text`` decides the placement: inside
        an existing ``*draw(...)`` block the command is appended before
        the closing ``)`` (single-line blocks are expanded first), and
        outside any block it becomes its own block. Selection removal,
        the edit itself and the caret move all happen inside one
        ``beginEditBlock()/endEditBlock()`` pair, so a single Undo
        reverts the whole insertion.
        """
        from .draw_catalog import build_insert_text
        from .positions import to_code_point_offset, to_lsp_offset

        doc = self.editor.toPlainText()
        cursor = self.editor.textCursor()
        sel_start = min(cursor.selectionStart(), cursor.selectionEnd())
        sel_end = max(cursor.selectionStart(), cursor.selectionEnd())
        # QTextCursor positions are UTF-16; the document string and
        # build_insert_text work in code points. Convert at the boundary.
        cp_start = to_code_point_offset(doc, sel_start)
        cp_end = to_code_point_offset(doc, sel_end)
        # Positions below are relative to the document *without* the
        # selection — removing it first inside the edit block makes the
        # two line up exactly.
        base = doc[:cp_start] + doc[cp_end:]
        try:
            change = build_insert_text(source, base, cp_start)
        except ValueError as exc:
            self.statusBar().showMessage(str(exc), 5000)
            return

        cursor.beginEditBlock()
        try:
            cursor.setPosition(sel_start)
            if sel_end > sel_start:
                cursor.setPosition(sel_end, QtGui.QTextCursor.KeepAnchor)
                cursor.insertText('')
            cursor.setPosition(to_lsp_offset(base, change.start))
            cursor.setPosition(to_lsp_offset(base, change.end), QtGui.QTextCursor.KeepAnchor)
            cursor.insertText(change.insert)
            # change.cursor is an offset into the *resulting* text
            # (base with the selection removed and change.insert
            # spliced in) — convert against that text, not base.
            new_text = base[:change.start] + change.insert + base[change.end:]
            cursor.setPosition(to_lsp_offset(new_text, change.cursor))
        finally:
            cursor.endEditBlock()
        self.editor.setTextCursor(cursor)
        self.editor.ensureCursorVisible()
        self.editor.setFocus()

    # ------------------------------------------------------------------
    # Friendly extras: palette, find, go-to-line, recent files
    # ------------------------------------------------------------------
    # Find highlight colors live on the instance (self._find_all_color /
    # self._find_current_color) so they follow the active theme.
    _MAX_FIND_MATCHES = 1000

    def _focus_problems(self):
        self._problems_dock.show()
        self._problems_dock.raise_()

    def _palette_commands(self):
        toggle_outline = self._outline_dock.toggleViewAction()
        toggle_problems = self._problems_dock.toggleViewAction()
        toggle_preview = self._preview_dock.toggleViewAction()
        return [
            ('file.new', i18n.tr('palette.file_new'), '', self._new_document),
            ('file.open', i18n.tr('palette.file_open'), 'Ctrl+O', self._open_file),
            ('file.save', i18n.tr('palette.file_save'), 'Ctrl+S', lambda: self._save()),
            ('file.saveAs', i18n.tr('palette.file_save_as'), '', lambda: self._save_as()),
            ('file.exit', i18n.tr('palette.file_exit'), '', self.close),
            ('edit.find', i18n.tr('palette.edit_find'), 'Ctrl+F', self._toggle_find),
            ('edit.gotoLine', i18n.tr('palette.edit_goto'), 'Ctrl+G', self._go_to_line),
            ('view.toggleOutline', i18n.tr('palette.view_outline'), '',
             toggle_outline.trigger),
            ('view.toggleProblems', i18n.tr('palette.view_problems'), '',
             toggle_problems.trigger),
            ('view.togglePreview', i18n.tr('palette.view_preview'), 'Ctrl+Shift+V',
             toggle_preview.trigger),
            ('view.toggleTheme', i18n.tr('palette.view_theme'), 'Ctrl+Shift+D',
             self._toggle_theme),
            ('view.zoomIn', i18n.tr('palette.view_zoom_in'), 'Ctrl+=',
             lambda: self._zoom(1)),
            ('view.zoomOut', i18n.tr('palette.view_zoom_out'), 'Ctrl+-',
             lambda: self._zoom(-1)),
            ('view.zoomReset', i18n.tr('palette.view_zoom_reset'), 'Ctrl+0',
             self._zoom_reset),
            ('view.chooseFont', i18n.tr('palette.view_font'), '',
             self._choose_editor_font),
            ('draw.gallery', i18n.tr('palette.draw_gallery'), 'Ctrl+Shift+G',
             self._open_draw_gallery),
            ('build.compile', i18n.tr('palette.build_compile'), 'Ctrl+B',
             self._compile),
            ('build.refreshPreview', i18n.tr('palette.build_refresh'), 'F5',
             self._refresh_preview_now),
            ('build.restartLSP', i18n.tr('palette.build_restart'), '',
             self._restart_lsp),
            ('file.exportPdf', i18n.tr('palette.export_pdf'), '',
             lambda: self._export_as('pdf')),
            ('file.exportPng', i18n.tr('palette.export_png'), '',
             lambda: self._export_as('png')),
            ('file.exportSvg', i18n.tr('palette.export_svg'), '',
             lambda: self._export_as('svg')),
            ('file.exportHtml', i18n.tr('palette.export_html'), '',
             lambda: self._export_as('html')),
            ('file.exportTyp', i18n.tr('palette.export_typ'), '',
             lambda: self._export_as('typ')),
        ]

    def _show_palette(self):
        dialog = CommandPalette(self)
        dialog.set_commands(
            [(cmd_id, title, hint)
             for cmd_id, title, hint, _ in self._palette_commands()])
        dialog.commandChosen.connect(self._run_palette_command)
        dialog.exec()

    def _run_palette_command(self, cmd_id):
        for item_id, _title, _hint, action in self._palette_commands():
            if item_id == cmd_id:
                action()
                return

    def _on_find_closed(self):
        self._clear_find_highlights()
        self.editor.setFocus()

    def _toggle_find(self):
        if self._find_bar.isVisible():
            self._find_bar.hide_bar()
            return
        selected = self.editor.textCursor().selectedText()
        self._find_bar.show_bar(selected or self.editor.word_under_cursor())

    def _find_again(self, direction):
        if not self._find_bar.isVisible():
            self._toggle_find()
            return
        self._do_find(self._find_bar._input.text(), direction)

    def _on_find_requested(self, text, direction):
        self._do_find(text, direction)

    def _on_find_options_changed(self, match_case, whole_word):
        self._find_match_case = bool(match_case)
        self._find_whole_word = bool(whole_word)
        if self._find_bar._input.text():
            self._do_find(self._find_bar._input.text(), 0)

    def _on_replace_requested(self, replacement, replace_all):
        """Replace the current match, or all matches (one undo step)."""
        needle = self._find_bar._input.text()
        if not needle:
            return
        ranges = self._find_all_ranges(needle)
        if not ranges:
            self._find_bar.set_match_count(0, 0)
            return
        cursor = self.editor.textCursor()
        if not replace_all:
            # Replace the match under the cursor when there is one,
            # otherwise the currently highlighted match.
            pos = cursor.position()
            index = next((i for i, (s, e) in enumerate(ranges)
                          if s <= pos <= e), None)
            if index is None:
                index = getattr(self, '_find_current_index', None)
            if index is None or not (0 <= index < len(ranges)):
                index = 0
            start, end = ranges[index]
            cursor.beginEditBlock()
            try:
                cursor.setPosition(start)
                cursor.setPosition(end, QtGui.QTextCursor.KeepAnchor)
                cursor.insertText(replacement or '')
            finally:
                cursor.endEditBlock()
        else:
            cursor.beginEditBlock()
            try:
                # Replace back-to-front so earlier offsets stay valid.
                for start, end in reversed(ranges):
                    cursor.setPosition(start)
                    cursor.setPosition(
                        end, QtGui.QTextCursor.KeepAnchor)
                    cursor.insertText(replacement or '')
            finally:
                cursor.endEditBlock()
        self.editor.setTextCursor(cursor)
        self.editor.ensureCursorVisible()
        self._do_find(needle, 0)

    def _find_all_ranges(self, text):
        """Qt-native (start, end) offsets of every case-insensitive match.

        Uses ``QTextDocument.find`` so offsets are already in Qt's UTF-16
        units (Python ``re`` counts astral characters as one unit and
        would drift ``setPosition`` by one per preceding surrogate pair).
        """
        if not text:
            return []
        pattern_text = QtCore.QRegularExpression.escape(text)
        if getattr(self, '_find_whole_word', False):
            pattern_text = r'\b(?:' + pattern_text + r')\b'
        pattern = QtCore.QRegularExpression(pattern_text)
        if not getattr(self, '_find_match_case', False):
            pattern.setPatternOptions(
                QtCore.QRegularExpression.CaseInsensitiveOption)
        doc = self.editor.document()
        from .positions import to_code_point_offset

        plain = self.editor.toPlainText()
        ranges = []
        cursor = QtGui.QTextCursor(doc)
        cursor.setPosition(0)
        while True:
            cursor = doc.find(pattern, cursor)
            if cursor.isNull():
                break
            start, end = cursor.selectionStart(), cursor.selectionEnd()
            # QTextDocument.find() regex matching is case-insensitive
            # regardless of the pattern options, so enforce exact
            # case (and whole-word boundaries) by post-filtering.
            # start/end are UTF-16 offsets; convert to code points
            # before indexing the Python string.
            cp_start = to_code_point_offset(plain, start)
            cp_end = to_code_point_offset(plain, end)
            if getattr(self, '_find_match_case', False):
                if plain[cp_start:cp_end] != text:
                    continue
            if getattr(self, '_find_whole_word', False):
                before = plain[cp_start - 1] if cp_start > 0 else ' '
                after = plain[cp_end] if cp_end < len(plain) else ' '
                if (before.isalnum() or before == '_'
                        or after.isalnum() or after == '_'):
                    continue
            ranges.append((start, end))
            if len(ranges) >= self._MAX_FIND_MATCHES:
                break
        return ranges

    def _do_find(self, text, direction):
        self._clear_find_highlights()
        ranges = self._find_all_ranges(text)
        prev_ranges = getattr(self, '_find_ranges', None)
        prev_index = getattr(self, '_find_current_index', None)
        self._find_ranges = ranges
        if not ranges:
            self._find_bar.set_match_count(0, 0)
            return
        cursor = self.editor.textCursor()
        pos = cursor.position()
        has_selection = cursor.hasSelection()
        sel_start = cursor.selectionStart() if has_selection else None
        inside = next((i for i, (s, e) in enumerate(ranges) if s <= pos < e), None)
        if direction == 0:
            index = inside if inside is not None else next(
                (i for i, (s, _e) in enumerate(ranges) if s >= pos), 0)
        elif direction > 0:
            if inside is not None:
                # Cursor inside a match: advance to the next one
                # (previously stayed on the same match).
                index = (inside + 1) % len(ranges)
            else:
                at_or_before = [i for i, (_s, e) in enumerate(ranges) if e <= pos]
                index = 0 if not at_or_before else (at_or_before[-1] + 1) % len(ranges)
        else:
            if inside is not None:
                index = (inside - 1) % len(ranges)
                # When the cursor sits inside a match, at_or_before
                # excludes it, so the generic formula would skip one.
            else:
                at_or_before = [i for i, (_s, e) in enumerate(ranges) if e <= pos]
                if not at_or_before:
                    index = len(ranges) - 1
                else:
                    # Navigating: cursor sits at end of current match, so
                    # at_or_before includes it and we step one back.
                    # Fresh search (e.g. cursor at EOF): at_or_before's
                    # last entry IS the target, don't skip it.
                    # Disambiguate via active selection: _show_find_match
                    # leaves a selection; a fresh EOF cursor has none.
                    try:
                        cur = int(prev_index) if prev_index is not None else None
                    except (TypeError, ValueError):
                        cur = None
                    navigating = (
                        has_selection
                        and cur is not None
                        and prev_ranges is not None
                        and len(prev_ranges) == len(ranges)
                        and 0 <= cur < len(ranges)
                        and ranges[cur][1] == pos
                        and sel_start == ranges[cur][0]
                        and at_or_before[-1] == cur
                    )
                    if navigating:
                        index = (cur - 1) % len(ranges)
                    else:
                        index = at_or_before[-1]
                # NOTE: after _show_find_match the cursor sits at the end
                # of the shown match (e == pos), so at_or_before includes
                # the current match and -1 steps to the previous one,
                # which is what the Prev button expects.
        self._show_find_match(index)

    def _show_find_match(self, index):
        ranges = self._find_ranges
        self._find_current_index = index
        self._highlight_find_ranges(ranges, index)
        self._find_bar.set_match_count(index + 1, len(ranges))
        start, end = ranges[index]
        cursor = self.editor.textCursor()
        cursor.setPosition(start)
        cursor.setPosition(end, QtGui.QTextCursor.KeepAnchor)
        self.editor.setTextCursor(cursor)

    def _highlight_find_ranges(self, ranges, current):
        document = self.editor.document()
        selections = []
        for i, (start, end) in enumerate(ranges):
            selection = QtWidgets.QTextEdit.ExtraSelection()
            color = self._find_current_color if i == current \
                else self._find_all_color
            selection.format.setBackground(color)
            selection.format.setProperty(self._FIND_PROP, True)
            cursor = QtGui.QTextCursor(document)
            cursor.setPosition(start)
            cursor.setPosition(end, QtGui.QTextCursor.KeepAnchor)
            selection.cursor = cursor
            selections.append(selection)
        self.editor.setExtraSelections(
            self._current_extra_selections() + selections)

    def _current_extra_selections(self):
        """Selections not owned by find (e.g. the current-line highlight)."""
        return [s for s in self.editor.extraSelections()
                if not s.format.property(self._FIND_PROP)]

    def _clear_find_highlights(self):
        self.editor.setExtraSelections(self._current_extra_selections())

    def _go_to_line(self):
        current = self.editor.textCursor().blockNumber() + 1
        total = max(1, self.editor.blockCount())
        _dlg = QtWidgets.QInputDialog(self)
        _dlg.setWindowTitle(i18n.tr('dialog.goto_title'))
        _dlg.setLabelText(i18n.tr('dialog.goto_label', total=total))
        _dlg.setIntRange(1, total)
        _dlg.setIntValue(current)
        translate_input_dialog(_dlg)
        ok = _dlg.exec() == QtWidgets.QDialog.Accepted
        line = _dlg.intValue() if ok else current
        if ok:
            self._goto(line - 1, 0)
            self.editor.setFocus()

    def _refresh_recent_menu(self):
        self._recent_menu.clear()
        paths = [p for p in self._recent.list() if p]
        if not paths:
            empty = self._recent_menu.addAction(i18n.tr('action.recent.empty'))
            empty.setEnabled(False)
            return
        shown = 0
        for path in paths:
            if not os.path.exists(path):
                continue
            action = self._recent_menu.addAction(
                os.path.basename(path) or path)
            action.setStatusTip(path)
            action.setData(path)
            action.triggered.connect(
                lambda _checked=False, p=path: self._open_recent(p))
            shown += 1
        if shown == 0:
            empty = self._recent_menu.addAction(i18n.tr('action.recent.empty'))
            empty.setEnabled(False)
            return
        self._recent_menu.addSeparator()
        clear_action = self._recent_menu.addAction(i18n.tr('action.recent.clear'))
        clear_action.triggered.connect(self._recent.clear)

    def _open_recent(self, path):
        if not os.path.exists(path):
            self.statusBar().showMessage(
                i18n.tr('status.file_not_found', path=path), 5000)
            return
        if not self._maybe_save():
            return
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                text = handle.read()
        except (OSError, UnicodeDecodeError) as e:
            _qt_critical(self, i18n.tr('dialog.open_failed'), str(e))
            return
        self._recent.add(path)
        self._switch_document(path, text)

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------
    def _display_name(self):
        if self._file_path:
            return os.path.basename(self._file_path) or self._file_path
        return i18n.tr('dialog.untitled')

    def _update_title(self):
        dirty = '*' if self.editor.document().isModified() else ''
        self.setWindowTitle(f"{dirty}{self._display_name()} — {i18n.tr('app.title_suffix')}")

    def _doc_uri_for_path(self, path):
        if path is None:
            self._untitled_count += 1
            return f'untitled:///untitled-{self._untitled_count}.ezmath'
        return QtCore.QUrl.fromLocalFile(path).toString()

    def _maybe_save(self):
        if self._no_save_prompt:
            return True
        if not self.editor.document().isModified():
            return True
        answer = _qt_question(
            self, i18n.tr('dialog.unsaved_title'),
            i18n.tr('dialog.unsaved_save', name=self._display_name()),
            [('btn.save', QtWidgets.QMessageBox.AcceptRole),
             ('btn.discard', QtWidgets.QMessageBox.DestructiveRole),
             ('btn.cancel', QtWidgets.QMessageBox.RejectRole)])
        if answer == QtWidgets.QMessageBox.AcceptRole:
            return self._save()
        return answer == QtWidgets.QMessageBox.DestructiveRole

    def _switch_document(self, path, text):
        self._close_current_in_lsp()
        self._change_timer.stop()
        self._file_path = path
        self._doc_uri = self._doc_uri_for_path(path)
        self.editor.setPlainText(text)
        self.editor.document().setModified(False)
        self.editor.moveCursor(QtGui.QTextCursor.Start)
        self.problems.clear()
        self.outline.clear()
        self._problems_button.setText('')
        self._open_current_in_lsp()
        self._update_title()
        self._schedule_preview()

    def _new_document(self):
        if not self._maybe_save():
            return
        self._switch_document(None, '')

    def _file_dialog(self, save, title):
        """Open/Save path picker that follows the app theme.

        Native OS dialogs ignore Qt palettes/stylesheets (the Windows
        one can never be dark), so in dark mode a Qt-drawn dialog is
        used and simply inherits the app palette + stylesheet. In light
        mode the native dialog users expect is kept. Returns
        ``(path, selected_filter)`` like the static
        ``QFileDialog.getOpen/SaveFileName`` helpers.
        """
        file_filter = i18n.tr('dialog.file_filter')
        # Always a Qt-drawn dialog: native dialogs cannot be
        # translated (Qt has no Vietnamese catalog) and ignore the
        # app theme. Labels/buttons are set from the catalog.
        dialog = QtWidgets.QFileDialog(self, title, '', file_filter)
        dialog.setOption(QtWidgets.QFileDialog.DontUseNativeDialog, True)
        translate_file_dialog(dialog)
        if save:
            dialog.setAcceptMode(QtWidgets.QFileDialog.AcceptSave)
        else:
            dialog.setFileMode(QtWidgets.QFileDialog.ExistingFile)
        if dialog.exec():
            files = dialog.selectedFiles()
            if files:
                return files[0], dialog.selectedNameFilter()
        return '', ''

    def _open_file(self):
        if not self._maybe_save():
            return
        path, _ = self._file_dialog(False, i18n.tr('dialog.open_title'))
        if not path:
            return
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                text = handle.read()
        except (OSError, UnicodeDecodeError) as e:
            _qt_critical(self, i18n.tr('dialog.open_failed'), str(e))
            return
        self._recent.add(path)
        self._switch_document(path, text)

    def _save(self):
        if self._file_path is None:
            return self._save_as()
        try:
            self._atomic_write(self._file_path, self.editor.toPlainText())
        except (OSError, UnicodeEncodeError) as e:
            _qt_critical(self, i18n.tr('dialog.save_failed'), str(e))
            return False
        self.editor.document().setModified(False)
        self._update_title()
        return True

    @staticmethod
    def _atomic_write(path, text):
        """Write *text* atomically via temp file + os.replace."""
        import tempfile
        directory = os.path.dirname(os.path.abspath(path)) or '.'
        os.makedirs(directory, exist_ok=True)
        try:
            original_mode = os.stat(path).st_mode & 0o777
        except OSError:
            original_mode = None
        fd, tmp = tempfile.mkstemp(dir=directory, prefix='.easymath-save-')
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                handle.write(text)
            if original_mode is not None:
                try:
                    os.chmod(tmp, original_mode)
                except OSError:
                    pass
            os.replace(tmp, path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def _save_as(self):
        path, _ = self._file_dialog(True, i18n.tr('dialog.save_as_title'))
        if not path:
            return False
        try:
            self._atomic_write(path, self.editor.toPlainText())
        except (OSError, UnicodeEncodeError) as e:
            _qt_critical(self, i18n.tr('dialog.save_failed'), str(e))
            return False
        self._recent.add(path)
        from .positions import utf16_units

        cursor_pos = self.editor.textCursor().position()
        text = self.editor.toPlainText()
        self._switch_document(path, text)
        try:
            restored = self.editor.textCursor()
            restored.setPosition(max(0, min(cursor_pos, utf16_units(text))))
            self.editor.setTextCursor(restored)
            self.editor.setFocus()
        except (RuntimeError, ValueError):
            pass
        return True

    # ------------------------------------------------------------------
    # Build: compile current file with the existing compiler CLI logic
    # ------------------------------------------------------------------
    def _compile(self):
        if self.editor.document().isModified():
            answer = _qt_question(
                self, i18n.tr('dialog.unsaved_title'), i18n.tr('dialog.save_before_compile'),
                [('btn.save', QtWidgets.QMessageBox.AcceptRole),
                 ('btn.discard', QtWidgets.QMessageBox.DestructiveRole),
                 ('btn.cancel', QtWidgets.QMessageBox.RejectRole)])
            if answer == QtWidgets.QMessageBox.RejectRole:
                return
            if answer == QtWidgets.QMessageBox.AcceptRole and not self._save():
                return
        if self._file_path is None:
            self.statusBar().showMessage(i18n.tr('status.save_before_compile'), 5000)
            return
        if self._build_process is not None:
            self.statusBar().showMessage(i18n.tr('status.build_running'), 5000)
            return
        cmd = resolve_compiler_command(self._file_path)
        if len(cmd) < 2:
            # A compiler command needs at least [python, ..., file]; an
            # empty argv would fail opaquely.
            self.statusBar().showMessage(i18n.tr('status.could_not_start'), 8000)
            return
        process = QtCore.QProcess(self)
        process.setProcessChannelMode(QtCore.QProcess.MergedChannels)
        process.finished.connect(self._on_build_finished)
        process.errorOccurred.connect(self._on_build_error)
        # '--' separator so a file literally named '--format' etc.
        # is treated as an operand (pipeline.main supports it).
        process.start(cmd[0], cmd[1:-1] + ['--', cmd[-1]])
        self._build_process = process
        self.statusBar().showMessage(i18n.tr('status.compiling'))

    def _on_build_error(self, error):
        # Clear the build state on ANY QProcess error (not just
        # FailedToStart): otherwise later compile attempts silently
        # refuse with "a build is already running".
        proc, self._build_process = self._build_process, None
        if proc is not None:
            try:
                proc.deleteLater()
            except RuntimeError:
                pass
        if error == QtCore.QProcess.ProcessError.FailedToStart:
            self.statusBar().showMessage(i18n.tr('status.could_not_start'), 8000)
        else:
            self.statusBar().showMessage(i18n.tr('status.build_failed'), 8000)

    def _on_build_finished(self, exit_code, _status):
        if getattr(self, '_closing', False):
            # Tearing down (kill() in closeEvent): suppress the spurious
            # failure modal; the process was intentionally terminated.
            proc, self._build_process = self._build_process, None
            if proc is not None:
                try:
                    proc.deleteLater()
                except RuntimeError:
                    pass
            return
        process, self._build_process = self._build_process, None
        output = ''
        if process is not None:
            output = bytes(process.readAllStandardOutput()).decode(
                'utf-8', errors='replace')
            process.deleteLater()
        if exit_code == 0:
            pdf_base, _ = os.path.splitext(self._file_path or '')
            pdf = pdf_base + '.pdf' if pdf_base else '.pdf'
            self.statusBar().showMessage(i18n.tr('status.compiled_to', path=pdf), 8000)
        else:
            _raw = output.strip()[-2000:] or i18n.tr(
                'dialog.compile_failed_code', code=exit_code)
            _qt_critical(
                self, i18n.tr('dialog.compile_failed'),
                friendly_errors.format_for_display(_raw))

    def _export_as(self, fmt):
        """Export the current document to *fmt* (pdf/png/svg/html/typ).

        Works for saved and untitled documents: the editor text is
        exported in-process via :mod:`editor.preview` (same compiler as
        preview/Build), so no save is required. PNG uses 150 DPI by
        default; multi-page PNG/SVG writes ``stem-1.ext`` … next to the
        chosen file.
        """
        fmt = str(fmt or 'pdf').strip().lower()
        if fmt == 'typst':
            fmt = 'typ'
        filters = {
            fmt: i18n.tr(f'export.fmt.{fmt}')
            for fmt in ('pdf', 'png', 'svg', 'html', 'typ')
        }
        filt = filters.get(fmt, 'All files (*)')
        base = ''
        if self._file_path:
            base, _ = os.path.splitext(self._file_path)
            base = f'{base}.{fmt}'
        dialog = QtWidgets.QFileDialog(
            self, i18n.tr('dialog.export_title', fmt=fmt.upper()), base, filt)
        dialog.setOption(QtWidgets.QFileDialog.DontUseNativeDialog, True)
        dialog.setAcceptMode(QtWidgets.QFileDialog.AcceptSave)
        translate_file_dialog(dialog)
        if not dialog.exec():
            return
        files = dialog.selectedFiles()
        if not files:
            return
        path = files[0]
        ppi = None
        if fmt == 'png':
            _ppi_dialog = QtWidgets.QInputDialog(self)
            _ppi_dialog.setWindowTitle(i18n.tr('dialog.png_resolution'))
            _ppi_dialog.setLabelText(i18n.tr('dialog.png_resolution_label'))
            _ppi_dialog.setIntRange(72, 600)
            _ppi_dialog.setIntStep(10)
            _ppi_dialog.setIntValue(150)
            translate_input_dialog(_ppi_dialog)
            ok = _ppi_dialog.exec() == QtWidgets.QDialog.Accepted
            ppi = _ppi_dialog.intValue() if ok else 150
            if not ok:
                return
        try:
            from .preview import export_source_to_file
            res = export_source_to_file(
                self.editor.toPlainText(), path, format=fmt, ppi=ppi,
                source_path=self._file_path)
        except Exception as exc:  # never crash the editor on export
            _qt_critical(
                self, i18n.tr('dialog.export_failed'),
                friendly_errors.format_for_display(
                    i18n.tr('dialog.export_failed_msg', detail=exc)))
            return
        out = res.get('output') if isinstance(res, dict) else None
        outs = res.get('outputs') if isinstance(res, dict) else None
        if out and (os.path.isfile(out) or outs):
            shown = ', '.join(outs) if outs else out
            self.statusBar().showMessage(i18n.tr('status.exported_to', path=shown), 8000)
        else:
            log = (res.get('log') or '').strip() if isinstance(res, dict) else ''
            _qt_critical(
                self, i18n.tr('dialog.export_failed'),
                friendly_errors.format_for_display(
                    log[-2000:] if log else i18n.tr('dialog.export_failed_fallback')))

    # ------------------------------------------------------------------
    # Wiring: menus, editor signals, close
    # ------------------------------------------------------------------
    def _weak_slot(self, meth, *bound):
        """Connect a bound method to a long-lived signal without leaking self.

        PySide keeps a connected *lambda/closure* alive for as long as the
        connection exists, and menu QActions/QShortcuts live as long as the
        window's menubar — so a plain ``lambda: self._foo()`` would keep the
        whole MainWindow (and its ~9 top-level widgets) alive after the caller
        drops it. Bound ``self._foo`` methods are exempt (PySide holds QObject
        receivers weakly), but lambdas that take extra args are not. This
        helper stores only a *weakref* to the receiver plus the bare function,
        so the action can never keep the window alive.

        See tests/test_main_window_leak.py.
        """
        func = meth.__func__                 # bare function: no strong self ref
        ref = weakref.ref(meth.__self__)

        def slot(*_ignored):
            """Weak-referenced callback: call *func* on the target object
            only if it still exists (prevents Qt signal/slot leak)."""
            obj = ref()
            if obj is not None:
                return func(obj, *bound)
        return slot

    def _register(self, widget, text_key, tip_key=None, icon_name=None,
                  **params):
        """Remember a menu/action for retranslate_ui() (language switch)."""
        self._menu_specs.append((widget, text_key, tip_key, params))
        if text_key:
            text = i18n.tr(text_key, **params)
            if hasattr(widget, 'setText'):
                widget.setText(text)
            elif hasattr(widget, 'setTitle'):
                widget.setTitle(text)
        if tip_key and hasattr(widget, 'setStatusTip'):
            widget.setStatusTip(i18n.tr(tip_key, **params))
        if icon_name:
            apply_action_icon(widget, icon_name, SIZE_MENU)
        return widget

    def _create_menus(self):
        file_menu = self.menuBar().addMenu(i18n.tr('menu.file'))
        self._menus['file'] = self._register(file_menu, 'menu.file')
        new_action = file_menu.addAction(i18n.tr('action.new'))
        self._register(new_action, 'action.new', 'action.new.tip', icon_name='file-new')
        new_action.setShortcut(QtGui.QKeySequence.New)
        new_action.triggered.connect(self._new_document)
        open_action = file_menu.addAction(i18n.tr('action.open'))
        self._register(open_action, 'action.open', 'action.open.tip', icon_name='file-open')
        open_action.setShortcut(QtGui.QKeySequence.Open)
        open_action.triggered.connect(self._open_file)
        self._recent_menu = file_menu.addMenu(i18n.tr('action.recent'))
        self._register(self._recent_menu, 'action.recent')
        file_menu.aboutToShow.connect(self._refresh_recent_menu)
        save_action = file_menu.addAction(i18n.tr('action.save'))
        self._register(save_action, 'action.save', 'action.save.tip', icon_name='file-save')
        save_action.setShortcut(QtGui.QKeySequence.Save)
        save_action.triggered.connect(self._save)
        save_as_action = file_menu.addAction(i18n.tr('action.save_as'))
        self._register(save_as_action, 'action.save_as', 'action.save_as.tip', icon_name='file-save-as')
        save_as_action.setShortcut(QtGui.QKeySequence.SaveAs)
        save_as_action.triggered.connect(self._save_as)
        export_menu = file_menu.addMenu(i18n.tr('action.export_as'))
        self._register(export_menu, 'action.export_as', 'action.export_as.tip', icon_name='export')
        self._menus['export'] = export_menu
        for _fmt in ('pdf', 'png', 'svg', 'html', 'typ'):
            _act = export_menu.addAction(i18n.tr(f'export.fmt.{_fmt}'))
            _act.setStatusTip(i18n.tr('action.export.fmt', fmt=_fmt.upper()))
            _act.triggered.connect(self._weak_slot(self._export_as, _fmt))
        file_menu.addSeparator()
        exit_action = file_menu.addAction(i18n.tr('action.exit'))
        self._register(exit_action, 'action.exit', icon_name='exit')
        exit_action.setShortcut(QtGui.QKeySequence.Quit)
        exit_action.triggered.connect(self.close)

        edit_menu = self.menuBar().addMenu(i18n.tr('menu.edit'))
        self._menus['edit'] = self._register(edit_menu, 'menu.edit')
        undo_action = edit_menu.addAction(i18n.tr('action.undo'))
        self._register(undo_action, 'action.undo', icon_name='undo')
        undo_action.setShortcut(QtGui.QKeySequence.Undo)
        undo_action.triggered.connect(self.editor.undo)
        redo_action = edit_menu.addAction(i18n.tr('action.redo'))
        self._register(redo_action, 'action.redo', icon_name='redo')
        redo_action.setShortcut(QtGui.QKeySequence.Redo)
        redo_action.triggered.connect(self.editor.redo)
        edit_menu.addSeparator()
        cut_action = edit_menu.addAction(i18n.tr('action.cut'))
        self._register(cut_action, 'action.cut', icon_name='cut')
        cut_action.setShortcut(QtGui.QKeySequence.Cut)
        cut_action.triggered.connect(self.editor.cut)
        copy_action = edit_menu.addAction(i18n.tr('action.copy'))
        self._register(copy_action, 'action.copy', icon_name='copy')
        copy_action.setShortcut(QtGui.QKeySequence.Copy)
        copy_action.triggered.connect(self.editor.copy)
        paste_action = edit_menu.addAction(i18n.tr('action.paste'))
        self._register(paste_action, 'action.paste', icon_name='paste')
        paste_action.setShortcut(QtGui.QKeySequence.Paste)
        paste_action.triggered.connect(self.editor.paste)
        edit_menu.addSeparator()
        select_all_action = edit_menu.addAction(i18n.tr('action.select_all'))
        self._register(select_all_action, 'action.select_all')
        select_all_action.setShortcut(QtGui.QKeySequence.SelectAll)
        select_all_action.triggered.connect(self.editor.selectAll)
        edit_menu.addSeparator()
        find_action = edit_menu.addAction(i18n.tr('action.find'))
        self._register(find_action, 'action.find', 'action.find.tip', icon_name='find')
        find_action.setShortcut('Ctrl+F')
        find_action.triggered.connect(self._toggle_find)
        goto_action = edit_menu.addAction(i18n.tr('action.goto_line'))
        self._register(goto_action, 'action.goto_line', 'action.goto_line.tip', icon_name='goto-line')
        goto_action.setShortcut('Ctrl+G')
        goto_action.triggered.connect(self._go_to_line)

        view_menu = self.menuBar().addMenu(i18n.tr('menu.view'))
        self._menus['view'] = self._register(view_menu, 'menu.view')
        view_menu.addAction(self._outline_dock.toggleViewAction())
        view_menu.addAction(self._problems_dock.toggleViewAction())
        preview_action = self._preview_dock.toggleViewAction()
        preview_action.setShortcut('Ctrl+Shift+V')
        preview_action.setStatusTip(i18n.tr('preview.status_tip'))
        view_menu.addAction(preview_action)
        self._preview_action = preview_action
        self._theme_action = view_menu.addAction(i18n.tr('action.dark_mode'))
        self._register(self._theme_action, 'action.dark_mode', 'action.dark_mode.tip', icon_name='theme')
        self._theme_action.setCheckable(True)
        self._theme_action.setShortcut('Ctrl+Shift+D')
        self._theme_action.triggered.connect(self._toggle_theme)

        self._auto_close_brackets_action = view_menu.addAction(i18n.tr('action.auto_close'))
        self._register(self._auto_close_brackets_action, 'action.auto_close', 'action.auto_close.tip')
        self._auto_close_brackets_action.setCheckable(True)
        self._auto_close_brackets_action.setChecked(self._auto_close_brackets)
        self._auto_close_brackets_action.setShortcut('Ctrl+Shift+B')
        self._auto_close_brackets_action.triggered.connect(self._toggle_auto_close_brackets)
        self._auto_update_action = view_menu.addAction(i18n.tr('action.auto_updates'))
        self._register(self._auto_update_action, 'action.auto_updates', 'action.auto_updates.tip', icon_name='update')
        self._auto_update_action.setCheckable(True)
        self._auto_update_action.setChecked(self._auto_update_enabled())
        self._auto_update_action.triggered.connect(self._toggle_auto_update)
        view_menu.addSeparator()
        palette_action = view_menu.addAction(i18n.tr('action.palette'))
        self._register(palette_action, 'action.palette', 'action.palette.tip', icon_name='palette')
        palette_action.setShortcut('Ctrl+Shift+P')
        palette_action.triggered.connect(self._show_palette)
        language_action = view_menu.addAction(i18n.tr('action.language'))
        self._register(language_action, 'action.language', 'action.language.tip', icon_name='language')
        language_action.triggered.connect(self._open_language_dialog)
        view_menu.addSeparator()
        zoom_in_action = view_menu.addAction(i18n.tr('action.zoom_in'))
        self._register(zoom_in_action, 'action.zoom_in', 'action.zoom_in.tip', icon_name='zoom-in')
        zoom_in_action.setShortcuts(['Ctrl+=', 'Ctrl++'])
        zoom_in_action.triggered.connect(self._weak_slot(self._zoom, 1))
        zoom_out_action = view_menu.addAction(i18n.tr('action.zoom_out'))
        self._register(zoom_out_action, 'action.zoom_out', 'action.zoom_out.tip', icon_name='zoom-out')
        zoom_out_action.setShortcut('Ctrl+-')
        zoom_out_action.triggered.connect(self._weak_slot(self._zoom, -1))
        zoom_reset_action = view_menu.addAction(i18n.tr('action.zoom_reset'))
        self._register(zoom_reset_action, 'action.zoom_reset', 'action.zoom_reset.tip', icon_name='zoom-reset')
        zoom_reset_action.setShortcut('Ctrl+0')
        zoom_reset_action.triggered.connect(self._zoom_reset)
        font_action = view_menu.addAction(i18n.tr('action.font'))
        self._register(font_action, 'action.font', 'action.font.tip', icon_name='font')
        font_action.triggered.connect(self._choose_editor_font)
        view_menu.addSeparator()
        gallery_action = view_menu.addAction(i18n.tr('action.gallery'))
        self._register(gallery_action, 'action.gallery', 'action.gallery.tip', icon_name='gallery')
        gallery_action.setShortcut('Ctrl+Shift+G')
        gallery_action.triggered.connect(self._open_draw_gallery)

        build_menu = self.menuBar().addMenu(i18n.tr('menu.build'))
        self._menus['build'] = self._register(build_menu, 'menu.build')
        compile_action = build_menu.addAction(i18n.tr('action.compile'))
        self._register(compile_action, 'action.compile', 'action.compile.tip', icon_name='compile')
        compile_action.setShortcut('Ctrl+B')
        compile_action.triggered.connect(self._compile)
        refresh_action = build_menu.addAction(i18n.tr('action.refresh_preview'))
        self._register(refresh_action, 'action.refresh_preview', 'action.refresh_preview.tip', icon_name='refresh')
        refresh_action.setShortcut('F5')
        refresh_action.triggered.connect(self._refresh_preview_now)
        build_menu.addSeparator()
        restart_action = build_menu.addAction(i18n.tr('action.restart_lsp'))
        self._register(restart_action, 'action.restart_lsp', 'action.restart_lsp.tip', icon_name='refresh')
        restart_action.triggered.connect(self._restart_lsp)

        help_menu = self.menuBar().addMenu(i18n.tr('menu.help'))
        self._menus['help'] = self._register(help_menu, 'menu.help')
        examples_menu = help_menu.addMenu(i18n.tr('action.examples'))
        self._register(examples_menu, 'action.examples', 'action.examples.tip', icon_name='examples')
        self._menus['examples'] = examples_menu
        self._example_actions = {}
        for entry_id, name_key, _source_text in EXAMPLES:
            action = examples_menu.addAction(i18n.tr(name_key))
            self._register(action, name_key, icon_name='examples')
            action.triggered.connect(self._weak_slot(self._insert_example, entry_id))
            self._example_actions[entry_id] = action
        welcome_action = help_menu.addAction(i18n.tr('action.welcome'))
        self._register(welcome_action, 'action.welcome', 'action.welcome.tip', icon_name='welcome')
        welcome_action.triggered.connect(self._show_welcome)
        shortcuts_action = help_menu.addAction(i18n.tr('action.shortcuts'))
        self._register(shortcuts_action, 'action.shortcuts', 'action.shortcuts.tip', icon_name='shortcuts')
        shortcuts_action.triggered.connect(self._show_shortcuts)
        update_action = help_menu.addAction(i18n.tr('action.check_updates'))
        self._register(update_action, 'action.check_updates', 'action.check_updates.tip', icon_name='update')
        update_action.triggered.connect(self._manual_update_check)
        about_action = help_menu.addAction(i18n.tr('action.about'))
        self._register(about_action, 'action.about', 'action.about.tip', icon_name='about')
        about_action.triggered.connect(self._show_about)

        self._toolbar = self.addToolBar(i18n.tr('toolbar.main'))
        self._toolbar.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self._toolbar.setIconSize(QtCore.QSize(SIZE_TOOLBAR, SIZE_TOOLBAR))
        self._toolbar.addAction(new_action)
        self._toolbar.addAction(open_action)
        self._toolbar.addAction(save_action)
        self._toolbar.addSeparator()
        self._toolbar.addAction(compile_action)

        find_next_shortcut = QtGui.QShortcut(QtGui.QKeySequence.StandardKey.FindNext, self)
        find_next_shortcut.activated.connect(self._weak_slot(self._find_again, 1))
        find_prev_shortcut = QtGui.QShortcut(QtGui.QKeySequence.StandardKey.FindPrevious, self)
        find_prev_shortcut.activated.connect(self._weak_slot(self._find_again, -1))

    # ------------------------------------------------------------------
    # Language (i18n) and newcomer help
    # ------------------------------------------------------------------
    def _apply_language(self, locale, save=True):
        """Switch the interface language without touching the document.

        Editor text, cursor, file path, LSP state and preview are all
        preserved; only static UI chrome is re-translated in place.
        """
        locale = i18n.normalize_locale(locale) or 'en'
        i18n.set_locale(locale)
        self._language = locale
        if save:
            i18n.save_setting_language(self._settings, locale)
        self.retranslate_ui()

    def retranslate_ui(self):
        """Re-apply every translated string in place (language switch)."""
        for widget, text_key, tip_key, params in self._menu_specs:
            try:
                if text_key:
                    text = i18n.tr(text_key, **params)
                    if hasattr(widget, 'setText'):
                        widget.setText(text)
                    elif hasattr(widget, 'setTitle'):
                        widget.setTitle(text)
                if tip_key and hasattr(widget, 'setStatusTip'):
                    widget.setStatusTip(i18n.tr(tip_key, **params))
            except (RuntimeError, AttributeError):
                pass
        self._outline_dock.setWindowTitle(i18n.tr('dock.outline'))
        self._problems_dock.setWindowTitle(i18n.tr('dock.problems'))
        self._preview_dock.setWindowTitle(i18n.tr('dock.preview'))
        # Dynamic update chrome (banner has its own text/size retranslate).
        for widget in (getattr(self, '_update_banner', None),
                       getattr(self, '_update_dialog', None)):
            if widget is not None:
                try:
                    widget.retranslate_ui()
                except (RuntimeError, AttributeError):
                    pass
        for dock, key in ((self._outline_dock, 'dock.outline'),
                          (self._problems_dock, 'dock.problems'),
                          (self._preview_dock, 'dock.preview')):
            try:
                dock.toggleViewAction().setText(i18n.tr(key))
            except (RuntimeError, AttributeError):
                pass
        try:
            self._preview_action.setStatusTip(i18n.tr('preview.status_tip'))
        except AttributeError:
            pass
        try:
            self._toolbar.setWindowTitle(i18n.tr('toolbar.main'))
        except AttributeError:
            pass
        self._problems_button.setToolTip(i18n.tr('status.show_problems'))
        count = self.problems.count()
        self._problems_button.setText(
            i18n.tr('status.problems', count=count) if count else '')
        connected = False
        try:
            connected = bool(self.lsp.is_connected())
        except Exception:
            connected = 'Connected' in self._lsp_label.text()
        self._lsp_label.setText(
            i18n.tr('status.lsp_connected') if connected
            else i18n.tr('status.lsp_disconnected'))
        line, col = self.editor.cursor_line_col()
        self._cursor_label.setText(
            i18n.tr('status.cursor', line=line + 1, col=col + 1))
        self.editor.retranslate_ui()
        self._symbol_bar.retranslate_ui()
        self._find_bar.retranslate_ui()
        self.preview.retranslate_ui()
        self._welcome_panel.retranslate_ui()
        # Refresh problem rows so friendly text follows the language.
        try:
            diagnostics = list(self.problems._diagnostics)
            if diagnostics:
                self.problems.set_diagnostics(diagnostics)
        except Exception:
            pass
        if self._draw_gallery is not None:
            self._draw_gallery.retranslate_ui()
        if self._draw_template is not None:
            self._draw_template.retranslate_ui()
        self._update_title()

    def _open_language_dialog(self):
        """Language picker (View -> Language); persists the choice."""
        dialog = QtWidgets.QDialog(self)
        dialog.setObjectName('languageDialog')
        dialog.setWindowTitle(i18n.tr('language.title'))
        layout = QtWidgets.QVBoxLayout(dialog)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.addWidget(QtWidgets.QLabel(i18n.tr('language.label'), dialog))
        combo = QtWidgets.QComboBox(dialog)
        combo.addItem(i18n.tr('language.english'), 'en')
        combo.addItem(i18n.tr('language.vietnamese'), 'vi')
        combo.addItem(i18n.tr('language.system'), 'system')
        saved = self._settings.value(i18n.LANGUAGE_SETTING, 'system')
        saved = saved[0] if isinstance(saved, (list, tuple)) and saved else saved
        index = combo.findData(saved if saved in ('en', 'vi', 'system') else 'system')
        combo.setCurrentIndex(max(0, index))
        layout.addWidget(combo)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok,
            dialog)
        buttons.button(QtWidgets.QDialogButtonBox.Ok).setText(
            i18n.tr('language.ok'))
        buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText(
            i18n.tr('language.cancel'))
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QtWidgets.QDialog.Accepted:
            return
        choice = combo.currentData()
        if choice == 'system':
            locale = i18n.detect_system_locale(
                QtCore.QLocale.system().name())
            try:
                self._settings.setValue(i18n.LANGUAGE_SETTING, 'system')
                self._settings.sync()
            except Exception:
                pass
            i18n.set_locale(locale)
            self._language = locale
            self.retranslate_ui()
            return
        self._apply_language(choice, save=True)

    def maybe_show_welcome(self):
        """Show the welcome banner once, on first run (called by app.main)."""
        try:
            show = self._settings.value('ui/showWelcome', True, type=bool)
        except Exception:
            show = True
        if show:
            self._welcome_panel.show()

    def _show_welcome(self):
        self._welcome_panel.show()

    def _dismiss_welcome(self):
        if self._welcome_panel.property('dont-show-again'):
            try:
                self._settings.setValue('ui/showWelcome', False)
                self._settings.sync()
            except Exception:
                pass
        self._welcome_panel.hide()

    def _insert_example(self, key):
        """Insert a ready-to-run example at the cursor (one undo step)."""
        source = example_source(key) if isinstance(key, str) else ''
        if not source:
            return
        self._welcome_panel.hide()
        if self._welcome_panel.property('dont-show-again'):
            self._dismiss_welcome()
        cursor = self.editor.textCursor()
        cursor.beginEditBlock()
        try:
            if cursor.position() > 0:
                cursor.insertText('\n')
            cursor.insertText(source)
        finally:
            cursor.endEditBlock()
        self.editor.setTextCursor(cursor)
        self.editor.ensureCursorVisible()
        self.editor.setFocus()

    def _show_shortcuts(self):
        ShortcutsDialog(self).exec()

    def _show_about(self):
        dialog = AboutDialog(parent=self)
        dialog.checkUpdatesRequested.connect(self._manual_update_check)
        dialog.exec()

    # ------------------------------------------------------------------
    # Updates — check, notice, download, self-install
    # ------------------------------------------------------------------
    def _auto_update_enabled(self):
        try:
            return bool(self._settings.value('update/autoCheck', True,
                                             type=bool))
        except (TypeError, ValueError, RuntimeError):
            return True

    def _toggle_auto_update(self, checked):
        try:
            self._settings.setValue('update/autoCheck', bool(checked))
            self._settings.sync()
        except (TypeError, ValueError, RuntimeError):
            pass
        # Mirror into the compiler-owned state file (both locations
        # carry the flag; the compiler ignores the config file).
        try:
            from compiler import update as _update

            _update.set_auto_check(bool(checked))
        except Exception:
            pass

    def _auto_update_check(self):
        if self._closing:
            return
        # Escape hatch for tests and scripts (mirrors EZMATH_NO_IME_FIX).
        if os.environ.get('EZMATH_NO_AUTO_UPDATE') == '1':
            return
        if not self._auto_update_enabled():
            return
        self._start_update_check(interactive=False)

    def _manual_update_check(self):
        self._start_update_check(interactive=True)

    def _start_update_check(self, interactive):
        if getattr(self, '_update_inflight', False):
            return
        self._update_inflight = True
        self._update_manual = bool(interactive)
        # Runs in the background thread; the worker emits `done`.
        self._update_request.emit(bool(interactive))

    @QtCore.Slot(object)
    def _on_update_check_done(self, payload):
        self._update_inflight = False
        manual = bool(self._update_manual)
        if not payload.get('ok'):
            if manual:
                _qt_critical(self, i18n.tr('update.dialog_title'),
                             i18n.tr('update.check_failed',
                                     reason=payload.get('error') or '?'))
            return
        if payload.get('status') != 'newer' or payload.get('latest') is None:
            if manual:
                self.statusBar().showMessage(
                    i18n.tr('update.up_to_date'), 5000)
            return
        self._update_payload = payload
        if payload.get('skipped'):
            # The user asked to skip this exact version; stay quiet
            # unless they explicitly opened the dialog.
            return
        latest = payload['latest']
        self._update_banner_payload = payload
        self._update_banner.set_info(payload.get('current', ''), latest.version)
        self._update_banner.show()
        if manual:
            self._open_update_dialog()

    def _show_update_banner(self):
        if self._update_banner_payload is not None:
            self._update_banner.show()

    def _dismiss_update_banner(self):
        self._update_banner.hide()

    def _open_update_dialog(self):
        payload = getattr(self, '_update_payload', None)
        if not payload or payload.get('latest') is None:
            return
        info = payload['latest']
        dialog = self._update_dialog
        if dialog is None:
            dialog = UpdateDialog(self)
            dialog.updateNowRequested.connect(self._on_update_now)
            dialog.downloadRequested.connect(self._on_download_requested)
            dialog.skipRequested.connect(self._on_skip_requested)
            dialog.cancelDownloadRequested.connect(
                self._cancel_update_download)
            dialog.finished.connect(self._on_update_dialog_closed)
            self._update_dialog = dialog
        platform_note = None
        method = payload.get('method') or 'unknown'
        if method == 'windows':
            platform_note = 'update.uac_note'
        elif method in ('debian', 'fedora', 'arch'):
            platform_note = 'update.polkit_note'
        elif method == 'macos':
            platform_note = 'update.macos_note'
        dialog.configure(info, payload.get('current', ''),
                         bool(payload.get('one_click')), platform_note,
                         payload.get('asset'))
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    def _on_update_dialog_closed(self, _result):
        self._update_dialog = None

    def _on_skip_requested(self):
        payload = getattr(self, '_update_payload', None)
        version = ''
        if payload and payload.get('latest') is not None:
            version = payload['latest'].version
        try:
            from compiler import update as _update

            _update.skip_version(version)
        except Exception:
            pass
        self._update_banner.hide()
        self.statusBar().showMessage(
            i18n.tr('update.skip_done', version=version), 5000)

    def _on_download_requested(self):
        payload = getattr(self, '_update_payload', None)
        if not payload:
            return
        info = payload['latest']
        asset = payload.get('asset')
        url = asset.download_url if asset is not None else info.html_url
        QtGui.QDesktopServices.openUrl(QtCore.QUrl(url))

    def _on_update_now(self):
        payload = getattr(self, '_update_payload', None)
        if not payload:
            return
        asset = payload.get('asset')
        sums = payload.get('sums')
        info = payload['latest']
        if asset is None or sums is None:
            if self._update_dialog is not None:
                self._update_dialog.set_error(
                    i18n.tr('update.unsupported'))
            return
        # Reuse the existing close/save logic: unsaved documents are
        # saved (or the update is aborted) with the same prompt the
        # window close uses.
        if not self._maybe_save():
            return
        self._start_update_download(info, asset, sums)

    def _start_update_download(self, info, asset, sums):
        if self._update_download_thread is not None:
            return
        dialog = self._update_dialog
        thread = QtCore.QThread(self)
        worker = UpdateDownloadWorker(asset, sums.download_url)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_download_progress)
        worker.finished.connect(self._on_download_finished)
        worker.failed.connect(self._on_download_failed)
        worker.cancelled.connect(self._on_download_cancelled)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        worker.cancelled.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self._on_download_thread_finished)
        self._update_download_thread = thread
        self._update_download_worker = worker
        if dialog is not None:
            dialog.set_busy(i18n.tr('update.downloading', name=asset.name))
        thread.start()

    def _on_download_progress(self, downloaded, total):
        if self._update_dialog is not None:
            self._update_dialog.set_progress(downloaded, total)

    def _on_download_finished(self, result):
        # The download (and its SHA-256 verification) succeeded. Stage
        # the helper plan and spawn the detached installer; the app
        # then quits through its normal close path.
        payload = getattr(self, '_update_payload', None)
        info = payload['latest'] if payload else None
        method = payload.get('method') if payload else None
        try:
            from compiler import updater as _updater
            from compiler import update as _update

            staged_ok = self._stage_and_spawn(_updater, info, method,
                                              result)
        except Exception as exc:
            staged_ok = str(exc)
        if staged_ok is True:
            if self._update_dialog is not None:
                self._update_dialog.set_installing()
            self.statusBar().showMessage(i18n.tr('update.installing'), 4000)
            # Give the status row a beat to paint, then quit cleanly.
            QtCore.QTimer.singleShot(600, self.close)
            return
        if self._update_dialog is not None:
            self._update_dialog.set_error(str(staged_ok))

    def _stage_and_spawn(self, _updater, info, method, result):
        if info is None or method is None:
            return 'missing update metadata'
        method_info = _updater.InstallInfo(method, True, '')
        plan_path = _updater.stage_update_plan(
            info, method_info, result, relaunch_argv=[sys.executable],
            pid=os.getpid())
        _updater.spawn_helper(plan_path)
        return True

    def _on_download_failed(self, reason):
        if self._update_dialog is not None:
            self._update_dialog.set_error(reason)

    def _on_download_cancelled(self):
        if self._update_dialog is not None:
            self._update_dialog.set_ready()

    def _cancel_update_download(self):
        worker = getattr(self, '_update_download_worker', None)
        if worker is not None:
            worker.cancel()

    def _on_download_thread_finished(self):
        self._update_download_thread = None
        self._update_download_worker = None

    def maybe_show_update_failure(self):
        """Show the "last update failed" notice once (next start)."""
        # A Windows self-update handed off to the installer detached
        # detects its outcome here: the running version vs the pending
        # version. Success stays silent; failure is recorded for the
        # notice below (which shows exactly once).
        try:
            from compiler import updater as _updater

            resolved = _updater.resolve_pending_update()
        except Exception:
            resolved = None
        if isinstance(resolved, dict) and resolved.get('ok'):
            try:
                self.statusBar().showMessage(
                    i18n.tr('update.installed_done',
                            version=resolved.get('version', '')), 8000)
            except Exception:
                pass
        try:
            from compiler import update as _update

            failure = _update.last_update_error()
        except Exception:
            return
        if not failure:
            return
        # Consume it now so it is shown exactly once, even if the
        # dialog is dismissed without being read.
        try:
            from compiler import update as _update

            _update.clear_update_error()
        except Exception:
            pass
        dialog = UpdateFailedDialog(failure.get('reason'),
                                    failure.get('log_path'), parent=self)
        dialog.downloadRequested.connect(self._download_update_manually)
        self._update_failed_dialog = dialog
        dialog.show()

    def _download_update_manually(self):
        from compiler import update as _update

        QtGui.QDesktopServices.openUrl(
            QtCore.QUrl(_update.RELEASES_PAGE_URL))

    # ------------------------------------------------------------------
    # Editor text size
    # ------------------------------------------------------------------
    _MIN_FONT_SIZE = 6.0
    _MAX_FONT_SIZE = 48.0

    def _set_editor_font_size(self, size):
        clamped = max(self._MIN_FONT_SIZE, min(self._MAX_FONT_SIZE, size))
        font = self.editor.font()
        font.setPointSizeF(clamped)
        self.editor.setFont(font)
        self._refresh_tab_stops()

    def _refresh_tab_stops(self):
        """Keep tab width at 4 spaces of the current editor font."""
        try:
            self.editor.setTabStopDistance(
                4 * self.editor.fontMetrics().horizontalAdvance(' '))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    def _zoom(self, step):
        self._set_editor_font_size(self.editor.font().pointSizeF() + step)

    def _zoom_reset(self):
        self._set_editor_font_size(self._default_font_size)

    # ------------------------------------------------------------------
    # Editor font family (persisted in QSettings alongside the theme)
    # ------------------------------------------------------------------
    _FONT_FAMILY_KEY = 'editor/fontFamily'
    _FONT_SIZE_KEY = 'editor/fontSize'

    def _apply_editor_font(self):
        """Apply the stored editor font, if any (called once at startup)."""
        try:
            family = self._settings.value(self._FONT_FAMILY_KEY, '')
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return
        try:
            size = self._settings.value(self._FONT_SIZE_KEY, '')
        except (AttributeError, RuntimeError, TypeError, ValueError):
            size = ''
        if (isinstance(family, str) and family.strip()) or size not in ('', None):
            self._set_editor_font(family, size, save=False)

    def _coerce_font_size(self, size):
        try:
            value = float(size)
        except (TypeError, ValueError):
            return None
        if value != value or value in (float('inf'), float('-inf')):
            return None
        return max(self._MIN_FONT_SIZE, min(self._MAX_FONT_SIZE, value))

    def _set_editor_font(self, family, size, save=True):
        """Apply a font family/size pair; persists when *save* is true.

        Blank family keeps the current family; invalid sizes are ignored
        (at least one of the two must be usable, else nothing changes).
        Returns True when anything was applied.
        """
        current = self.editor.font()
        new_family = current.family()
        if isinstance(family, str) and family.strip():
            new_family = family.strip()
        new_size = self._coerce_font_size(size)
        if new_size is None:
            try:
                _sz = float(current.pointSizeF())
                # -1 (pixel-size fonts) is truthy but useless; keep default.
                new_size = _sz if _sz > 0 else self._default_font_size
            except (TypeError, ValueError):
                new_size = self._default_font_size
        if new_family == current.family() and new_size == current.pointSizeF():
            return False
        font = QtGui.QFont(current)
        font.setFamily(new_family)
        font.setPointSizeF(new_size)
        self.editor.setFont(font)
        self._default_font_size = float(self.editor.font().pointSizeF())
        self._refresh_tab_stops()
        if save:
            try:
                self._settings.setValue(self._FONT_FAMILY_KEY, new_family)
                self._settings.setValue(self._FONT_SIZE_KEY, new_size)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass
        return True

    def _choose_editor_font(self):
        current = self.editor.font()
        font, ok = QtWidgets.QFontDialog.getFont(current, self, i18n.tr('dialog.font_title'))
        if not ok:
            return
        try:
            family = font.family()
        except (AttributeError, RuntimeError):
            return
        try:
            size = float(font.pointSizeF())
        except (AttributeError, RuntimeError, TypeError, ValueError):
            size = None
        self._set_editor_font(family, size)

    # ------------------------------------------------------------------
    # Theme (light/dark mode, persisted in QSettings)
    # ------------------------------------------------------------------
    def _apply_theme(self, name, save=True):
        name = app_theme.normalize(name)
        self._theme_name = name
        app = QtWidgets.QApplication.instance()
        if app is not None:
            palette = app_theme.build_palette(name)
            if palette is not None:
                app.setPalette(palette)
            elif self._default_palette is not None:
                app.setPalette(self._default_palette)
            try:
                app.setStyleSheet(app_theme.stylesheet(name))
            except Exception:
                pass
        # Qt-drawn menu bar honors palette/stylesheet; the native OS
        # menu bar does not, so keep it embedded.
        try:
            self.menuBar().setNativeMenuBar(False)
        except Exception:
            pass
        self._set_title_bar_dark(name == app_theme.DARK)
        try:
            from .icons import set_theme_dark

            set_theme_dark(name == app_theme.DARK)
        except Exception:
            pass
        self.editor.set_theme(name)
        colors = app_theme.editor_colors(name)
        self._find_all_color = QtGui.QColor(colors['find_all'])
        self._find_current_color = QtGui.QColor(colors['find_current'])
        self._refresh_find_colors()
        action = getattr(self, '_theme_action', None)
        if action is not None:
            action.setChecked(name == app_theme.DARK)
        if save:
            app_theme.save_theme_name(self._settings, name)

    def _set_title_bar_dark(self, dark):
        """Dark/light OS title bar for the main window AND every dialog.

        The app-wide filter covers windows shown later (QMessageBox,
        QInputDialog, file dialogs, ...); set_dark() also refreshes
        windows that are already visible.
        """
        app = QtWidgets.QApplication.instance()
        themer = None
        if app is not None:
            themer = getattr(app, '_title_themer', None)
        if themer is None:
            themer = app_theme.TitleBarThemer(dark, parent=app)
            if app is not None:
                try:
                    app.installEventFilter(themer)
                except RuntimeError:
                    pass
                app._title_themer = themer
            self._title_themer = themer
        else:
            self._title_themer = themer
        try:
            themer.set_dark(dark)
        except RuntimeError:
            pass
        app_theme.set_title_bar_dark(self, dark)

    def _toggle_theme(self):
        self._apply_theme(app_theme.DARK
                          if self._theme_name != app_theme.DARK
                          else app_theme.LIGHT)
    
    def _toggle_auto_close_brackets(self):
        """Toggle auto-close brackets setting and update the editor."""
        if hasattr(self, '_auto_close_brackets_action'):
            value = self._auto_close_brackets_action.isChecked()
            self._auto_close_brackets = value
            self._settings.setValue('editor/autoCloseBrackets', value)
            self._settings.sync()
            self.editor._auto_close_brackets = value

    def _refresh_find_colors(self):
        """Re-paint active find highlights without moving the cursor."""
        ranges = getattr(self, '_find_ranges', None)
        if not ranges:
            self._clear_find_highlights()
            return
        try:
            doc_len = self.editor.document().characterCount()
        except Exception:
            doc_len = None
        safe = []
        for s, e in ranges:
            try:
                s, e = int(s), int(e)
            except (TypeError, ValueError):
                continue
            if doc_len is not None:
                s = max(0, min(s, doc_len))
                e = max(0, min(e, doc_len))
            if e < s:
                s, e = e, s
            safe.append((s, e))
        if not safe:
            self._clear_find_highlights()
            return
        self._find_ranges = safe
        current = getattr(self, '_find_current_index', 0)
        try:
            current = int(current)
        except (TypeError, ValueError):
            current = 0
        current = max(0, min(current, len(safe) - 1))
        self._find_current_index = current
        self._clear_find_highlights()
        self._highlight_find_ranges(
            safe, current)

    def _connect_editor(self):
        self.editor.cursorMoved.connect(self._on_cursor_moved)
        self.editor.textChanged.connect(self._on_text_changed)
        self.editor.document().modificationChanged.connect(self._update_title)
        self.editor.completionRequested.connect(self._on_completion_requested)
        self.editor.hoverRequested.connect(self._on_hover_requested)
        self.problems.diagnosticActivated.connect(self._goto_range)
        self.outline.symbolActivated.connect(self._goto)

    def _on_cursor_moved(self, line, col):
        self._cursor_label.setText(
            i18n.tr('status.cursor', line=line + 1, col=col + 1))

    def _on_text_changed(self):
        lsp = getattr(self, 'lsp', None)
        if lsp is not None and lsp.is_connected() and self._lsp_open:
            self._change_timer.start()
        self._schedule_preview()

    # ------------------------------------------------------------------
    # Live preview (debounced, background compile, stale results dropped)
    # ------------------------------------------------------------------
    def _preview_visible_and_auto(self):
        return self._preview_dock.isVisible() and self._preview_auto

    def _schedule_preview(self):
        self._preview_version += 1
        if not self._preview_auto:
            return
        if not self._preview_dock.isVisible():
            return
        self._preview_timer.start()

    def _refresh_preview_now(self, force=False):
        if not self._preview_dock.isVisible():
            self._preview_dock.show()
            self._preview_dock.raise_()
        self._preview_version += 1
        self._preview_timer.stop()
        self._on_preview_timeout(force=True)

    def _on_preview_visibility(self, _visible):
        # Opening the dock renders immediately; hiding cancels pending work
        # (a running compile still finishes but its result is dropped).
        if self._preview_dock.isVisible() and self._preview_auto:
            self._preview_version += 1
            self._on_preview_timeout()
        else:
            self._preview_timer.stop()

    def _on_preview_auto(self, enabled):
        self._preview_auto = bool(enabled)
        if self._preview_auto:
            self._schedule_preview()
        else:
            self._preview_timer.stop()

    def _on_preview_timeout(self, force=False):
        if not force and (not self._preview_auto or not self._preview_dock.isVisible()):
            return
        if not self._preview_dock.isVisible():
            return
        version = self._preview_version
        text = self.editor.toPlainText()
        if not force and text == self._last_preview_text:
            return
        self._last_preview_text = text
        self.preview.show_loading()
        self._preview_request.emit(
            version, text, self._preview_workdir, self._file_path or '')

    def _on_preview_finished(self, version, result):
        if version != self._preview_version:
            # Stale render: clean up its versioned PDF so temp does not grow.
            try:
                stale_pdf = result.get('pdf') if isinstance(result, dict) else None
                if stale_pdf and os.path.isfile(stale_pdf):
                    os.unlink(stale_pdf)
            except OSError:
                pass
            return  # stale: user kept typing while compiling
        if not isinstance(result, dict):
            return
        if result.get('ok') and result.get('pdf'):
            old_pdf = getattr(self.preview, 'pdf_path', None)
            self.preview.show_pdf(result['pdf'])
            try:
                self.preview.set_source_map(result.get('smap'))
            except Exception:
                pass
            # Delete the previous versioned PDF now that the new one is loaded.
            try:
                if old_pdf and old_pdf != result['pdf'] and os.path.isfile(old_pdf):
                    # Only clean our preview files, never user documents.
                    if os.path.basename(old_pdf).startswith('preview'):
                        os.unlink(old_pdf)
            except OSError:
                pass
            return
        log = (result.get('log') or '').strip()
        self.preview.show_error(
            friendly_errors.format_for_display(
                log[-2000:] if log else i18n.tr('preview.failed_fallback')))

    def _on_preview_source_link(self, typ_line, typ_column):
        """Navigate from a preview source-link activation to the .eml span.

        Reuses ``PreviewPanel.typ_location_to_eml`` (sidecar map) and
        ``open_source_location`` (cursor + visibility). Unmapped/missing
        locations show a transient status message instead of navigating.
        """
        try:
            span = self.preview.typ_location_to_eml(typ_line, typ_column)
        except Exception:
            span = None
        if span is None:
            try:
                self.statusBar().showMessage(
                    i18n.tr('status.no_source_mapping'), 3000)
            except (AttributeError, RuntimeError, TypeError):
                pass
            return
        try:
            self.open_source_span(span)
        except Exception:
            pass

    def _open_preview_externally(self):
        pdf = getattr(self.preview, 'pdf_path', None)
        if not pdf:
            self.statusBar().showMessage(i18n.tr('status.no_preview'), 3000)
            return
        QtGui.QDesktopServices.openUrl(
            QtCore.QUrl.fromLocalFile(pdf))

    def _shutdown_preview(self):
        if getattr(self, '_preview_shutdown', False):
            return
        self._preview_shutdown = True
        try:
            self._preview_timer.stop()
        except RuntimeError:
            pass
        thread = getattr(self, '_preview_thread', None)
        worker = getattr(self, '_preview_worker', None)
        if thread is not None:
            if worker is not None:
                try:
                    # Delete the worker inside its own thread, before
                    # the loop quits, so the deferred delete actually
                    # runs (posting to a stopped loop never does).
                    QtCore.QMetaObject.invokeMethod(
                        worker, 'deleteLater',
                        QtCore.Qt.ConnectionType.QueuedConnection)
                except RuntimeError:
                    pass
            thread.quit()
            if not thread.wait(3000):
                # Compile running >3s: terminate to avoid destroying a
                # live QThread (Qt fatal), then wait briefly and abandon
                # (never block close indefinitely).
                try:
                    thread.terminate()
                except RuntimeError:
                    pass
                thread.wait(3000)
        workdir = getattr(self, '_preview_workdir', None)
        if workdir:
            shutil.rmtree(workdir, ignore_errors=True)
        self._shutdown_update_threads()

    def _shutdown_update_threads(self):
        """Stop the update check/download threads without leaking them."""
        if getattr(self, '_update_threads_shutdown', False):
            return
        self._update_threads_shutdown = True
        # A download in flight is cancelled and given a chance to unwind.
        worker = getattr(self, '_update_download_worker', None)
        if worker is not None:
            try:
                worker.cancel()
            except RuntimeError:
                pass
        for attr in ('_update_check_thread', '_update_download_thread'):
            thread = getattr(self, attr, None)
            if thread is None:
                continue
            try:
                thread.quit()
                if not thread.wait(3000):
                    thread.terminate()
                    thread.wait(1000)
            except RuntimeError:
                pass
        self._update_check_thread = None
        self._update_download_thread = None
        self._update_check_worker = None
        self._update_download_worker = None

    def __del__(self):
        # Destroying a MainWindow via Python GC (tests drop the reference
        # without calling close()) must still stop the preview worker QThread
        # — a QThread parented to a QWidget is destroyed with it, and Qt is
        # fatal if that thread is still running. closeEvent covers the
        # interactive path; this covers the GC path. Idempotent via the
        # _preview_shutdown guard in _shutdown_preview().
        try:
            self._shutdown_preview()
        except Exception:
            pass

    def open_path(self, path):
        """Open a file (used for a launch argument)."""
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                text = handle.read()
        except (OSError, UnicodeDecodeError) as e:
            _qt_critical(self, i18n.tr('dialog.open_failed'), str(e))
            return
        self._recent.add(path)
        self._switch_document(path, text)

    def closeEvent(self, event):
        """Handle window close: prompt to save, stop preview/build,
        shut down the LSP client, then accept or ignore the close."""
        if self._closing:
            # Second pass: shutdown completed (or was forced).
            self._shutdown_preview()
            event.accept()
            return
        if not self._maybe_save():
            event.ignore()
            return
        # Mark closing FIRST so any queued build/preview finished
        # signals are suppressed instead of popping a modal on a
        # tearing-down window.
        self._closing = True
        self._restart_pending = False
        self._reopen_after_connect = False
        self._change_timer.stop()
        self._preview_timer.stop()
        self._close_current_in_lsp()
        if self._build_process is not None:
            try:
                self._build_process.finished.disconnect(self._on_build_finished)
            except (RuntimeError, TypeError):
                pass
            try:
                self._build_process.kill()
            except RuntimeError:
                pass
            self._build_process = None
        if self.lsp.state == 'stopped':
            self._shutdown_preview()
            event.accept()
            return
        # The LSP shutdown handshake (shutdown -> response -> exit ->
        # process exit) is asynchronous: defer the close until the process
        # is gone so Qt never destroys a live QProcess.  A watchdog
        # forces the close if shutdown hangs.
        self.statusBar().showMessage(i18n.tr('status.shutting_down'))
        watchdog = QtCore.QTimer(self)
        watchdog.setSingleShot(True)
        watchdog.timeout.connect(self._force_close)
        watchdog.start(5000)
        self._watchdog = watchdog
        self.lsp.stop()
        event.ignore()

    def _force_close(self):
        """Last-resort close when LSP shutdown hangs."""
        if not self._closing:
            return
        try:
            self.lsp.abort()
        except RuntimeError:
            pass  # Qt objects already destroyed during teardown
        try:
            self.close()
        except RuntimeError:
            pass
