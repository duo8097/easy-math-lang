"""Registration of geometry commands into the solver."""

import re
import sys

from .errors import GeometryError
from .vectors import _cross2d, _norm

POINT_NAME_RE = re.compile(r'^[A-Za-z][A-Za-z0-9_]*$')


def parse_numeric_arg(text):
    """Parse a user-typed number, tolerating thousands commas.

    ``1,000`` / ``100,000`` -> 1000.0. Only strict thousands groups
    (1-3 leading digits, then groups of exactly 3 digits) are accepted;
    anything else containing a comma (e.g. ``3,5`` — use ``3.5`` for
    decimals) raises ValueError so callers report their usual
    "must be numeric" error. Decimal separator is a dot.
    """
    s = text.strip()
    # Tolerate sign and decimals: -1,000, 1,000.5
    if ',' in s:
        t = s.lstrip('+-')
        if not re.fullmatch(r'\d{1,3}(?:,\d{3})+(?:\.\d+)?', t):
            raise ValueError(f'invalid number {text!r}')
        s = ('-' if s.startswith('-') else '+' if s.startswith('+') else '') + t.replace(',', '')
    return float(s)


def _check_point_name(name):
    if not POINT_NAME_RE.match(name):
        raise GeometryError(f"invalid point name {name!r} — use letters, digits, '_' starting with a letter")
    return name


def _bad_len(n):
    """True when a segment length is unusable (non-finite or degenerate).

    Plain ``n < 1e-9`` is False for NaN, letting diverged coordinates
    slip through to ``dot/(n1*n2)`` and poison costs with NaN.
    """
    import math as _m
    try:
        f = float(n)
    except (TypeError, ValueError):
        return True
    return (not _m.isfinite(f)) or f < 1e-9


def _seg_cost(P, A, B, fn):
    """Cost with degenerate-segment guard: coincident points cost 1.0."""
    if _bad_len(_norm(P[B] - P[A])):
        return 1.0
    return fn()

KNOWN_GEOMETRY_COMMANDS = {
    'point', 'line', 'ray', 'circle', 'triangle', 'right-angle', 'angle',
    'equal-angle', 'equal-length', 'parallel', 'perp', 'on-line', 'on-circle',
    'distance', 'midpoint', 'intersection', 'arc', 'label',
    'length', 'angle-value',
}


def _process_command(solver, cmd, args):
    """Register a geometry command into the solver."""
    # Imported here (not at module top) so merely referencing command
    # names — e.g. the editor symbol palette — never pulls NumPy in.
    import numpy as np

    if cmd not in KNOWN_GEOMETRY_COMMANDS:
        raise GeometryError(f"unknown geometry command *{cmd} — ignored")

    if cmd == 'point':
        if not args or not args[0]:
            raise GeometryError("*point() requires a name argument")
        if len(args) > 1:
            raise GeometryError(f"*point() takes 1 argument, got {len(args)}: {'; '.join(args)}")
        if '=' in args[0]:
            name, coords = args[0].split('=', 1)
            name = name.strip()
            _check_point_name(name)
            rhs = coords.strip()
            if re.match(r'^[A-Za-z][A-Za-z0-9_]*\s*\(', rhs):
                # Construction: *point(M = midpoint(A ; B)) — the point
                # is computed analytically from its inputs (derived,
                # never a free variable for the solver). Imported here
                # (not at module top) so the editor/LSP can reference
                # command tables without pulling the construction parser.
                from .constructions import parse_construction

                construction = parse_construction(rhs)
                # Referenced inputs auto-create like everywhere else
                # (coordinates are optional); explicit coordinates
                # given later still win.
                for dep in sorted(construction.deps):
                    solver.add_point(dep)
                solver.add_derived_point(
                    name,
                    construction.deps,
                    construction.compute,
                    f"*point({name} = {construction.text})",
                )
            else:
                try:
                    # Split on the LAST comma: x may itself use thousands
                    # separators ("1,000, 0" -> x=1,000 y=0), consistent
                    # with parse_numeric_arg used by distance/circle.
                    x_str, y_str = coords.rsplit(',', 1)
                    solver.add_point(name, parse_numeric_arg(x_str),
                                     parse_numeric_arg(y_str))
                except (ValueError, TypeError) as e:
                    raise GeometryError(f"invalid coordinates: {e}")
        else:
            name = args[0].strip()
            _check_point_name(name)
            solver.add_point(name)

    elif cmd == 'distance':
        if len(args) != 3:
            raise GeometryError(f"*distance requires 3 arguments: A ; B ; distance (got {len(args)})")
        A, B = args[0].strip(), args[1].strip()
        _check_point_name(A)
        _check_point_name(B)
        try:
            d = parse_numeric_arg(args[2])
        except ValueError:
            raise GeometryError(f"distance value must be numeric, got: {args[2]!r}")
        import math as _math

        if not _math.isfinite(d):
            raise GeometryError(f"distance must be finite, got: {args[2]!r}")
        if d > 1e6:
            raise GeometryError(f"distance exceeds the canvas limit (1e6), got: {args[2]!r}")
        if d < 0:
            raise GeometryError(f"distance must be non-negative, got: {args[2]!r}")
        solver.add_point(A)
        solver.add_point(B)
        if A == B and d > 1e-9:
            raise GeometryError(f"*distance({A} ; {B} ; {d}): same point cannot have non-zero distance")
        # Seed a good initial guess so huge (but legal) distances do not
        # require the solver to travel ~1e6 units from the default r=3
        # circle (max ~5000 steps * 1.0 clip). If exactly one endpoint is
        # fixed, place the free one at distance d; if both are free,
        # separate them along +x. Constructed endpoints are skipped: the
        # solver recomputes them analytically, so a seed based on their
        # pre-solve placeholder would be a phantom.
        if A not in solver.derived and B not in solver.derived:
            try:
                a_fixed = A in solver.fixed
                b_fixed = B in solver.fixed
                if d > 1e-9:
                    def _clamp(v):
                        return max(-1e6, min(1e6, float(v)))
                    if a_fixed and not b_fixed:
                        ax, ay = float(solver.points[A][0]), float(solver.points[A][1])
                        solver.points[B] = np.array([_clamp(ax + d), _clamp(ay)])
                    elif b_fixed and not a_fixed:
                        bx, by = float(solver.points[B][0]), float(solver.points[B][1])
                        solver.points[A] = np.array([_clamp(bx - d), _clamp(by)])
                    elif not a_fixed and not b_fixed:
                        ax, ay = float(solver.points[A][0]), float(solver.points[A][1])
                        solver.points[B] = np.array([_clamp(ax + d), _clamp(ay)])
            except (TypeError, ValueError, IndexError, KeyError) as e:
                print(f'[GeometryWarning] distance seeding skipped for {A}-{B}: {e}',
                      file=sys.stderr)
        solver.add_constraint(
            f"distance({A},{B}={d})",
            lambda P, a=A, b=B, dv=d: (_norm(P[a] - P[b]) - dv) ** 2,
            deps=(A, B),
        )

    elif cmd == 'perp':
        if len(args) == 4:
            A, B, C, D = [a.strip() for a in args]
            for pt in [A, B, C, D]:
                _check_point_name(pt)
                solver.add_point(pt)

            def _perp_cost_4(P, a=A, b=B, c=C, d=D):
                v1 = P[b] - P[a]
                v2 = P[d] - P[c]
                n1, n2 = float(_norm(v1)), float(_norm(v2))
                if _bad_len(n1) or _bad_len(n2):
                    return 1.0
                cosang = float(np.dot(v1, v2)) / (n1 * n2)
                return cosang * cosang

            solver.add_constraint(
                f"perp({A}{B},{C}{D})",
                lambda P, a=A, b=B, c=C, d=D: _seg_cost(
                    P, a, b,
                    lambda: _seg_cost(
                        P, c, d,
                        lambda: _perp_cost_4(P, a, b, c, d),
                    ),
                ),
                deps=(A, B, C, D),
            )
        elif len(args) == 3:
            A, B, C = [a.strip() for a in args]
            for pt in [A, B, C]:
                _check_point_name(pt)
                solver.add_point(pt)

            def _perp_cost_3(P, a=A, b=B, c=C):
                v1 = P[b] - P[a]
                v2 = P[c] - P[b]
                n1, n2 = float(_norm(v1)), float(_norm(v2))
                if _bad_len(n1) or _bad_len(n2):
                    return 1.0
                cosang = float(np.dot(v1, v2)) / (n1 * n2)
                return cosang * cosang

            solver.add_constraint(
                f"perp({A}{B},{B}{C})",
                lambda P, a=A, b=B, c=C: _seg_cost(
                    P, a, b,
                    lambda: _seg_cost(
                        P, b, c,
                        lambda: _perp_cost_3(P, a, b, c),
                    ),
                ),
                deps=(A, B, C),
            )
        else:
            raise GeometryError("*perp requires 3 or 4 arguments")

    elif cmd == 'parallel':
        if len(args) != 4:
            raise GeometryError(f"*parallel requires 4 arguments: A ; B ; C ; D (got {len(args)})")
        A, B, C, D = [a.strip() for a in args[:4]]
        for pt in [A, B, C, D]:
            _check_point_name(pt)
            solver.add_point(pt)

        def _parallel_cost(P, a=A, b=B, c=C, d=D):
            v1 = P[b] - P[a]
            v2 = P[d] - P[c]
            n1, n2 = float(_norm(v1)), float(_norm(v2))
            if _bad_len(n1) or _bad_len(n2):
                return 1.0
            sinang = float(_cross2d(v1, v2)) / (n1 * n2)
            return sinang * sinang

        solver.add_constraint(
            f"parallel({A}{B},{C}{D})",
            lambda P, a=A, b=B, c=C, d=D: _seg_cost(
                P, a, b,
                lambda: _seg_cost(
                    P, c, d,
                    lambda: _parallel_cost(P, a, b, c, d),
                ),
            ),
            deps=(A, B, C, D),
        )

    elif cmd == 'on-line':
        if len(args) != 3:
            raise GeometryError(f"*on-line requires 3 arguments: A ; B ; C (got {len(args)})")
        A, B, C = [a.strip() for a in args[:3]]
        for pt in [A, B, C]:
            _check_point_name(pt)
            solver.add_point(pt)

        def _online_cost(P, a=A, b=B, c=C):
            v1 = P[b] - P[a]
            n1 = float(_norm(v1))
            if _bad_len(n1):
                return 1.0
            # Distance from C to line AB (absolute units, not L^4).
            return (float(_cross2d(v1, P[c] - P[a])) / n1) ** 2

        solver.add_constraint(
            f"on-line({C} on {A}{B})",
            lambda P, a=A, b=B, c=C: _seg_cost(
                P, a, b,
                lambda: _online_cost(P, a, b, c),
            ),
            deps=(A, B, C),
        )

    elif cmd == 'on-circle':
        if len(args) != 3:
            raise GeometryError(f"*on-circle requires 3 arguments: O ; r ; A (got {len(args)})")
        O, r_str, A = args[0].strip(), args[1].strip(), args[2].strip()
        _check_point_name(O)
        _check_point_name(A)
        try:
            r = parse_numeric_arg(r_str)
        except ValueError:
            raise GeometryError(f"radius must be numeric, got: {r_str!r}")
        import math as _math2

        if not _math2.isfinite(r):
            raise GeometryError(f"radius must be finite, got: {r_str!r}")
        if r > 1e6:
            raise GeometryError(f"radius exceeds the canvas limit (1e6), got: {r_str!r}")
        if r <= 0:
            raise GeometryError(f"radius must be positive, got: {r_str!r}")
        for pt in [O, A]:
            solver.add_point(pt)
        solver.add_constraint(
            f"on-circle({A} on circle({O},{r}))",
            lambda P, o=O, rv=r, a=A: (_norm(P[a] - P[o]) - rv) ** 2,
            deps=(O, A),
        )

    elif cmd == 'equal-length':
        if len(args) != 4:
            raise GeometryError(f"*equal-length requires 4 arguments: A ; B ; C ; D (got {len(args)})")
        A, B, C, D = [a.strip() for a in args[:4]]
        for pt in [A, B, C, D]:
            _check_point_name(pt)
            solver.add_point(pt)
        solver.add_constraint(
            f"equal-length({A}{B}={C}{D})",
            lambda P, a=A, b=B, c=C, d=D: (_norm(P[b] - P[a]) - _norm(P[d] - P[c])) ** 2,
            deps=(A, B, C, D),
        )

    elif cmd == 'midpoint':
        if len(args) != 3:
            raise GeometryError(f"*midpoint requires 3 arguments: A ; B ; C (got {len(args)})")
        A, B, C = [a.strip() for a in args[:3]]
        for pt in [A, B, C]:
            _check_point_name(pt)
            solver.add_point(pt)
        solver.add_constraint(
            f"midpoint({C} of {A}{B})",
            lambda P, a=A, b=B, c=C: _norm(P[c] - (P[a] + P[b]) / 2) ** 2,
            deps=(A, B, C),
        )

    elif cmd == 'intersection':
        if len(args) != 3:
            raise GeometryError(f"*intersection requires 3 arguments: name ; line(A;B) ; line(D;E) (got {len(args)})")
        C = args[0].strip()
        _check_point_name(C)

        def _parse_line_arg(s):
            m = re.match(r'line\s*\(\s*(.*?)\s*[;,]\s*(.*?)\s*\)\s*$', s.strip())
            if not m:
                raise GeometryError(f"expected line(P;Q), got: {s!r}")
            p, q = m.group(1).strip(), m.group(2).strip()
            _check_point_name(p)
            _check_point_name(q)
            if p == q:
                raise GeometryError(f"intersection: line({p};{q}) is degenerate (same point twice)")
            return p, q

        A, B = _parse_line_arg(args[1])
        D, E = _parse_line_arg(args[2])
        for pt in [A, B, C, D, E]:
            solver.add_point(pt)

        def _inter_cost_1(P, a=A, b=B, c=C):
            v = P[b] - P[a]
            n = float(_norm(v))
            if _bad_len(n):
                return 1.0
            return (float(_cross2d(v, P[c] - P[a])) / n) ** 2

        def _inter_cost_2(P, d=D, e=E, c=C):
            v = P[e] - P[d]
            n = float(_norm(v))
            if _bad_len(n):
                return 1.0
            return (float(_cross2d(v, P[c] - P[d])) / n) ** 2

        solver.add_constraint(
            f"intersection({C} on {A}{B})",
            lambda P, a=A, b=B, c=C: _seg_cost(
                P, a, b,
                lambda: _inter_cost_1(P, a, b, c),
            ),
            deps=(A, B, C),
        )
        solver.add_constraint(
            f"intersection({C} on {D}{E})",
            lambda P, d=D, e=E, c=C: _seg_cost(
                P, d, e,
                lambda: _inter_cost_2(P, d, e, c),
            ),
            deps=(D, E, C),
        )

    elif cmd == 'equal-angle':
        # angle ABC equals angle DEF (both interior/minor angles). The
        # equality marks themselves are drawn by codegen; the constraint
        # here is what moves the free points until the angles match.
        if len(args) != 6:
            raise GeometryError(
                f"*equal-angle requires 6 arguments: A ; B ; C ; D ; E ; F (got {len(args)})"
            )
        A, B, C, D, E, F = [a.strip() for a in args[:6]]
        for pt in [A, B, C, D, E, F]:
            _check_point_name(pt)
            solver.add_point(pt)
        import math as _math

        def _equal_angle_cost(P, a=A, b=B, c=C, d=D, e=E, f=F):
            v1, v2 = P[a] - P[b], P[c] - P[b]
            v3, v4 = P[d] - P[e], P[f] - P[e]
            if (_bad_len(_norm(v1)) or _bad_len(_norm(v2))
                    or _bad_len(_norm(v3)) or _bad_len(_norm(v4))):
                return 1.0
            # atan2(|cross|, dot) is the interior angle in [0, pi]:
            # smooth everywhere the arms are non-degenerate (acos would
            # need clamping and loses gradient near 0/pi).
            t1 = _math.atan2(abs(float(_cross2d(v1, v2))),
                             float(np.dot(v1, v2)))
            t2 = _math.atan2(abs(float(_cross2d(v3, v4))),
                             float(np.dot(v3, v4)))
            return (t1 - t2) ** 2

        solver.add_constraint(
            f"equal-angle({A}{B}{C}={D}{E}{F})",
            _equal_angle_cost,
            deps=(A, B, C, D, E, F),
        )

    # Draw-only commands — just register for the draw pass
    elif cmd in ('line', 'ray', 'triangle', 'circle', 'right-angle', 'angle',
                 'arc', 'label', 'length', 'angle-value'):
        # Auto-create referenced points so simple drawings work without
        # explicit *point() (per spec: coordinates are optional).
        for i, arg in enumerate(args):
            a = arg.strip()
            # *circle(O ; r-or-point): the second arg is a radius unless it
            # names an already-defined point. Never auto-create it: a
            # typo'd radius (*circle(O ; hello)) must error instead of
            # silently drawing a circle around a fresh point.
            if cmd == 'circle' and i == 1:
                continue
            # Only documented point positions auto-create. Anything past a
            # command's arity is malformed and must not leave stray dots
            # (codegen rejects it loudly instead).
            if cmd == 'triangle' and i >= 3:
                continue
            if cmd == 'line' and i >= 2:
                continue
            if cmd == 'ray' and i >= 2:
                continue
            if cmd == 'circle' and i >= 2:
                continue
            if cmd == 'right-angle' and i >= 3:
                continue
            if cmd == 'arc' and i >= 3:
                continue
            if cmd == 'length' and i >= 2:
                continue
            if cmd == 'angle-value' and i >= 3:
                continue
            # *label(P ; text): only the first arg is a point; the text
            # must never auto-create a stray point (e.g. *label(A ; hello)).
            if cmd == 'label' and i >= 1:
                continue
            # *angle(A ; B ; C ; label): the 4th arg is label text, and
            # anything beyond is malformed.
            if cmd == 'angle' and i >= 3:
                continue
            if a.lower() == 'infinite':
                continue
            if re.match(r'^[A-Za-z][A-Za-z0-9_]*$', a):
                try:
                    float(a)
                except ValueError:
                    solver.add_point(a)
                    continue
    # (parallel/perp as constraint-only — don't add draw command separately)

    solver.draw_commands.append((cmd, args))
