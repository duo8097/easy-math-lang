"""Document analysis for the LSP, built on the existing compiler.

There is intentionally no second parser here.  Analysis mirrors the
compiler pipeline (`compiler/pipeline.py`) line classification and reuses:
  - `comments.strip_comments` for comment handling,
  - `CompileContext` + `statements.process_assignment_or_define` for the
    semantic state (definitions and their values),
  - `variables.replace_vars` / `replace_defines` for substitution,
  - `calc.apply_calc_in_string` for calc() validation,
  - `diagnostics.KNOWN_COMMANDS` (+ the same unknown-command rule) and
    `geometry.parse_draw_block` (geometry diagnostics) for diagnostics.

The only LSP-specific work is turning compiler results into positioned
diagnostics/symbols: the compiler is line-oriented, so line numbers map
1:1 and character offsets are found by scanning the source line.  Checks
run on the source text (pre-substitution) so reported ranges are exact;
substitution is applied to a copy only to decide resolvability.

Table of contents for this ~1200-line file — line numbers are
approximate (they drift; the names do not):

    ~line  section
    -----  -------
      59   _mask_ranges / _mask_calc_spans / _mask_matrix_spans /
           _mask_known_call_spans / _mask_p_segments — offset-preserving
           "blank out" helpers so LSP checks never see raw math
      143  Diag / Definition / Analysis — the small data classes
      183   _quiet / _quiet_calc — context managers around compiler stderr
      264   _record_new / _snapshot / _find_call_anchor / _analyze_draw —
           *draw(...) block handling
      327   _validate_table_calls / _validate_table_block /
           _validate_plot_image_styling — table & plot checks
      468   analyze_text / _analyze_math_body / _analyze_text_inner —
           THE line loop that turns text into diagnostics
     1082   _in_p_span — is this character inside an inline math span?
     1098   complete / hover / document_symbols — the LSP request handlers
"""

import contextlib
import difflib
import io
import os
import re

from compiler.calc import apply_calc_in_string, evaluate_calc
from compiler.comments import strip_comments
from compiler.diagnostics import (
    BARE_COMMAND_RE,
    KNOWN_COMMANDS,
    KNOWN_GEOMETRY_COMMANDS,
)
from compiler.symbols import WORD_REPLACEMENTS
from compiler.statements import (
    _normalize_friendly_statement,
    process_assignment_or_define,
)
from compiler.escaping import blank_urls
from compiler.state import CompileContext
from compiler import tables as _tables
from compiler.variables import (
    _looks_like_comparison,
    replace_defines,
    replace_vars,
)
from geometry.parsing import parse_draw_block
from . import builtins

IDENT = r'[A-Za-z_][A-Za-z0-9_]*'
VAR_TOKEN = re.compile(r'<([^<>]+)>')
CALC_OPEN = re.compile(r'(?<![A-Za-z0-9_])\*?calc\(')
CMD_CALL = re.compile(r'\*([^\W\d_][\w\-]*)\s*\(')
P_LINE = re.compile(r'^\*p\((.*)\)$')
WORD_AT = re.compile(IDENT)

# Bare *word keywords that render as glyphs (mirror compiler/diagnostics.py).
_SYMBOL_WORDS = frozenset(old for old, _new in WORD_REPLACEMENTS)


def _mask_ranges(code, spans):
    """Blank *spans* with spaces (offset-preserving)."""
    chars = list(code)
    for start, end in spans:
        for i in range(max(0, start), min(len(chars), end)):
            chars[i] = ' '
    return ''.join(chars)


def _mask_calc_spans(code):
    """Blank balanced calc(...)/ *calc(...) spans (offset-preserving).

    The compiler evaluates calc() away before warning about commands,
    so command-like text inside calc() (e.g. the ``*`` in ``2*3``)
    must not warn here either. Unclosed calc() is left intact so the
    unclosed-paren check below can still flag it.
    """
    spans = []
    for m in CALC_OPEN.finditer(code):
        close = _balanced_range(code, m.end() - 1)
        if close is None:
            continue
        spans.append((m.start(), close))
    return _mask_ranges(code, spans)


def _geometry_warning(cmd, parens=True):
    """Message for a geometry command used outside *draw(...).

    ``*draw`` itself gets the compiler's wording — the old message was
    self-referential ('*draw(...) is only valid inside *draw(...)').
    """
    if cmd == 'draw':
        return 'unclosed or malformed *draw(...) — treated as plain text'
    if parens:
        return f"*{cmd}(...) is only valid inside *draw(...) — treated as plain text"
    return f"*{cmd} is only valid inside *draw(...) — treated as plain text"


def _mask_matrix_spans(code):
    """Blank balanced ``*matrix(``/``*mat(`` spans (offset-preserving).

    Their cells go through the math cleaner, which never calls
    warn_unknown_commands — so unknown commands inside matrix cells are
    silent in the compiler and must be silent here too. The shape
    checker still sees the unmasked line.
    """
    spans = []
    for m in re.finditer(r'\*(matrix|mat)\s*\(', code):
        close = _balanced_range(code, m.end() - 1)
        if close is None:
            continue
        spans.append((m.start(), close))
    return _mask_ranges(code, spans)


def _mask_known_call_spans(code):
    """Blank balanced *known(...) spans (offset-preserving).

    The compiler expands known math commands before warning, so
    multiplication inside their arguments (``*frac(a*b ; c)``) never
    warns there — hide the same spans here for parity. Unknown calls
    stay visible so the unknown-command checks still flag them.
    ``*table``/``*matrix``/``*mat`` are NOT masked: their cells run
    through the full text pipeline, so bare unknowns inside them warn
    in the compiler too (nested known calls inside the cells are still
    masked by the same pass).
    """
    spans = []
    for m in CMD_CALL.finditer(code):
        cmd = m.group(1)
        if cmd in ('table', 'matrix', 'mat'):
            continue
        if (cmd in KNOWN_COMMANDS or cmd in _SYMBOL_WORDS
                or cmd == 'calc'
                or cmd in KNOWN_GEOMETRY_COMMANDS
                or cmd.replace('_', '-') in KNOWN_GEOMETRY_COMMANDS):
            close = _balanced_range(code, m.end() - 1)
            if close is None:
                continue
            spans.append((m.start(), close))
    return _mask_ranges(code, spans)


# --- Diagnostics + definitions: data the LSP reports and finds ---
class Diag:
    """A diagnostic with 0-based line/character positions."""

    def __init__(self, line, start, end, severity, message):
        self.line = line
        self.start = start
        self.end = end
        self.severity = severity  # 'error' | 'warning'
        self.message = message

    def __repr__(self):
        return f'Diag({self.line}:{self.start}-{self.end} {self.severity} {self.message!r})'


class Definition:
    """A named declaration: define, variable or draw block."""

    def __init__(self, name, kind, line, start, end, value=None):
        self.name = name
        self.kind = kind  # 'define' | 'variable' | 'draw'
        self.line = line
        self.start = start
        self.end = end
        self.value = value

    def __repr__(self):
        return f'Definition({self.name!r} {self.kind} @{self.line})'


class Analysis:
    """Collects diagnostics, definitions and variable values for one file."""

    def __init__(self):
        """Start with no diagnostics, no definitions, no variable values."""
        self.diagnostics = []
        self.definitions = []
        self.values = {}  # name -> (kind, value, def_line)


# --- Context managers around compiler stderr output ---
@contextlib.contextmanager
def _quiet():
    """Suppress compiler stderr chatter; diagnostics are derived by us."""
    buf = io.StringIO()
    with contextlib.redirect_stderr(buf):
        yield buf


@contextlib.contextmanager
def _quiet_calc(analysis, line):
    """Suppress compiler noise but keep ``calc()`` failures as diagnostics.

    The compiler reports e.g. ``calc(1/0)`` only on stderr, which the LSP
    otherwise swallows — leaving the user with nothing. Convert exactly
    the calc-failure lines into diagnostics; everything else stays
    suppressed.
    """
    buf = io.StringIO()
    with contextlib.redirect_stderr(buf):
        yield buf
    for raw in buf.getvalue().split('\n'):
        s = raw.strip()
        if 'calc()' not in s:
            continue
        if s.startswith('[Error') or s.startswith('[Calc Error'):
            m = re.match(r'\[Error\]\s*(?:Line \d+:\s*)?(.*)', s, re.IGNORECASE)
            msg = (m.group(1) if m else s).strip() or s
            analysis.diagnostics.append(Diag(line, 0, 0, 'error', msg[:300]))


def _balanced_range(text, open_index):
    """End index (exclusive) of the ')' matching text[open_index] == '('.

    Returns None when unbalanced (syntax error).
    """
    depth = 0
    for i in range(open_index, len(text)):
        if text[i] == '(':
            depth += 1
        elif text[i] == ')':
            depth -= 1
            if depth == 0:
                return i + 1
    return None


def _mask_p_segments(code):
    """Replace balanced *p(...) spans with spaces (preserving offsets).

    Raw *p content bypasses all checks, like the compiler. Unclosed
    *p( is left intact so later checks can still flag it.
    """
    chars = list(code)
    pos = 0
    pat = re.compile(r'\*p\(')
    while True:
        m = pat.search(code, pos)
        if not m:
            break
        close = _balanced_range(code, m.end() - 1)
        if close is None:
            break
        for i in range(m.start(), close):
            chars[i] = ' '
        pos = close
    return ''.join(chars)


def _unescaped_bs_positions(s):
    """Offsets of unescaped ``\\`` in *s* (``\\\\`` ignored)."""
    out = []
    i, n = 0, len(s)
    while i < n:
        if s[i] == '\\':
            if i + 1 < n and s[i + 1] == '\\':
                i += 2
                continue
            out.append(i)
        i += 1
    return out


def _record_new(ctx, before, stmt_text, line_no, analysis):
    """Record names defined by one processed statement."""
    new_vars = set(ctx.variables) - before[0]
    new_defs = set(ctx.defines) - before[1]
    for name in sorted(new_vars | new_defs):
        kind = 'define' if name in ctx.defines else 'variable'
        value = ctx.variables.get(name)
        m = re.search(rf'<{re.escape(name)}>', stmt_text)
        if m is None:
            m = re.search(rf'\b{re.escape(name)}\b', stmt_text)
        start, end = (m.start(), m.end()) if m else (0, len(stmt_text))
        analysis.definitions.append(
            Definition(name, kind, line_no, start, end,
                       value=None if value is None else str(value))
        )


def _snapshot(ctx):
    return set(ctx.variables), set(ctx.defines)


def _find_call_anchor(code, name):
    """Offset of ``*name(`` in *code*, or 0 when absent.

    Matches inside a balanced ``*p(...)`` span don't count (the compiler
    treats them as raw text), replacing the old ``code.index`` that
    mis-anchored diagnostics.
    """
    masked = _mask_p_segments(code)
    m = re.search(r'\*' + re.escape(name) + r'\s*\(', masked)
    return m.start() if m is not None else 0


# --- Draw block handling (*draw(...) -> geometry checks) ---
def _analyze_draw(block_text, lines, start_line, end_line, analysis):
    """Geometry diagnostics for one draw block (compiler output reused)."""
    with _quiet() as cap:
        out = parse_draw_block(block_text)
    seen = set()
    anchor_end = len(lines[start_line]) if start_line < len(lines) else 0
    # Single-line anchor on the block opener (Diag is single-line);
    # the message names the failing command for precise location.
    for source in (cap.getvalue().split('\n'), out.split('\n')):
        for raw in source:
            m = re.match(r'(?://\s*)?\[(GeometryError|GeometryWarning)\]\s*(.*)', raw.strip())
            if not m:
                continue
            severity = 'error' if m.group(1) == 'GeometryError' else 'warning'
            message = m.group(2).strip() or m.group(1)
            # The compiler emits the same failure twice — to stderr with
            # the command echoed and to the canvas as a bare comment
            # ('*line(A; A): ...' vs '*line: ...'). Dedup on a
            # command-prefix-free message so one error = one diagnostic.
            norm = re.sub(r'^\*[A-Za-z][\w-]*(\([^)]*\))?:\s*', '', message)
            norm = re.sub(r'\s+', ' ', norm).strip()
            key = (severity, norm, start_line, end_line)
            if key in seen:
                continue
            seen.add(key)
            analysis.diagnostics.append(
                Diag(start_line, 0, anchor_end, severity, message)
            )


# --- Table shape checks (*table / *matrix cells must be rectangular) ---
def _table_shape_message(inner, kind):
    """Return a warning string when a table/matrix grid is ragged/empty."""
    try:
        grid = _tables.parse_grid(inner)
    except Exception:
        return None
    kept = [r for r in grid if any(c.strip() for c in r)]
    if not kept:
        return f'*{kind}(...) is empty'
    widths = sorted({len(r) for r in kept})
    if len(widths) != 1:
        return (
            f'*{kind}(...) rows have different lengths '
            f'{sorted(len(r) for r in kept)} — short rows are padded'
        )
    return None


_PLOT_CALLS = frozenset({'plot'})
_STYLE_CALLS = frozenset({'bold', 'italic', 'underline'})
_IMAGE_CALLS = frozenset({'image'})


def _validate_plot_image_styling(masked_code, idx, analysis, ctx):
    """Shape checks for *plot/*image and styling calls (text mode)."""
    try:
        from compiler.math_commands import split_top_level_args
        from compiler import plots as _plots
    except Exception:
        return

    for m in CMD_CALL.finditer(masked_code):
        cmd = m.group(1)
        if cmd not in _PLOT_CALLS and cmd not in _IMAGE_CALLS and cmd not in _STYLE_CALLS:
            continue
        close = _balanced_range(masked_code, m.end() - 1)
        if close is None:
            analysis.diagnostics.append(Diag(
                idx, m.start(), len(masked_code), 'error',
                f'Unclosed *{cmd}(... — missing closing parenthesis',
            ))
            continue
        if cmd in _STYLE_CALLS:
            continue
        inner_raw = masked_code[m.end():close - 1]
        try:
            args = split_top_level_args(inner_raw)
        except Exception:
            continue
        if cmd == 'plot':
            if not args[0].strip():
                analysis.diagnostics.append(Diag(
                    idx, m.start(), close, 'error',
                    '*plot(...) needs an expression to plot',
                ))
                continue
            if len(args) != 3:
                analysis.diagnostics.append(Diag(
                    idx, m.start(), close, 'error',
                    f'*plot(...) needs 3 arguments: expression ; xmin ; xmax '
                    f'(got {len(args)})',
                ))
                continue
            try:
                xmin = _plots.evaluate_bound(ctx, args[1])
                xmax = _plots.evaluate_bound(ctx, args[2])
            except ValueError as e:
                analysis.diagnostics.append(Diag(
                    idx, m.start(), close, 'error',
                    f'*plot(...) invalid bounds: {e}',
                ))
                continue
            if xmin >= xmax:
                analysis.diagnostics.append(Diag(
                    idx, m.start(), close, 'error',
                    f'*plot(...) needs xmin < xmax (got {xmin} >= {xmax})',
                ))
        elif cmd == 'image':
            if len(args) not in (1, 2):
                analysis.diagnostics.append(Diag(
                    idx, m.start(), close, 'error',
                    f'*image(...) needs 1 or 2 arguments: path [; width] '
                    f'(got {len(args)})',
                ))
            elif not args[0].strip():
                analysis.diagnostics.append(Diag(
                    idx, m.start(), close, 'error',
                    '*image(...) needs a file path',
                ))


def _validate_table_calls(line_text, idx, analysis, *, in_math_pairs):
    """Emit shape warnings for single-line *table/*matrix calls."""
    pos = 0
    while True:
        try:
            found = _tables.find_next_call(line_text, pos)
        except Exception:
            return
        if not found:
            return
        if found[0] == 'unclosed':
            _, name, call_start, inner_start, _, _ = found
            analysis.diagnostics.append(Diag(
                idx, call_start, inner_start, 'warning',
                f'Unclosed *{name}(... — missing closing parenthesis',
            ))
            pos = inner_start
            continue
        name, call_start, _s, call_end, inner_raw = found
        if name == 'table' and in_math_pairs:
            # Tables are text mode; the compiler warns too.
            analysis.diagnostics.append(Diag(
                idx, call_start, call_end, 'warning',
                '*table(...) cannot be used inside math \\ ... \\',
            ))
            pos = call_end
            continue
        msg = _table_shape_message(inner_raw, name)
        if msg:
            analysis.diagnostics.append(Diag(
                idx, call_start, call_end, 'warning', msg,
            ))
        pos = call_end


def _validate_table_block(block_type, block_content, lines,
                           start_line, end_line, analysis):
    """Shape diagnostics for a multiline *table/*matrix/*mat block."""
    kind = block_type[1:-1]
    joined = _tables.join_block_lines(
        [stmt for _, stmt in block_content]
    )
    msg = _table_shape_message(joined, kind)
    anchor_end = len(lines[start_line]) if start_line < len(lines) else 0
    if msg:
        analysis.diagnostics.append(
            Diag(start_line, 0, anchor_end, 'warning', msg)
        )


# --- Main analysis: text -> diagnostics (the line loop) ---
def _uri_to_path(uri):
    if not isinstance(uri, str):
        return None
    if uri.startswith('file://'):
        from urllib.parse import unquote, urlparse
        parsed = urlparse(uri)
        path = unquote(parsed.path or '')
        if os.name == 'nt' and path.startswith('/') and len(path) > 2 and path[2] == ':':
            path = path[1:]
        return path or None
    return None


def _known_commands(analysis=None):
    known = set(KNOWN_COMMANDS)
    reg = getattr(analysis, 'registry', None) if analysis is not None else None
    if reg is not None:
        try:
            known |= reg.all_command_names()
        except Exception:
            pass
    return known


def analyze_text(text, base_dir=None, uri=None):
    """Analyze a document; never raises on malformed input."""
    analysis = Analysis()
    try:
        if not isinstance(text, str):
            analysis.diagnostics.append(
                Diag(0, 0, 0, 'error', 'Invalid document text')
            )
            return analysis
        if base_dir is None and isinstance(uri, str):
            base_dir = _uri_to_path(uri)
            if base_dir is not None:
                base_dir = os.path.dirname(base_dir)
        return _analyze_text_inner(text, analysis, base_dir=base_dir)
    except Exception as e:
        try:
            analysis.diagnostics.append(
                Diag(0, 0, 0, 'error', f'Analysis failed: {e}')
            )
        except Exception:
            pass
        return analysis


def _analyze_math_body(ctx, head, idx, analysis):
    """Checks for the math portion of a line (\\... or a multiline head).

    Mirrors the compiler's validation of math bodies: undefined
    variables get hard errors, ``calc(...)`` errors are reported, and
    unknown commands inside math are flagged (the compiler's
    ``warn_unknown_commands`` runs on math inners too). Positions are
    relative to *head* (which starts at column 0 of the source line).
    """
    check_code = _mask_p_segments(head)
    check_code = blank_urls(check_code)

    for occ in VAR_TOKEN.finditer(check_code):
        raw_name = occ.group(1)
        if not re.fullmatch(rf'\s*{IDENT}\s*', raw_name):
            continue
        if occ.start() > 0 and check_code[occ.start() - 1] == '<':
            continue
        if occ.end() < len(check_code) and check_code[occ.end()] == '>':
            continue
        if _looks_like_comparison(check_code, occ.start(), occ.end()):
            continue
        clean = raw_name.strip()
        if clean in ctx.variables or clean in ctx.defines:
            continue
        analysis.diagnostics.append(Diag(
            idx, occ.start(), occ.end(), 'error',
            f'Undefined variable <{clean}>',
        ))

    # Unknown commands inside math (the compiler warns too).
    _masked = check_code
    while True:
        _o = _unescaped_bs_positions(_masked)
        if len(_o) < 2:
            break
        _masked = (
            _masked[:_o[0]] + ' ' * (_o[1] + 1 - _o[0]) + _masked[_o[1] + 1:]
        )
    for m in CMD_CALL.finditer(_masked):
        cmd = m.group(1)
        if cmd == 'calc':
            continue
        _known = _known_commands(analysis)
        if cmd in _known:
            continue
        if cmd in KNOWN_GEOMETRY_COMMANDS or cmd.replace('_', '-') in KNOWN_GEOMETRY_COMMANDS:
            analysis.diagnostics.append(Diag(
                idx, m.start(), m.end(), 'warning',
                _geometry_warning(cmd, parens=True),
            ))
            continue
        analysis.diagnostics.append(Diag(
            idx, m.start(), m.end(), 'warning',
            f"Unknown command *{cmd}(...) — treated as plain text",
        ))

    for m in CALC_OPEN.finditer(check_code):
        close = _balanced_range(check_code, m.end() - 1)
        if close is None:
            analysis.diagnostics.append(Diag(
                idx, m.start(), len(check_code), 'error',
                'Unclosed parenthesis in calc(...)',
            ))
            continue
        expr = head[m.end():close - 1]
        res = evaluate_calc(ctx, expr)
        if res.startswith('[Calc Error'):
            analysis.diagnostics.append(Diag(
                idx, m.start(), close, 'error', res,
            ))


def _analyze_text_inner(text, analysis, base_dir=None):
    # LSP clients split lines on \r\n, \r and \n only; str.splitlines()
    # would invent phantom lines for VT/FF/FS-US/NEL and mistranslate
    # every diagnostic that follows them. Normalize first.
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    ctx = CompileContext()
    raw_lines = text.split('\n')
    lines = strip_comments(text).split('\n')
    # strip_comments preserves line count, but be defensive.
    while len(lines) < len(raw_lines):
        lines.append('')

    # Per-document mod loading (never mutate defaults).
    try:
        from compiler.command_registry import load_document_registry
        registry, mod_diags = load_document_registry(text, base_dir)
        analysis.registry = registry
        ctx.registry = registry
        for ln, sev, msg in mod_diags:
            idx = ln - 1
            if idx < 0 or idx >= len(lines):
                idx = 0
            analysis.diagnostics.append(Diag(
                idx, 0, len(lines[idx]) if idx < len(lines) else 0,
                'error' if sev.lower().startswith('err') else 'warning',
                msg))
    except Exception as e:
        analysis.diagnostics.append(Diag(0, 0, 0, 'error',
                                         f'mod loading failed: {e}'))

    in_f_block = False
    block_type = None
    block_content = []
    block_start = 0
    in_table_block = False
    table_type = None
    table_content = []
    table_start = 0
    in_math = False
    math_start = 0
    math_start_char = 0

    ctx._doc_title_seen = False
    with _quiet():
        in_fence = False
        for idx, code in enumerate(lines):
            s = code.strip()
            if not s:
                continue
            if s.startswith('```'):
                in_fence = not in_fence
                continue
            if in_fence:
                continue

            # Control lines suspended while multiline math is open
            # (mirrors compiler/pipeline.py: tail after the closer is
            # still processed as normal text). Buffered math lines still
            # get text checks below (undefined vars/calc), matching the
            # compiler which validates the joined math body.
            math_buffered = False
            if in_math:
                masked = _mask_p_segments(code)
                _bs_close = _unescaped_bs_positions(masked)
                if not _bs_close:
                    math_buffered = True
                else:
                    # Mirror the compiler (compiler/pipeline.py): the first
                    # unescaped backslash closes multiline math; the tail
                    # after it is normal text (it may open new math pairs,
                    # handled by the single-line tracking below).
                    in_math = False
                    first = _bs_close[0]
                    # The math head is part of the math body: check it
                    # (undefined vars/calc/unknown commands) before the
                    # normal-text pass. Positions below start at column 0,
                    # so they are exact. The head+closer are then masked
                    # out of the tail's text checks (offset-preserving) —
                    # nothing on them can leak in.
                    _analyze_math_body(ctx, code[:first], idx, analysis)
                    code = ' ' * (first + 1) + code[first + 1:]
                    s = code.strip()
                    if not s:
                        continue

            # *define(...) / define(...) — suspended inside math buffer.
            # Space-tolerant like the compiler
            # (pipeline.py accepts '*define (x = 1)').
            _m_def = re.match(r'^(\*?define)\s*\((.*)\)\s*$', s)
            if not math_buffered and _m_def and _m_def.group(2) is not None:
                inner = s[_m_def.start(2):_m_def.end(2)]
                before = _snapshot(ctx)
                with _quiet_calc(analysis, idx):
                    process_assignment_or_define(ctx, 'define(' + inner + ')', line_no=idx + 1)
                _record_new(ctx, before, code, idx, analysis)
                continue

            # Friendly: let/var and bare *define without parens.
            if not math_buffered:
                _norm = _normalize_friendly_statement(s)
                if _norm != s and (
                    _norm.startswith('define(')
                    or re.match(r'^<[^<>]+>\s*=', _norm)
                ):
                    before = _snapshot(ctx)
                    with _quiet_calc(analysis, idx):
                        process_assignment_or_define(ctx, _norm, line_no=idx + 1)
                    _record_new(ctx, before, code, idx, analysis)
                    continue

            # Single-line *draw(...) — suspended inside math buffer.
            if not math_buffered and s.startswith('*draw(') and s.endswith(')'):
                inner = s[6:-1]
                inner = replace_vars(ctx, inner)
                inner = replace_defines(ctx, inner)
                with _quiet_calc(analysis, idx):
                    inner = apply_calc_in_string(ctx, inner)
                pos = code.index('*draw')
                analysis.definitions.append(Definition('draw', 'draw', idx, pos, pos + 5))
                if '[Calc Error' in inner:
                    analysis.diagnostics.append(Diag(
                        idx, pos, pos + 5, 'error', inner[inner.index('[Calc Error'):inner.index('[Calc Error') + 120],
                    ))
                _analyze_draw(inner, lines, idx, idx, analysis)
                continue

            # Single-line *f(...) — suspended inside math buffer.
            if not math_buffered and s.startswith('*f(') and s.endswith(')'):
                inner = s[3:-1].strip()
                if not (inner.startswith('frac(') or inner.startswith('root(')):
                    before = _snapshot(ctx)
                    with _quiet_calc(analysis, idx):
                        process_assignment_or_define(ctx, inner, line_no=idx + 1)
                    _record_new(ctx, before, code, idx, analysis)
                    continue
            elif not math_buffered and ((s.startswith('*(') and s.endswith(')') and len(s) > 3)
                  or (s.startswith('f(') and s.endswith(')') and len(s) > 3
                      and not s.startswith('frac('))):
                inner = s[2:-1].strip()
                if inner and not inner.startswith('*'):
                    _inner_norm = _normalize_friendly_statement(inner)
                    if (re.match(r'^<[^<>]+>\s*=', inner)
                            or inner.startswith('define(')
                            or _inner_norm != inner):
                        before = _snapshot(ctx)
                        with _quiet_calc(analysis, idx):
                            process_assignment_or_define(ctx, inner, line_no=idx + 1)
                        _record_new(ctx, before, code, idx, analysis)
                        continue
            if not math_buffered and s in ('*(', '*f(', 'f(', '*draw('):
                in_f_block = True
                block_type = s
                block_content = []
                block_start = idx
                continue
            elif not math_buffered and s == ')' and in_f_block:
                if block_type == '*draw(':
                    pos = _find_call_anchor(lines[block_start], 'draw')
                    analysis.definitions.append(
                        Definition('draw', 'draw', block_start, pos, pos + 5)
                    )
                    _analyze_draw(
                        '\n'.join(stmt for _, stmt in block_content),
                        lines, block_start, idx, analysis,
                    )
                else:
                    for stmt_idx, stmt in block_content:
                        before = _snapshot(ctx)
                        with _quiet_calc(analysis, stmt_idx):
                            process_assignment_or_define(ctx, stmt, line_no=stmt_idx + 1)
                        _record_new(ctx, before, lines[stmt_idx], stmt_idx, analysis)
                in_f_block = False
                continue

            # Multiline *table/*matrix/*mat/*align/*cases/*vec blocks:
            # buffer rows for shape validation, but inner lines still
            # get normal text checks below (variables/calc inside cells
            # must resolve). *align/*cases rows are equations and *vec
            # rows are components — no shape check on close.
            if not math_buffered and not in_f_block and s in (
                '*table(', '*matrix(', '*mat(', '*align(', '*cases(', '*vec(',
            ):
                in_table_block = True
                table_type = s
                table_content = []
                table_start = idx
                continue
            if not math_buffered and s == ')' and in_table_block:
                if table_type not in ('*align(', '*cases(', '*vec('):
                    _validate_table_block(
                        table_type, table_content, lines,
                        table_start, idx, analysis,
                    )
                in_table_block = False
                table_type = None
                table_content = []
                continue

            if in_f_block and not math_buffered:
                block_content.append((idx, s))
                continue
            if in_table_block and not math_buffered:
                table_content.append((idx, s))
                # Fall through to text checks so cell contents validate.
                # Assignments are NOT processed here (mirrors the compiler:
                # table blocks hold rows, not definitions).

            if not math_buffered and not in_table_block and re.match(r'^<[^<>]+>\s*=', s):
                before = _snapshot(ctx)
                with _quiet_calc(analysis, idx):
                    process_assignment_or_define(ctx, s, line_no=idx + 1)
                _record_new(ctx, before, code, idx, analysis)
                continue

            # --- Document title/font: *doc_title/*doc_font control lines ---
            if not math_buffered and not in_f_block and not in_table_block:
                _dm = re.match(r'^\*(doc_title|doc-title|doctitle|title|doc_font|doc-font|docfont)\s*\(', s)
                if _dm:
                    _dname = _dm.group(1)
                    _is_font = _dname.replace('-', '_') == 'doc_font' or _dname == 'docfont'
                    _open = _dm.end() - 1
                    _depth = 0
                    _in_q = False
                    _close = None
                    for _i in range(_open, len(s)):
                        _ch = s[_i]
                        if _ch == '"' and (_i == 0 or s[_i - 1] != '\\'):
                            _in_q = not _in_q
                            continue
                        if _in_q:
                            continue
                        if _ch == '(':
                            _depth += 1
                        elif _ch == ')':
                            _depth -= 1
                            if _depth == 0:
                                _close = _i
                                break
                    if _close is None:
                        analysis.diagnostics.append(Diag(
                            idx, _find_call_anchor(code, _dname),
                            len(code), 'warning',
                            f'Unclosed *{_dname}(... — missing closing parenthesis',
                        ))
                    elif s[_close + 1:].strip():
                        pass  # trailing content: not a pure control line
                    else:
                        _inner = s[_open + 1:_close]
                        if not _inner.strip():
                            _default = ('default font (Typst default, 12pt)'
                                        if _is_font else 'default title')
                            analysis.diagnostics.append(Diag(
                                idx, _find_call_anchor(code, _dname),
                                len(code), 'warning',
                                f'*{_dname}(...) is empty — using {_default}',
                            ))
                            continue
                        if _is_font:
                            # Mirror the compiler's validation: invalid
                            # family/size makes the *doc_font ignored.
                            try:
                                from compiler.pipeline import (
                                    _valid_doc_font_family,
                                    _valid_doc_font_size,
                                )
                                from compiler.math_commands import split_top_level_args
                                _fargs = split_top_level_args(_inner)
                            except Exception:
                                _fargs = None
                            if _fargs is not None:
                                _fam = (_fargs[0] if _fargs else '').strip()
                                _sz = (_fargs[1] if len(_fargs) > 1 else '').strip()
                                if (_valid_doc_font_family(_fam) is None
                                        or (len(_fargs) > 1
                                            and _valid_doc_font_size(_sz) is None)):
                                    analysis.diagnostics.append(Diag(
                                        idx, _find_call_anchor(code, _dname),
                                        len(code), 'error',
                                        f'invalid *{_dname}(...) — ignored',
                                    ))
                        elif _dname.replace('-', '_') in ('doc_title', 'doctitle', 'title'):
                            if ctx._doc_title_seen:
                                analysis.diagnostics.append(Diag(
                                    idx, _find_call_anchor(code, _dname),
                                    _find_call_anchor(code, _dname) + 1,
                                    'warning',
                                    'multiple *doc_title(...) — last one wins',
                                ))
                            ctx._doc_title_seen = True
                        # Consumed control line: the compiler renders the
                        # title at codegen with final variables, so forward
                        # references are valid — skip per-line undefined
                        # checks here to avoid false positives.
                        continue

            # --- Text line checks (positions refer to the source line) ---
            # *p(...) raw spans are masked so their contents bypass checks.
            check_code = _mask_p_segments(code)
            check_code = blank_urls(check_code)
            if check_code.strip() == '':
                continue

            # --- Inline math state (mirrors compiler toggle semantics) ---
            # Checks below still run on math contents (variables/calc are
            # valid inside math); this only tracks unclosed delimiters.
            # Table/f-block rows never toggle math state — the compiler
            # checks in_f_block/*table rows before math-open detection,
            # so a stray \ in a cell can never swallow the document.
            bs = _unescaped_bs_positions(check_code)
            if not (in_table_block or in_f_block):
                if in_math:
                    if len(bs) % 2 == 1:
                        in_math = False
                else:
                    if len(bs) % 2 == 1:
                        in_math = True
                        math_start = idx
                        math_start_char = bs[-1]
            # Warn on empty \ \ pairs on this line.
            tmp = check_code
            while True:
                o = _unescaped_bs_positions(tmp)
                if len(o) < 2:
                    break
                inner = tmp[o[0] + 1:o[1]]
                if inner.strip() == '':
                    analysis.diagnostics.append(Diag(
                        idx, o[0], o[1] + 1, 'warning',
                        'Empty math expression \\ \\.',
                    ))
                    tmp = tmp[:o[0]] + ' ' * (o[1] + 1 - o[0]) + tmp[o[1] + 1:]
                else:
                    tmp = tmp[:o[0]] + ' ' * (o[1] + 1 - o[0]) + tmp[o[1] + 1:]

            # Unclosed *p( — the compiler warns too.
            for m in re.finditer(r'\*p\(', check_code):
                if _balanced_range(check_code, m.end() - 1) is None:
                    analysis.diagnostics.append(Diag(
                        idx, m.start(), len(check_code), 'warning',
                        'Unclosed *p( — treated as plain text',
                    ))

            known = sorted(set(ctx.variables) | set(ctx.defines))
            # Flag every undefined <name> occurrence in source offsets
            # (spacing variants like <oops> vs < oops > are distinct).
            for occ in VAR_TOKEN.finditer(check_code):
                raw_name = occ.group(1)
                if not re.fullmatch(rf'\s*{IDENT}\s*', raw_name):
                    continue
                # Mirror the compiler's << >> guard on the substituted
                # text is approximations; use source adjacency here.
                if occ.start() > 0 and check_code[occ.start() - 1] == '<':
                    continue
                if occ.end() < len(check_code) and check_code[occ.end()] == '>':
                    continue
                if _looks_like_comparison(check_code, occ.start(), occ.end()):
                    continue
                clean = raw_name.strip()
                if clean in ctx.variables or clean in ctx.defines:
                    continue
                message = f'Undefined variable <{clean}>'
                suggestion = difflib.get_close_matches(clean, known, n=1, cutoff=0.6)
                if suggestion:
                    message += f". Did you mean '{suggestion[0]}'?"
                analysis.diagnostics.append(Diag(
                    idx, occ.start(), occ.end(), 'error', message,
                ))

            # Mask single-line math pairs so commands inside math don't
            # warn (the text-mode scan). Math-pair contents get their
            # own scan below, mirroring the compiler's
            # warn_unknown_commands on inline math.
            _math_masked = check_code
            while True:
                _o = _unescaped_bs_positions(_math_masked)
                if len(_o) < 2:
                    break
                _math_masked = (
                    _math_masked[:_o[0]] + ' ' * (_o[1] + 1 - _o[0]) + _math_masked[_o[1] + 1:]
                )
            # Matrix/mat cells are transparent to the compiler's
            # unknown-command check (clean_inner_math never calls it).
            _cmd_scan_src = _mask_matrix_spans(_math_masked)
            for m in CMD_CALL.finditer(_cmd_scan_src):
                cmd = m.group(1)
                if cmd == 'calc':
                    # Unclosed *calc( is reported by the CALC_OPEN check;
                    # the compiler strips the leading * and never warns.
                    continue
                _known = _known_commands(analysis)
                if cmd in _known:
                    continue
                if cmd in KNOWN_GEOMETRY_COMMANDS or cmd.replace('_', '-') in KNOWN_GEOMETRY_COMMANDS:
                    analysis.diagnostics.append(Diag(
                        idx, m.start(), m.end(), 'warning',
                        _geometry_warning(cmd, parens=True),
                    ))
                    continue
                analysis.diagnostics.append(Diag(
                    idx, m.start(), m.end(), 'warning',
                    f"Unknown command *{cmd}(...) — treated as plain text",
                ))

            # Inside math pairs: the compiler warns about unknown
            # commands there too, and about text-mode commands (*image,
            # *newpage, *pagebreak) that make no sense inside math.
            _starts = _unescaped_bs_positions(check_code)
            for _k in range(0, len(_starts) - 1, 2):
                _i_start = _starts[_k] + 1
                _inner = check_code[_i_start:_starts[_k + 1]]
                _inner_unknown = _mask_matrix_spans(_inner)
                for m in CMD_CALL.finditer(_inner_unknown):
                    cmd = m.group(1)
                    a, b = _i_start + m.start(), _i_start + m.end()
                    if cmd in ('image', 'newpage', 'pagebreak'):
                        analysis.diagnostics.append(Diag(
                            idx, a, b, 'warning',
                            f"*{cmd}(...) is text mode and cannot be used "
                            f"inside math — leaving as-is",
                        ))
                        continue
                    _known = _known_commands(analysis)
                    if cmd == 'calc' or cmd in _known:
                        continue
                    if cmd in KNOWN_GEOMETRY_COMMANDS or cmd.replace('_', '-') in KNOWN_GEOMETRY_COMMANDS:
                        analysis.diagnostics.append(Diag(
                            idx, a, b, 'warning',
                            _geometry_warning(cmd, parens=True),
                        ))
                        continue
                    analysis.diagnostics.append(Diag(
                        idx, a, b, 'warning',
                        f"Unknown command *{cmd}(...) — treated as plain text",
                    ))

            # Bare *word without parens (mirrors the compiler warning).
            # Protected spans are hidden first: math pairs (above), calc()
            # contents (evaluated away by the compiler), known *cmd(...)
            # arguments (*frac(a*b ; c) is multiplication, not a command)
            # and literal dollars (the compiler escapes each '$').
            _bare_scan = _mask_calc_spans(_math_masked)
            _bare_scan = _mask_known_call_spans(_bare_scan)
            _bare_scan = _bare_scan.replace('$', ' ')
            for m in BARE_COMMAND_RE.finditer(_bare_scan):
                cmd = m.group(1)
                _known = _known_commands(analysis)
                if cmd in _known or cmd in _SYMBOL_WORDS or cmd == 'calc':
                    continue
                if cmd in KNOWN_GEOMETRY_COMMANDS or cmd.replace('_', '-') in KNOWN_GEOMETRY_COMMANDS:
                    analysis.diagnostics.append(Diag(
                        idx, m.start(), m.end(), 'warning',
                        _geometry_warning(cmd, parens=False),
                    ))
                    continue
                analysis.diagnostics.append(Diag(
                    idx, m.start(), m.end(), 'warning',
                    f"Unknown command *{cmd} — treated as plain text",
                ))

            # Table/matrix shape checks (text mode). Matrices also work
            # inside \ ... \ math, so validate them on the unmasked line;
            # tables inside math get their own warning.
            _validate_table_calls(
                _math_masked, idx, analysis, in_math_pairs=False,
            )
            _validate_plot_image_styling(_math_masked, idx, analysis, ctx)
            if _math_masked != check_code:
                # Only the insides of \ ... \ pairs (offsets preserved):
                # tables are invalid there, matrices get shape checks.
                _starts = _unescaped_bs_positions(check_code)
                _chars = list(check_code)
                _in_pair = [False] * len(_chars)
                for _k in range(0, len(_starts) - 1, 2):
                    for _j in range(_starts[_k], _starts[_k + 1] + 1):
                        _in_pair[_j] = True
                _math_only = ''.join(
                    c if _in_pair[_j] else ' '
                    for _j, c in enumerate(_chars)
                )
                _validate_table_calls(
                    _math_only, idx, analysis, in_math_pairs=True,
                )

            for m in CALC_OPEN.finditer(check_code):
                close = _balanced_range(check_code, m.end() - 1)
                if close is None:
                    analysis.diagnostics.append(Diag(
                        idx, m.start(), len(check_code), 'error',
                        'Unclosed parenthesis in calc(...)',
                    ))
                    continue
                # Evaluate the expression extracted from the source line
                # directly (evaluate_calc re-applies var/define
                # substitution). Use the original source line (`code`) for
                # slicing so source offsets stay accurate after any prior
                # substitutions changed text length.
                expr = code[m.end():close - 1]
                res = evaluate_calc(ctx, expr)
                if res.startswith('[Calc Error'):
                    analysis.diagnostics.append(Diag(
                        idx, m.start(), close, 'error', res,
                    ))

    if in_math:
        analysis.diagnostics.append(Diag(
            math_start, math_start_char,
            len(lines[math_start]) if math_start < len(lines) else math_start_char + 1,
            'error', 'Unclosed math delimiter \\ ... \\ — missing closing \\.',
        ))

    if in_f_block:
        analysis.diagnostics.append(Diag(
            block_start, 0,
            len(lines[block_start]) if block_start < len(lines) else 0,
            'error', "Unclosed block '(' — content may be silently consumed",
        ))

    if in_table_block:
        analysis.diagnostics.append(Diag(
            table_start, 0,
            len(lines[table_start]) if table_start < len(lines) else 0,
            'error', "Unclosed block '(' — content may be silently consumed",
        ))

    for d in analysis.definitions:
        kind, value = d.kind, d.value
        if value is not None and (
            '[Calc Error' in str(value) or '[UNDEFINED' in str(value)
        ):
            # The stored "value" is the literal failure marker the
            # compiler wrote in — never present it as a real value.
            value = None
        elif value is not None and '<' in value:
            with _quiet():
                resolved = replace_vars(ctx, value)
            if '[Calc Error' in resolved or '[UNDEFINED' in resolved:
                value = None
            elif '<' not in resolved:
                value = resolved
        analysis.values[d.name] = (kind, value, d.line)
    return analysis


# --- Inline math membership check ---
def _in_p_span(line_text, character):
    """True when the cursor offset lies inside a balanced *p(...) span."""
    pat = re.compile(r'\*p\(')
    pos = 0
    while True:
        m = pat.search(line_text, pos)
        if not m:
            return False
        close = _balanced_range(line_text, m.end() - 1)
        if close is None:
            return False
        if m.start() <= character < close:
            return True
        pos = close


# --- LSP request handlers: complete / hover / document symbols ---
def complete(text, line, character, base_dir=None, uri=None):
    """Completion candidates at a cursor position (client filters by prefix)."""
    analysis = analyze_text(text, base_dir=base_dir, uri=uri)
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    cur = lines[line] if 0 <= line < len(lines) else ''
    # Inside *p(...) raw spans the compiler ignores variables; suppress
    # variable/define items there (keep symbol/function help).
    in_p = _in_p_span(cur, max(0, character))
    head = cur[:max(0, character)]
    star = bool(re.search(r'\*(?=[A-Za-z_][A-Za-z0-9_]*$)', head))

    items = []
    if not in_p:
        for name, (kind, value, _def_line) in sorted(analysis.values.items()):
            if kind == 'draw':
                # The *draw block's own symbol: KEYWORD_DOCS already
                # suggests 'draw' with its signature below — listing the
                # block twice (once as a bare "draw" constant) is noise.
                continue
            items.append({
                'label': name,
                'kind': 'variable' if kind == 'variable' else 'constant',
                'detail': f'= {value}' if value else kind,
            })
    math_docs = dict(builtins.MATH_DOCS)
    reg = getattr(analysis, 'registry', None)
    if reg is not None:
        for spec in reg.commands.values():
            if spec.name not in math_docs:
                math_docs[spec.name] = (spec.usage, spec.doc)
            for alias in spec.aliases:
                if alias not in math_docs:
                    alias_usage = spec.usage.replace(
                        '*' + spec.name, '*' + alias, 1)
                    math_docs[alias] = (
                        alias_usage, f'{spec.doc} (alias of *{spec.name})')
    for name in sorted(math_docs):
        sig, _desc = math_docs[name]
        items.append({'label': name, 'kind': 'function', 'detail': sig})
    for name in sorted(builtins.KEYWORD_DOCS):
        sig, _desc = builtins.KEYWORD_DOCS[name]
        items.append({'label': name, 'kind': 'keyword', 'detail': sig})
    for name in sorted(builtins.GEOMETRY_DOCS):
        sig, _desc = builtins.GEOMETRY_DOCS[name]
        items.append({'label': name, 'kind': 'function', 'detail': f'geometry: {sig}'})
    for name in sorted(builtins.GEOMETRY_CONSTRUCTION_DOCS):
        sig, _desc = builtins.GEOMETRY_CONSTRUCTION_DOCS[name]
        items.append({'label': name, 'kind': 'function',
                      'detail': f'geometry construction (in *point): {sig}'})
    if star:
        for word, glyph in builtins.symbol_entries():
            items.append({
                'label': f'*{word}', 'kind': 'keyword',
                'detail': f'symbol {glyph}',
            })
    return items


def hover(text, line, character, base_dir=None, uri=None):
    """Hover info for the identifier under the cursor, or None."""
    analysis = analyze_text(text, base_dir=base_dir, uri=uri)
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    if not (0 <= line < len(lines)):
        return None
    cur = lines[line]
    if _in_p_span(cur, character):
        # Raw passthrough: the compiler treats contents literally.
        return None
    token = None
    for m in WORD_AT.finditer(cur):
        if m.start() <= character <= m.end():
            token = m
            break
    if token is None:
        return None
    name = token.group(0)
    if name in analysis.values:
        kind, value, def_line = analysis.values[name]
        if kind != 'draw':
            shown_kind = 'Define' if kind == 'define' else 'Variable'
            body = f'**{name}**\n\n{shown_kind}'
            if value:
                body += f'\n\nValue: {value}'
            body += f'\n\nDefined at line {def_line + 1}'
            return {'value': body, 'start': token.start(), 'end': token.end()}
        # The *draw block's own symbol: fall through to KEYWORD_DOCS so
        # hovering *draw( shows the command's signature + description
        # (more useful than "Variable, defined at line N").
    reg = getattr(analysis, 'registry', None)
    spec = None
    if reg is not None:
        if name in reg.commands:
            spec = reg.commands[name]
        elif name in reg.aliases:
            spec = reg.commands.get(reg.aliases[name])
    if spec is not None:
        if name == spec.name:
            sig = spec.usage
        else:
            sig = spec.usage.replace('*' + spec.name, '*' + name, 1)
        desc = spec.doc
        try:
            from compiler.command_registry import is_user_mod_spec as _is_user
            user = _is_user(spec)
        except Exception:
            user = False
        extra = ''
        if user:
            if name in builtins.MATH_DOCS:
                extra = '\n\nOverrides the built-in definition.'
            else:
                extra = f'\n\nDefined in {spec.source}.'
        return {'value': f'**{name}**\n\nFunction\n\n{sig}\n\n{desc}{extra}',
                'start': token.start(), 'end': token.end()}
    if name in builtins.MATH_DOCS:
        sig, desc = builtins.MATH_DOCS[name]
        return {'value': f'**{name}**\n\nFunction\n\n{sig}\n\n{desc}',
                'start': token.start(), 'end': token.end()}
    if name in builtins.KEYWORD_DOCS:
        sig, desc = builtins.KEYWORD_DOCS[name]
        return {'value': f'**{name}**\n\nKeyword\n\n{sig}\n\n{desc}',
                'start': token.start(), 'end': token.end()}
    if name in builtins.GEOMETRY_DOCS:
        sig, desc = builtins.GEOMETRY_DOCS[name]
        return {'value': f'**{name}**\n\nGeometry command\n\n{sig}\n\n{desc}',
                'start': token.start(), 'end': token.end()}
    if name in builtins.GEOMETRY_CONSTRUCTION_DOCS:
        sig, desc = builtins.GEOMETRY_CONSTRUCTION_DOCS[name]
        return {'value': f'**{name}**\n\nGeometry construction '
                         f'(used inside *point)\n\n{sig}\n\n{desc}',
                'start': token.start(), 'end': token.end()}
    for word, glyph in builtins.symbol_entries():
        if name == word:
            return {'value': f'**{name}**\n\nSymbol\n\n`*{word}` → {glyph}',
                    'start': token.start(), 'end': token.end()}
    return None


def document_symbols(text):
    """Flat (name, kind, line, start, end) symbols for the document."""
    return [
        (d.name, d.kind, d.line, d.start, d.end)
        for d in analyze_text(text).definitions
    ]
